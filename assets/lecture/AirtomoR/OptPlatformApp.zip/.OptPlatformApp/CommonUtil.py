#!/usr/bin/python3
# coding: utf-8
#
#  CommonUtil.py
#
import logging
logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)

import os
import glob
import shutil
import sys

import math

def divname2num(divname):
    try:
        head, tail = divname.split("_")
        divnum = int(head[len("div"):])
        str_list=[]
        int_list=[]
        if divnum <= 32:
            for i in range(len(tail)):
                str_list.append(tail[i])
            int_list = [max(0,int(s,base=32)) for s in str_list]
            return divnum, int_list
        else:
            str_list = tail.split("#")
            int_list = [max(0,int(s,base=32)) for s in str_list]
            return divnum, int_list
    except:
        return None, None

def num2divname(divnum,int_list):

    if divnum <= 32:
        divname = "div"+str(divnum)+"_"
        for elem in int_list:
            if elem==0:
                divname = divname + '0'
            else:
                l = [max(0,int(x)) for x in list(str(elem))]
                divname = divname + base_convert(l, 10, 32)
        return divname
    else:
        divname = "div"+str(divnum)+"_"
        for elem in int_list:
            if elem==0:
                divname = divname + '0' + "#"
            else:
                l = [max(0,int(x)) for x in list(str(elem))]
                divname = divname + base_convert(l, 10, 32) + "#"
        divname = divname[:-1]
        return divname

def base_convert(nl, ibase, obase):
    o = []
    while any(nl):
        c = 0
        for i in range(len(nl)):
            c = c * ibase + nl[i]
            nl[i],c = divmod(c,obase)
        o.append(c)
    o.reverse()
    s32 = ""
    for item in o:
        if item<10:
            s32=s32+str(item)        
        elif item==10:
            s32=s32+"a"
        elif item==11:
            s32=s32+"b"
        elif item==12:
            s32=s32+"c"
        elif item==13:
            s32=s32+"d"
        elif item==14:
            s32=s32+"e"
        elif item==15:
            s32=s32+"f"
        elif item==16:
            s32=s32+"g"
        elif item==17:
            s32=s32+"h"
        elif item==18:
            s32=s32+"i"
        elif item==19:
            s32=s32+"j"
        elif item==20:
            s32=s32+"k"
        elif item==21:
            s32=s32+"l"
        elif item==22:
            s32=s32+"m"
        elif item==23:
            s32=s32+"n"
        elif item==24:
            s32=s32+"o"
        elif item==25:
            s32=s32+"p"
        elif item==26:
            s32=s32+"q"
        elif item==27:
            s32=s32+"r"
        elif item==28:
            s32=s32+"s"
        elif item==29:
            s32=s32+"t"
        elif item==30:
            s32=s32+"u"
        else:
            s32=s32+"v"
    return s32


def getscore(startDir):
    if os.path.exists(startDir + "/score.csv"):
        f = open(startDir + "/score.csv")
        cont = f.read()
        f.close()
        cols = cont.split(",")

        try:
            head = float(cols[0])
            return(head)
        except:
            return None
    else:
        return None



def getscores(startDir):
    if os.path.exists(startDir + "/score.csv"):
        f = open(startDir + "/score.csv")
        cont = f.read(); f.close()
        score = cont.split()[0]
        try:
            float_score = [float(s) for s in score.split(",")]
            return float_score
        except:
            return None
    else:
        return None

def get_value_header(startDir):
    if os.path.exists(startDir + "/value_header.csv"):
        f = open(startDir + "/value_header.csv")
        cont = f.read(); f.close()
        score = cont.split()[0]
        try:
            float_score = [float(s) for s in score.split(",")]
            return float_score
        except:
            return None
    else:
        return None



def getscorelen(startDir):
    if(getscores(startDir)!=None):
        return len(getscores(startDir))
    else:
        folderDirs = glob.glob(startDir + "/*")
        scoreFiles = []
        for folderDir in folderDirs:
            if os.path.exists(folderDir + "/score.csv"):
                return len(getscores(folderDir))
        return 0
        

def direction_decode( parentDir, myselfDir):

    parent_div,parent_list = divname2num(os.path.basename(parentDir))
    myself_div,myself_list = divname2num(os.path.basename(myselfDir))

    ancestor_direction = []
    attr_TreeType = ""

    if (parent_div+1==myself_div):
#        logging.debug("Pascal")
        attr_TreeType = "Pascal"
        ancestor_direction=[2*(x1 - x2) for (x1,x2) in zip(myself_list,parent_list)]

    elif (parent_div*2==myself_div):
#        print("Binary")
        attr_TreeType = "Binary"
        ancestor_direction=[x1 - 2*x2 + 1 for (x1,x2) in zip(myself_list,parent_list)]
        

    elif ( parent_div%3==0 and myself_div== (parent_div//3)*4 ) or ( parent_div%3!=0 and myself_div==(parent_div//2)*3 ) :
#        print("fcPascal")
        ancestor_direction=[]
        attr_TreeType = "fcPascal"
        epsilon = 0.00000000000000001
        for x1, x2 in zip(myself_list,parent_list):
            if x1 < (myself_div+1)//2 and (parent_div%2==0 and x2!=parent_div//2) and x1 == min( myself_div//2 -2  ,max(1, math.floor(( (x2/parent_div - 1/(2*myself_div)))  * myself_div - epsilon)  ))  + 1:
                ancestor_direction.append(1)
            elif x1 > myself_div//2 and   (parent_div%2==0 and x2!=parent_div//2) and x1 == max( (myself_div+1)//2 +2 ,min(myself_div-1, math.ceil(( (x2/parent_div + 1/(2*myself_div) )) * myself_div + epsilon) )) -1:
                ancestor_direction.append(1)
            elif myself_div%2==0 and  x1 == myself_div//2 and parent_div%2==0 and  x2 == parent_div//2:
                ancestor_direction.append(1)
            elif float(x1) / myself_div - float(x2) / parent_div > 0:
                ancestor_direction.append(2)
            else:
                ancestor_direction.append(0)

    elif (parent_div*3==myself_div):
#        print("Binary")
        attr_TreeType = "div12"
        # div12 abst table createjob, need +1 offset (in function -1 apply)
        ancestor_direction=[x1 - 3*x2 +1 for (x1,x2) in zip(myself_list,parent_list)]


        
    else:
        logging.debug("direction of selectDir is not belong to prepared TreeType")
        ancestor_direction = []

    return attr_TreeType, ancestor_direction
    
    
def inversed_direction(direction):
    return_direction = [2 - s for s in direction] 
    return return_direction    
    
    
def direction_decode2str( parentDir, myselfDir):

    _,ancestor_direction = direction_decode(parentDir, myselfDir )

    return_strlist = []

    if not ancestor_direction:
        return return_strlist

    else:
        for elem in ancestor_direction:
            if elem==1:
                return_strlist.append("Center")
            elif elem <= 0:
                return_strlist.append("Down")
            else:
                return_strlist.append("Up")

    return return_strlist

