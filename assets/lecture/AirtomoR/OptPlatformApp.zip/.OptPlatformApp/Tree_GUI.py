#!/usr/bin/python3
# -*- coding: utf-8 -*-
"""
Opt_platform.py
Copyright (C) 2020 Tsunehiro Watanabe, Shigeki Fujii all rights reserved.

This software is released under the MIT License.
http://opensource.org/licenses/mit-license.php
"""

from Util_Tree import TreeWidget, treeWidget_Extend
import logging
logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)


#from PySide import QtCore, QtGui
#from PySide.QtGui import *
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

#<
#from PySide.QtUiTools import QUiLoader
#>
#from functools import partial
from decimal import Decimal
import sys
import os.path
import gettext
import tempfile
import math
import subprocess
from subprocess import Popen
import shutil
import glob
import threading
#import treeWidget_ExtendQt4Dialog5 as myTree
import Util_Tree
#import pandas as pd
import six

#from sklearn.tree import DecisionTreeRegressor
#import numpy as np

import re

#import Table_GUI

import multiprocessing
import time
import csv

import signal

import CommonUtil
import ExecUtil

#version definition
Version = "2.10"            #optPlatfoamのversion

#import hoge
#amount of outer parallel definition
nProcs = max(multiprocessing.cpu_count() // 2, 1) #half thread
nCpu_perCase = 1                            #(Now and future may not implement)amount of inner parallel definition

#TreeType ="Binary_plusC"
TreeType ="Binary"

#logFile definition
LogFile = os.getenv("Optlog")
LogTableGui = os.getenv("TableGui_log")
LogTableGuiLoad = os.getenv("TableGuiLoad_log")
flagTableGui = os.getenv("TableGui_flag")
flagTableGuiLoad = os.getenv("TableGuiLoad_flag")

nOutParallel, nInParallel = "", ""

#-------------------
#  textEdit class
#-------------------
class textEdit(QTextEdit):
    try:
        reloadSignal =  pyqtSignal(str)
    except:
        reloadSignal =  Signal(str)

#------------------
#  lineEdit class
#------------------
class lineEdit(QLineEdit):
    try:
        keyUpSignal =  pyqtSignal()
        keyDownSignal =  pyqtSignal()
        keyEnterSignal =  pyqtSignal()
    except:
        keyUpSignal =  Signal()
        keyDownSignal =  Signal()
        keyEnterSignal =  Signal()

    def keyPressEvent(self, event):
        key = event.key()
        if key ==  Qt.Key_Up:
            self.keyUpSignal.emit()
        elif key ==  Qt.Key_Down:
            self.keyDownSignal.emit()
        elif key ==  Qt.Key_Enter or key ==  Qt.Key_Return:
            self.keyEnterSignal.emit()
        else:
            return QLineEdit.keyPressEvent(self, event)
        return


#class Tree_GUIFrame( QDialog):
class Tree_GUIFrame(QMainWindow):
    """
    Class of inherited Frame, use for GUI layout
    """

    threadEndSignal = Signal()

    #def __init__(self, mainWindow, parent=None):
    def __init__(self, mainWindow):
      
        # QDialog.__init__(self)
        super(Tree_GUIFrame, self).__init__(mainWindow)
        self.mainWindow = mainWindow
        #get windowSize
        self.width = 1200
        self.height = 1000
        optDir = os.getenv("OptPlatform")
        fileName = optDir + "/Opt_platform_winSize"
        if os.path.exists(fileName):
            f = open(fileName); line = f.read(); f.close()
            words = line.split()
            if len(words) >= 2:
                self.width = int(words[0])
                self.height = int(words[1])
        #suspend thread flag
        self.flagThread = "run"

    def GUILayout(self,  caseDirectory):
        """
        Set this layout
        """

        width = self.width
        height = self.height
        self.mainWindow.resize(width, height)
        self.centralWidget = QWidget(self.mainWindow)

        #splitter and the box definition
        totalpanel = QHBoxLayout(self.centralWidget)
        self.splitter = QSplitter(Qt.Horizontal)
        #self.splitter.setSizes([600, 600])

        #left widget of splitter definition-----------------------------
        self.frame = QFrame(self.centralWidget)
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        panel1 = QVBoxLayout(self.frame)

        #create treeWidget
        caseDir = caseDirectory
        selDir = os.path.dirname(caseDir)
        self.tree = Util_Tree.treeWidget_Extend(caseDir)
        #self.treeWidget = self.tree.treeWidget
        #set tree window size
        #self.treeWidget.setMinimumSize( QSize(0, 1000))
        panel1.addWidget(self.tree.treeWidget)
        self.tree.main()
        self.splitter.addWidget(self.frame)

        #right widget of splitter definition-----------------------------
        self.frame2 = QFrame(self.centralWidget)
        self.frame2.setFrameShape(QFrame.StyledPanel)
        self.frame2.setFrameShadow(QFrame.Raised)
        panel2 = QVBoxLayout(self.frame2)

        #out splitter definition--------------------------------
        self.outSplitter = QSplitter(Qt.Vertical)

        #above of splitter definition-----------------------------------
        self.frameUp = QFrame()
        self.frameUp.setFrameShape(QFrame.StyledPanel)
        self.frameUp.setFrameShadow(QFrame.Raised)
        panelUp = QVBoxLayout(self.frameUp)

        #set widget at panalUp---------
        #label currentDir
        self.label_currDir = QLabel(self.frame2)
        self.label_currDir.setObjectName("label_currDir")
        #self.label_currDir.setText("currDir: " + caseDirectory )
        panelUp.addWidget(self.label_currDir)
        #label comm
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label_comm = QLabel(self.frame2)
        self.label_comm.setObjectName("label_comm")
        self.label_comm.setText("command")
        self.horizontalLayout.addWidget(self.label_comm)
        #lineEdit command
        self.lineEdit_command = lineEdit(self.frame2)
        #self.lineEdit_command =  QLineEdit(self.frame2)
        self.lineEdit_command.setObjectName("lineEdit_command")
        self.horizontalLayout.addWidget(self.lineEdit_command)
        #button run
        self.button_run = QPushButton(self.frame2)
        self.button_run.setObjectName("button_run")
        self.button_run.setText(u"Run")
        self.horizontalLayout.addWidget(self.button_run)
        #button cancel
        self.button_cancel = QPushButton(self.frame2)
        self.button_cancel.setObjectName("button_cancel")
        self.button_cancel.setText(u"Pause")
        self.horizontalLayout.addWidget(self.button_cancel)
        panelUp.addLayout(self.horizontalLayout)
        #textEdit
        self.textEdit_results = textEdit(self.frame2)
        #self.textEdit_results =  QTextEdit(self.frame2)
        self.textEdit_results.setObjectName("textEdit_results")
        panelUp.addWidget(self.textEdit_results)

        #add frame at out splitter
        self.outSplitter.addWidget(self.frameUp)

        #below of out plitter definition----------------------------------
        self.frameDown = QFrame()
        self.frameDown.setFrameShape(QFrame.StyledPanel)
        self.frameDown.setFrameShadow(QFrame.Raised)
        panelDown = QVBoxLayout(self.frameDown)
        panel2.addWidget(self.frameDown)

        #set widget at panelDown---------
        verticalLayoutLog = QVBoxLayout()
        #label_log
        self.label_log = QLabel(self.frameDown)
        self.label_log.setText("opt_platform log")
        verticalLayoutLog.addWidget(self.label_log)
        #textEdit_log
        self.textEdit_log = textEdit(self.frameDown)
        self.textEdit_log.setObjectName("textEdit_log")
        verticalLayoutLog.addWidget(self.textEdit_log)

        panelDown.addLayout(verticalLayoutLog)
        #add frame at out splitter
        self.outSplitter.addWidget(self.frameDown)

        #set the position of out splitter (ratio 8:2)
        outSplitterSize = self.outSplitter.size().height()
        self.outSplitter.setSizes([outSplitterSize*0.8, outSplitterSize*0.2])
        #add out splitter at panel2
        panel2.addWidget(self.outSplitter)


        #toolBar items
        self.toolBar = QToolBar(self.mainWindow)
        self.toolBar.setObjectName("toolBar")
        self.mainWindow.addToolBar( Qt.TopToolBarArea, self.toolBar)
        self.toolBar.setContextMenuPolicy( Qt.PreventContextMenu)

        #  optSearchMax
        icon_optSearch = QIcon()
        icon_optSearch.addPixmap(QPixmap("searchMax.png"), QIcon.Normal, QIcon.Off)
        self.actionOptSearch = QAction(self.mainWindow)
        self.actionOptSearch.setIcon(icon_optSearch)
        self.actionOptSearch.setObjectName("actionOptSearch")
        self.actionOptSearch.setToolTip(u"Search score max")
        self.toolBar.addAction(self.actionOptSearch)
        #  sub1SearchMax
        icon_sub1SearchMax = QIcon()
        icon_sub1SearchMax.addPixmap(QPixmap("go-up1.png"), QIcon.Normal, QIcon.Off)
        self.actionSub1SearchMax = QAction(self.mainWindow)
        self.actionSub1SearchMax.setIcon(icon_sub1SearchMax)
        self.actionSub1SearchMax.setObjectName("actionSub1SearchMax")
        self.actionSub1SearchMax.setToolTip(u"Search sub4*n+ 1 max")
        self.toolBar.addAction(self.actionSub1SearchMax)
        #  sub2SearchMax
        icon_sub2SearchMax = QIcon()
        icon_sub2SearchMax.addPixmap(QPixmap("go-up2.png"), QIcon.Normal, QIcon.Off)
        self.actionSub2SearchMax = QAction(self.mainWindow)
        self.actionSub2SearchMax.setIcon(icon_sub2SearchMax)
        self.actionSub2SearchMax.setObjectName("actionSub2SearchMax")
        self.actionSub2SearchMax.setToolTip(u"Search sub4*n+ 2 max")
        self.toolBar.addAction(self.actionSub2SearchMax)
        #  sub3SearchMax
        icon_sub3SearchMax = QIcon()
        icon_sub3SearchMax.addPixmap(QPixmap("go-up3.png"), QIcon.Normal, QIcon.Off)
        self.actionSub3SearchMax = QAction(self.mainWindow)
        self.actionSub3SearchMax.setIcon(icon_sub3SearchMax)
        self.actionSub3SearchMax.setObjectName("actionSub3SearchMax")
        self.actionSub3SearchMax.setToolTip(u"Search sub4*n+ 3 max")
        self.toolBar.addAction(self.actionSub3SearchMax)
        #  sub4SearchMax
        icon_sub4SearchMax = QIcon()
        icon_sub4SearchMax.addPixmap(QPixmap("go-up4.png"), QIcon.Normal, QIcon.Off)
        self.actionSub4SearchMax = QAction(self.mainWindow)
        self.actionSub4SearchMax.setIcon(icon_sub4SearchMax)
        self.actionSub4SearchMax.setObjectName("actionSub4SearchMax")
        self.actionSub4SearchMax.setToolTip(u"Search sub4*n+ 4 max")
        self.toolBar.addAction(self.actionSub4SearchMax)
        #  optSearchMin
        icon_optSearchMin = QIcon()
        icon_optSearchMin.addPixmap(QPixmap("searchMin.png"), QIcon.Normal, QIcon.Off)
        self.actionOptSearchMin = QAction(self.mainWindow)
        self.actionOptSearchMin.setIcon(icon_optSearchMin)
        self.actionOptSearchMin.setObjectName("actionOptSearchMin")
        self.actionOptSearchMin.setToolTip(u"Search score min")
        self.toolBar.addAction(self.actionOptSearchMin)
        #  sub1SearchMin
        icon_sub1SearchMin = QIcon()
        icon_sub1SearchMin.addPixmap(QPixmap("go-down1.png"), QIcon.Normal, QIcon.Off)
        self.actionSub1SearchMin = QAction(self.mainWindow)
        self.actionSub1SearchMin.setIcon(icon_sub1SearchMin)
        self.actionSub1SearchMin.setObjectName("actionSub1SearchMin")
        self.actionSub1SearchMin.setToolTip(u"Search sub4*n+ 1 min")
        self.toolBar.addAction(self.actionSub1SearchMin)
        #  sub2SearchMin
        icon_sub2SearchMin = QIcon()
        icon_sub2SearchMin.addPixmap(QPixmap("go-down2.png"), QIcon.Normal, QIcon.Off)
        self.actionSub2SearchMin = QAction(self.mainWindow)
        self.actionSub2SearchMin.setIcon(icon_sub2SearchMin)
        self.actionSub2SearchMin.setObjectName("actionSub2SearchMin")
        self.actionSub2SearchMin.setToolTip(u"Search sub4*n+ 2 min")
        self.toolBar.addAction(self.actionSub2SearchMin)
        #  sub3SearchMin
        icon_sub3SearchMin = QIcon()
        icon_sub3SearchMin.addPixmap(QPixmap("go-down3.png"), QIcon.Normal, QIcon.Off)
        self.actionSub3SearchMin = QAction(self.mainWindow)
        self.actionSub3SearchMin.setIcon(icon_sub3SearchMin)
        self.actionSub3SearchMin.setObjectName("actionSub3SearchMin")
        self.actionSub3SearchMin.setToolTip(u"Search sub4*n+ 3 min")
        self.toolBar.addAction(self.actionSub3SearchMin)
        #  sub4SearchMin
        icon_sub4SearchMin = QIcon()
        icon_sub4SearchMin.addPixmap(QPixmap("go-down4.png"), QIcon.Normal, QIcon.Off)
        self.actionSub4SearchMin = QAction(self.mainWindow)
        self.actionSub4SearchMin.setIcon(icon_sub4SearchMin)
        self.actionSub4SearchMin.setObjectName("actionSub4SearchMin")
        self.actionSub4SearchMin.setToolTip(u"Search sub4*n+ 4 min")
        self.toolBar.addAction(self.actionSub4SearchMin)

        #  backward
        icon_backward = QIcon()
        icon_backward.addPixmap(QPixmap("backwardArrow.png"), QIcon.Normal, QIcon.Off)
        self.actionbackward = QAction(self.mainWindow)
        self.actionbackward.setIcon(icon_backward)
        self.actionbackward.setObjectName("actionbackward")
        self.actionbackward.setToolTip(u"backward subscore")
        self.toolBar.addAction(self.actionbackward)
        #  forward
        icon_forward = QIcon()
        icon_forward.addPixmap(QPixmap("forwardArrow.png"), QIcon.Normal, QIcon.Off)
        self.actionforward = QAction(self.mainWindow)
        self.actionforward.setIcon(icon_forward)
        self.actionforward.setObjectName("actionforward")
        self.actionforward.setToolTip(u"forward subscore")
        self.toolBar.addAction(self.actionforward)
        #  reloadDir
        icon_reloadDir = QIcon()
        icon_reloadDir.addPixmap(QPixmap("reload.png"), QIcon.Normal, QIcon.Off)
        self.actionReloadDir = QAction(self.mainWindow)
        self.actionReloadDir.setIcon(icon_reloadDir)
        self.actionReloadDir.setObjectName("actionReloadDir")
        self.actionReloadDir.setToolTip(u"reload Tree diagram")
        self.toolBar.addAction(self.actionReloadDir)

        #comboBox Patterncode
        self.hLayout_6 =  QHBoxLayout()
        self.typeComboBox2 =  QComboBox(self.frame2)

        self.typeComboBox2.addItem("logcode")
        self.typeComboBox2.addItem("logcode_xor")
#        self.typeComboBox2.addItem("logcode_andnand")
        self.typeComboBox2.addItem("logcode_xor_andnand")
        self.typeComboBox2.addItem("4C2")
        self.typeComboBox2.addItem("6C3")
        self.typeComboBox2.addItem("8C4")
        self.typeComboBox2.addItem("10C5")
        self.typeComboBox2.addItem("12C6")
        self.typeComboBox2.addItem("5C2")
        self.typeComboBox2.addItem("5C3")
        self.typeComboBox2.addItem("7C3")
        self.typeComboBox2.addItem("7C4")        

        self.hLayout_6.addWidget(self.typeComboBox2)


# for modulation lcg-flag
        self.checkBox0 =  QCheckBox()
        self.checkBox0.setText(u"modulation")
        self.hLayout_6.addWidget(self.checkBox0)

        self.label_b_constant =  QLabel(self.frame2)
        self.label_b_constant.setObjectName("b_constant")
        self.label_b_constant.setText("b_constant")
        self.hLayout_6.addWidget(self.label_b_constant)

        self.typeComboBox3 =  QComboBox(self.frame2)
        self.typeComboBox3.addItem("131")
        self.typeComboBox3.addItem("135")
        self.typeComboBox3.addItem("139")
        self.typeComboBox3.addItem("143")
        self.typeComboBox3.addItem("147")
        self.typeComboBox3.addItem("151")
        self.typeComboBox3.addItem("155")
        self.typeComboBox3.addItem("159")

        self.hLayout_6.addWidget(self.typeComboBox3)

        spacerItem6 =  QSpacerItem(40, 20,  QSizePolicy.Expanding,  QSizePolicy.Minimum)
        self.hLayout_6.addItem(spacerItem6)

        #global nOutParallel, nInParallel
        #label nOutPara
        self.label_nOutPara =  QLabel(self.frame2)
        self.label_nOutPara.setObjectName("nCase")
        self.label_nOutPara.setText("nCase")
        self.hLayout_6.addWidget(self.label_nOutPara)
        #lineEdit nOutPara
        self.nOutParallel =  QLineEdit(self.frame2)
        self.nOutParallel.setFixedWidth(90)
        self.nOutParallel.setObjectName("nCase")
        self.nOutParallel.setText(str(nProcs))
        self.hLayout_6.addWidget(self.nOutParallel)
        #label nInPara
#        self.label_nInPara = QtGui.QLabel(self.frame2)
#        self.label_nInPara.setObjectName("nCpu_perCase")
#        self.label_nInPara.setText("nCpu_perCase")
#        self.horizontalLayout_7.addWidget(self.label_nInPara)

        #lineEdit nInPara
#        nInParallel = QtGui.QLineEdit(self.frame2)
#        nInParallel.setObjectName("nCpu_perCase")
#        nInParallel.setText(str(nCpu_perCase))
#        self.horizontalLayout_7.addWidget(nInParallel)

        #checkBox
        self.checkBox1 =  QCheckBox()
        self.checkBox1.setText(u"only csv")
        self.hLayout_6.addWidget(self.checkBox1)

# for modulation lcg-flag

        self.vLayout_6 =  QVBoxLayout()
        self.vLayout_6.addLayout(self.hLayout_6)

        self.horizontalLayout_6 =  QHBoxLayout()

        #button Edit2
        self.pattern_execButton =  QPushButton(self.frame2)
        self.pattern_execButton.setObjectName("pattern_exec")
        self.pattern_execButton.setText("Pattern_exec")
        self.horizontalLayout_6.addWidget(self.pattern_execButton)
        #button eachparam_exec
        self.eachparam_execButton =  QPushButton(self.frame2)
        self.eachparam_execButton.setObjectName("eachparam_exec")
        self.eachparam_execButton.setText("eachparam_exec")
        self.horizontalLayout_6.addWidget(self.eachparam_execButton)

        #button samedirect_exec
        self.samedirect_execButton =  QPushButton(self.frame2)
        self.samedirect_execButton.setObjectName("samedirect_exec")
        self.samedirect_execButton.setText("samedirect_exec")
        self.horizontalLayout_6.addWidget(self.samedirect_execButton)

        #button Osamedirect_exec
        self.Osamedirect_execButton =  QPushButton(self.frame2)
        self.Osamedirect_execButton.setObjectName("Osamedirect_exec")
        self.Osamedirect_execButton.setText("Osamedirect_exec")
        self.horizontalLayout_6.addWidget(self.Osamedirect_execButton)


        #button makeMesh2        
        self.select_execButton =  QPushButton(self.frame2)
        self.select_execButton.setObjectName("select_execButton")
        self.select_execButton.setText("select_exec")
        self.horizontalLayout_6.addWidget(self.select_execButton)

        self.nearbyGrid_execButton =  QPushButton(self.frame2)
        self.nearbyGrid_execButton.setObjectName("nearbyGrid_execButton")
        self.nearbyGrid_execButton.setText("nearbyGrid_exec")
        self.horizontalLayout_6.addWidget(self.nearbyGrid_execButton)

        self.vLayout_6.addLayout(self.horizontalLayout_6)

        #group action2
        self.horizontalGroupBox6 =  QGroupBox('PatternCode / option@exec /      exec_button')
#        self.horizontalGroupBox6.setLayout(self.horizontalLayout_6)
        self.horizontalGroupBox6.setLayout(self.vLayout_6)
#        panel2.addWidget(self.horizontalGroupBox6)


#        self.hLayout_5 = QtGui.QHBoxLayout()

        self.vLayout_5 =  QVBoxLayout()
#        self.vLayout_5.addLayout(self.hLayout_5)

        self.horizontalLayout_5 =  QHBoxLayout()


        #button viewMesh
        self.Table_GUIButton =  QPushButton(self.frame2)
        self.Table_GUIButton.setObjectName("Table_GUIButton")
        self.Table_GUIButton.setText("TableGUI")
        self.horizontalLayout_5.addWidget(self.Table_GUIButton)

        #button viewMesh
        self.Table_fromloadDirButton =  QPushButton(self.frame2)
        self.Table_fromloadDirButton.setObjectName("TableGUI_fromloadDir")
        self.Table_fromloadDirButton.setText("TableGUI_fromloadDir")
        self.horizontalLayout_5.addWidget(self.Table_fromloadDirButton)

        #button viewMesh
        self.Div12_Table_GUIButton =  QPushButton(self.frame2)
        self.Div12_Table_GUIButton.setObjectName("Div12_Table_GUIButton")
        self.Div12_Table_GUIButton.setText("Div12_TableGUI")
        self.horizontalLayout_5.addWidget(self.Div12_Table_GUIButton)

        #supacer
        spacerItem2 =  QSpacerItem(40, 20,  QSizePolicy.Expanding,  QSizePolicy.Minimum)
        self.horizontalLayout_5.addItem(spacerItem2)
        #button exit2
        self.exit2Button =  QPushButton(self.frame2)
        self.exit2Button.setObjectName("exit2Button")
        self.exit2Button.setText("Exit")
        self.horizontalLayout_5.addWidget(self.exit2Button)
        self.vLayout_5.addLayout(self.horizontalLayout_5)

        #group action2
        self.horizontalGroupBox5 =  QGroupBox('TableGUI_button / Exit')
        #self.horizontalGroupBox6.setLayout(self.horizontalLayout_6)
        self.horizontalGroupBox5.setLayout(self.vLayout_5)
        # panel2.addWidget(self.horizontalGroupBox6)


        #radioButton
        self.horizontalLayout_7 =  QHBoxLayout()
        self.radioButton_p =  QRadioButton(self.frame2)
        self.radioButton_p.setObjectName("radioButton_p")
        self.radioButton_p.setText("Pascal")

        self.horizontalLayout_7 =  QHBoxLayout()
        self.radioButton_f =  QRadioButton(self.frame2)
        self.radioButton_f.setObjectName("radioButton_f")
        self.radioButton_f.setText("fcPascal")

        self.horizontalLayout_7 =  QHBoxLayout()
        self.radioButton_fc =  QRadioButton(self.frame2)
        self.radioButton_fc.setObjectName("radioButton_fc")
        self.radioButton_fc.setText("fcPascal_plusC")

        self.radioButton_b =  QRadioButton(self.frame2)
        self.radioButton_b.setObjectName("radioButton_b")
        self.radioButton_b.setText("Binary")
        self.radioButton_b.setChecked(1)


        self.radioButton_bc =  QRadioButton(self.frame2)
        self.radioButton_bc.setObjectName("radioButton_bc")
        self.radioButton_bc.setText("Binary_plusC")
#        self.radioButton_bc.setChecked(1)

        self.radioButton =  QButtonGroup(self.frame2)

        self.radioButton.addButton(self.radioButton_p,1)
        self.radioButton.addButton(self.radioButton_f,2)
        self.radioButton.addButton(self.radioButton_fc,3)
        self.radioButton.addButton(self.radioButton_b,4)
        self.radioButton.addButton(self.radioButton_bc,5)
        self.horizontalLayout_7.addWidget(self.radioButton_p)
        self.horizontalLayout_7.addWidget(self.radioButton_f)
        self.horizontalLayout_7.addWidget(self.radioButton_fc)
        self.horizontalLayout_7.addWidget(self.radioButton_b)
        self.horizontalLayout_7.addWidget(self.radioButton_bc)

        spacerItem7 =  QSpacerItem(40, 20,  QSizePolicy.Expanding,  QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem6)

        #group TreeType
        self.horizontalGroupBox7 =  QGroupBox('TreeType')
        self.horizontalGroupBox7.setLayout(self.horizontalLayout_7)
        panel2.addWidget(self.horizontalGroupBox7)
        panel2.addWidget(self.horizontalGroupBox6)
        panel2.addWidget(self.horizontalGroupBox5)

        #add frame2 at left-right splitter
        self.splitter.addWidget(self.frame2)
        #set the position of splitter (ratio 1:1)
        self.splitter.setSizes([width/2.0, width/2.0])
        #add splitter totalpanel
        totalpanel.addWidget(self.splitter)
        #add centralWidget at mainwindow
        self.mainWindow.setCentralWidget(self.centralWidget)
        return

    def get_loadButton(self):
        """
        not use
        """
        return self.loadButton
    
    def get_exportButton(self):
        """
        not use
        """
        return self.exportButton

    def get_exitButton(self):
        """
        push Exit
        @rtype: Button
        @return: Exit
        """
        return self.exitButton
    
    def get_caseButton(self):
        """
        not use
        """
        return self.caseButton

    def ending(self):
        """ save windowSize at Exit process"""
        width = self.mainWindow.width()
        height = self.mainWindow.height()
        optDir = os.getenv("OptPlatform")
        fileName = optDir + "/Opt_platform_winSize"
        winSize = str(width) + " " + str(height)
        f = open(fileName, "w"); f.write(winSize); f.close()


    def close(self):
        self.flagThread = "stop"    #thread停止
        self.ending()
        qApp.quit()


class ViewControl():
###class ViewControl( QMainWindow):
    """
    class of manage the display
    """
    #PATH_4_OPENFOAM = "/opt/OpenFOAM/OpenFOAM-v2006"
    #BASHRC_PATH_4_OPENFOAM = PATH_4_OPENFOAM + "/etc/bashrc"
    #MESSAGE_STR = "message"

    def __init__(self, mainWindow):
        """
        defalut setting
        @type mainControl: MainControl
        @param mainControl:
        """
        #self.mainControl = mainControl
        self.mainWindow = mainWindow
        self.patterns = []
        self.currDir = os.getenv("HOME")
        self.commRes = os.getenv("HOME") + "/commRes"
        self.commProc = ""
        self.commStat = "stop"
        self.keyHistoryFile = os.getenv("HOME") + "/.comm_history"
        self.keyCount = 0
        self.checkKeyHistory()



    def showMessageDialog(self, message):
        """
        display Dialog that have message box and OK button
        @type message: string 
        @param message: 
        """
        QMessageBox.information(self.tree_GUIFrame, "Message", message)
        
    

    def ignite(self,  initdir):
        """
        ignite GUI with previous selectDir

        """

        self.dirName = initdir
        self.tree_GUIFrame = Tree_GUIFrame(self.mainWindow)
        self.tree_GUIFrame.GUILayout(self.dirName)

        QObject.connect(self.tree_GUIFrame.exit2Button,  SIGNAL("clicked()"), self.actionOnExitButton)
        QObject.connect(self.tree_GUIFrame.samedirect_execButton,  SIGNAL("clicked()"), self.actionOnsamedirect_execButton)
        QObject.connect(self.tree_GUIFrame.Osamedirect_execButton,  SIGNAL("clicked()"), self.actionOnOsamedirect_execButton)
        QObject.connect(self.tree_GUIFrame.pattern_execButton,  SIGNAL("clicked()"), self.actionOnpattern_execButton)
        QObject.connect(self.tree_GUIFrame.select_execButton,  SIGNAL("clicked()"), self.actionOnselect_execButton)
        QObject.connect(self.tree_GUIFrame.nearbyGrid_execButton,  SIGNAL("clicked()"), self.actionOnnearbyGrid_execButton)
        
        
        QObject.connect(self.tree_GUIFrame.Table_GUIButton,  SIGNAL("clicked()"), self.actionOnTable_GUIButton)
        QObject.connect(self.tree_GUIFrame.eachparam_execButton,  SIGNAL("clicked()"), self.actionOneachparam_execButton)
        QObject.connect(self.tree_GUIFrame.Table_fromloadDirButton,  SIGNAL("clicked()"), self.actionOnTable_fromloadDirButton)

        QObject.connect(self.tree_GUIFrame.radioButton_p,  SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.tree_GUIFrame.radioButton_f,  SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.tree_GUIFrame.radioButton_fc,  SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.tree_GUIFrame.radioButton_b,  SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.tree_GUIFrame.radioButton_bc,  SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.tree_GUIFrame.Div12_Table_GUIButton,  SIGNAL("clicked()"), self.actionOnDiv12_Table_GUIButton)


        #signal setting at tree GUIFrame
        self.tree_GUIFrame.button_run.clicked.connect(self.runCommand)
        self.tree_GUIFrame.textEdit_results.reloadSignal.connect(self.setTextToResult)
        self.tree_GUIFrame.textEdit_log.reloadSignal.connect(self.setTextToLog)
        self.tree_GUIFrame.button_cancel.clicked.connect(self.cancelCommand)
        self.tree_GUIFrame.tree.treeWidget.itemClicked.connect(self.onSelectDir)
        self.tree_GUIFrame.lineEdit_command.keyDownSignal.connect(self.keyDown)
        self.tree_GUIFrame.lineEdit_command.keyUpSignal.connect(self.keyUp)
        self.tree_GUIFrame.lineEdit_command.keyEnterSignal.connect(self.runCommand)
        #connet item with action
        self.tree_GUIFrame.actionOptSearch.triggered.connect(self.onOptSearch)
        self.tree_GUIFrame.actionOptSearchMin.triggered.connect(self.onOptSearchMin)
        self.tree_GUIFrame.actionSub1SearchMax.triggered.connect(self.onSub1SearchMax)
        self.tree_GUIFrame.actionSub2SearchMax.triggered.connect(self.onSub2SearchMax)
        self.tree_GUIFrame.actionSub3SearchMax.triggered.connect(self.onSub3SearchMax)
        self.tree_GUIFrame.actionSub4SearchMax.triggered.connect(self.onSub4SearchMax)
        self.tree_GUIFrame.actionSub1SearchMin.triggered.connect(self.onSub1SearchMin)
        self.tree_GUIFrame.actionSub2SearchMin.triggered.connect(self.onSub2SearchMin)
        self.tree_GUIFrame.actionSub3SearchMin.triggered.connect(self.onSub3SearchMin)
        self.tree_GUIFrame.actionSub4SearchMin.triggered.connect(self.onSub4SearchMin)
        self.tree_GUIFrame.actionbackward.triggered.connect(self.onBackward)
        self.tree_GUIFrame.actionforward.triggered.connect(self.onForward)
        
        
        self.tree_GUIFrame.actionReloadDir.triggered.connect(self.onReloadDir)
        #when double click column of treeWidget
        self.colHeader = self.tree_GUIFrame.tree.treeWidget.header()
        self.mainWindow.connect(self.colHeader,  SIGNAL("sectionDoubleClicked(int)"), self.onColDclick)
        #double click of item of treeWidget
        self.tree_GUIFrame.tree.treeWidget.itemDoubleClicked.connect(self.onTreeItemDclick)
        #threadEnd
        self.tree_GUIFrame.threadEndSignal.connect(self.setEnableButtons)

        #display currDir
        showDir = self.makeString80(selectDir)
        self.tree_GUIFrame.label_currDir.setText("currDir:" + showDir)
        #set cancelButton
        self.tree_GUIFrame.button_cancel.setEnabled(False)

        #ignite thread of log part
        self.runOptlogThread()


    def onSub1SearchMax(self):
        """ search max of sub 4n + 1"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+1])
        except:
            mess = "sub"+ str(4*n+1) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[-1][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+1) + " \n (Maximum) "
        self.okDialog(u"", mess)

    def onSub2SearchMax(self):
        """ search max of sub 4n + 2"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+2])
        except:
            mess = "sub"+ str(4*n+2) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[-1][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+2) + " \n (Maximum) "
        self.okDialog(u"", mess)

    def onSub3SearchMax(self):
        """ search max of sub 4n + 3"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+3])
        except:
            mess =  "sub"+ str(4*n+3) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[-1][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+3) + " \n (Maximum) "
        self.okDialog(u"", mess)

    def onSub4SearchMax(self):
        """ search max of sub 4n + 4"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+4])
        except:
            mess =  "sub"+ str(4*n+4) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[-1][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+4) + " \n (Maximum) "
        self.okDialog(u"", mess)

    def onSub1SearchMin(self):
        """ search min of sub 4n + 1"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+1])
        except:
            mess =  "sub"+ str(4*n+1) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[0][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+1) + " \n (Minimum) "
        self.okDialog(u"", mess)

    def onSub2SearchMin(self):
        """ search min of sub 4n + 2"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+2])
        except:
            mess = "sub"+ str(4*n+2) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[0][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+2) + " \n (Minimum) "
        self.okDialog(u"", mess)

    def onSub3SearchMin(self):
        """ search min of sub 4n + 3"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+3])
        except:
            mess = "sub"+ str(4*n+3) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[0][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+3) + " \n (Minimum) "
        self.okDialog(u"", mess)

    def onSub4SearchMin(self):
        """ search min of sub 4n + 4"""
        treeWidget = self.tree_GUIFrame.tree
        n = treeWidget.glob_quadindex
        items = self.optSearchItems()
        try:
            items.sort(key=lambda x: x[1][4*n+4])
        except:
            mess = "sub"+ str(4*n+4) + " data not exists"
            self.errDialog(u"error", mess)
            return
        maxDir = items[0][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = "selected node is the best sub" + str(4*n+4) + " \n (Minimum) "
        self.okDialog(u"", mess)

    def onBackward(self):
        treeWidget = self.tree_GUIFrame.tree
        if treeWidget.glob_quadindex > 0:
            treeWidget.glob_quadindex = treeWidget.glob_quadindex -1
        else:
            treeWidget.glob_quadindex = 0
        #treeを再表示
        self.tree_GUIFrame.tree.sortScoreFlag = "yes"
        self.tree_GUIFrame.tree.sortCoeff = 1.0    #1:ascend、-1:descend
        self.tree_GUIFrame.tree.sortColNo = 1      #the index of sort-row
        n = treeWidget.glob_quadindex
        headers = ["directory", "score", "sub"+str(4*n+1), "sub"+str(4*n+2), "sub"+str(4*n+3), "sub"+str(4*n+4), "stat","nValley" , "note", "nChild"]
        self.tree_GUIFrame.tree.headers = headers
        self.tree_GUIFrame.tree.createTreeWidget()
        self.tree_GUIFrame.tree.reloadFolders()
        return

    def onForward(self):
        treeWidget = self.tree_GUIFrame.tree
        if treeWidget.glob_quadindex < 64:
            treeWidget.glob_quadindex = treeWidget.glob_quadindex +1
        else:
            treeWidget.glob_quadindex = 64
        #treeを再表示
        self.tree_GUIFrame.tree.sortScoreFlag = "yes"
        self.tree_GUIFrame.tree.sortCoeff = 1.0    #1:ascend、-1:descend
        self.tree_GUIFrame.tree.sortColNo = 1      #the index of sort-row
        n = treeWidget.glob_quadindex
        headers = ["directory", "score", "sub"+str(4*n+1), "sub"+str(4*n+2), "sub"+str(4*n+3), "sub"+str(4*n+4), "stat","nValley" , "note", "nChild"]
        self.tree_GUIFrame.tree.headers = headers
        self.tree_GUIFrame.tree.createTreeWidget()
        self.tree_GUIFrame.tree.reloadFolders()
        return


    def onReloadDir(self):
        """ reload directory """
        self.tree_GUIFrame.tree.reloadFolders()
        print("Directories were reloaded.")

    def onOptSearchMin(self):
        """ search min of score"""
        items = self.optSearchItems()
        minDir = items[0][0]
        self.tree_GUIFrame.tree.selectDir(minDir)
        mess = u"selected node is the best score \n (Minimum) "
        self.okDialog(u"best score", mess)

    def onOptSearch(self):
        """ scoresearch max of score"""
        items = self.optSearchItems()
        maxDir = items[-1][0]
        self.tree_GUIFrame.tree.selectDir(maxDir)
        mess = u"selected node is the best score \n (Maximum) "
        self.okDialog(u"best score", mess)

    def optSearchItems(self):
        """return the list of dir and score dir """
        selItems = self.tree_GUIFrame.tree.getSelectedItems() 
        currDir = self.tree_GUIFrame.tree.getDirFromItem(selItems[0])
        folderName = currDir.split("/")[-1]
        if folderName[:len("div")] != "div":
            mess = u"selected directory \n is not target of analysis "
            self.okDialog(u" error ", mess)
            return
        dirList = currDir.split("/")
        for i in range(len(dirList)):
            if dirList[i][:len("div")] == "div":
                startDir = "/".join(dirList[:i+1])
                break
        optDict = {}
        for currDir, _dirs, _files in os.walk(startDir):
            if currDir.split("/")[-1][:len("div")] == "div":
                if os.path.exists(currDir + "/score.csv") == True:
                    f = open(currDir + "/score.csv"); cont = f.read(); f.close()
                    #score = float(cont.split(",")[0])
                    score = list(map(float, cont.split(",")))
                    optDict[currDir] = score
        items = list(optDict.items())
        #items.sort(key=lambda x: x[1])
        items.sort(key=lambda x: x[1][0])
        return items

    def onTreeItemDclick(self, item, colNo):
        """opne selected Dir"""
        currDir = self.tree_GUIFrame.tree.getDirFromItem(item)
        comm = "nautilus '" + currDir + "' &"
        os.system(comm)

    def onColDclick(self, event):
        """change the sort item or direction"""
        treeWidget = self.tree_GUIFrame.tree
        hcol = event        #get colNo of colHeaderの
        #find the position of doubleClick
        if hcol == 0:
            #treeDiectoryをDClick
            if treeWidget.sortScoreFlag == "yes":
                treeWidget.sortScoreFlag = "no"
            else:
                treeWidget.sortScoreFlag = "yes"
            treeWidget.sortColNo = 0
        else:
            #DClick the score
            treeWidget.sortScoreFlag = "yes"
            if treeWidget.sortColNo != hcol:
                #when change the position of Dclic
                treeWidget.sortColNo = hcol
                treeWidget.sortCoeff = 1.0
            else:
                #if the position of Dclick is same, inverse
                if treeWidget.sortCoeff == 1.0:
                    treeWidget.sortCoeff = -1.0
                else:
                    treeWidget.sortCoeff = 1.0
                    
        #reload tree
        self.tree_GUIFrame.tree.createTreeWidget()
        self.tree_GUIFrame.tree.reloadFolders()
        return


    def keyDown(self):
        f = open(self.keyHistoryFile); cont = f.read(); f.close()
        #words = cont.split()
        words = cont.split("\n")[:-1]
        self.keyCount += 1
        if self.keyCount < len(words):
            comm = words[self.keyCount]
        else:
            comm = ""
            self.keyCount = len(words)
        self.tree_GUIFrame.lineEdit_command.setText(comm)

    def keyUp(self):
        f = open(self.keyHistoryFile); cont = f.read(); f.close()
        #words = cont.split()
        words = cont.split("\n")[:-1]
        self.keyCount -= 1
        if self.keyCount < 0:
            comm = words[0]
            self.keyCount += 1
        else:
            comm = words[self.keyCount]
        self.tree_GUIFrame.lineEdit_command.setText(comm)

    def checkKeyHistory(self):
        if os.path.exists(self.keyHistoryFile) == False:
            f = open(self.keyHistoryFile, "w"); f.close()
            self.keyCount = 0
        else:
            f = open(self.keyHistoryFile); cont = f.read(); f.close()
            words = cont.split("\n")[:-1]
            if len(words) > 100:
                words = words[:100]
                cont = "\n".join(words) + "\n"
                f = open(self.keyHistoryFile, "w"); f.write(cont); f.close()
            self.keyCount = len(words)


    def onSelectDir(self, selItem, col):
        """select item of tree,file of "selectDir updated"""
        self.currDir = self.tree_GUIFrame.tree.getDirFromItem(selItem)
        #shorten the characters at most 80 at currDir
        showDir = self.makeString80(self.currDir)
        # nMax = 80
        # if len(self.currDir) > nMax:
        #     showDir = "..." + self.currDir[:-(nMax-3)]
        # else:
        #     showDir = self.currDir
        self.tree_GUIFrame.label_currDir.setText("currDir:" + showDir)
        selectDirName = os.getenv("OptPlatform") + "/selectDir"
        f = open(selectDirName, "w")
        f.write(self.currDir)
        f.close()

    def makeString80(self, line):
        if len(line) > 80:
            line = " ..." + line[-80:]
        return line

    def setTextToResult(self, line):
        """ Output the line to the display part"""
        self.tree_GUIFrame.textEdit_results.append(line)

    def setTextToLog(self, line):
        """output the line to the log display part"""
        self.tree_GUIFrame.textEdit_log.append(line)

    def runCommand(self):
        """excute command"""
        #delete commRes
        if os.path.exists(self.commRes):
           os.remove(self.commRes)
        #get command
        command = str(self.tree_GUIFrame.lineEdit_command.text())
        #comm = "cd " + self.currDir + "; " + command + " > " + self.commRes + " 2>&1 ; echo end >> " + self.commRes + ""
        comm = "cd '" + self.currDir + "'; " + command + " > '" + self.commRes + "' 2>&1 ; echo end >> '" + self.commRes + "'"
        #excute command
        self.commProc = subprocess.Popen(
            comm,
            shell = True,
            stdout = subprocess.PIPE,
            stderr = subprocess.PIPE,
            preexec_fn = os.setsid )
        #add command to history
        try:
            f = open(self.keyHistoryFile); cont = f.read(); f.close()
            words = cont.split("\n")[:-1]
            if command != words[-1]:
                f = open(self.keyHistoryFile, "a"); f.write(command+"\n"); f.close()
                self.keyCount += 1
        except:
            f = open(self.keyHistoryFile, "w"); f.write(command+"\n"); f.close()            
        #wait until commResFile completed
        while os.path.exists(self.commRes) == False:
            time.sleep(0.1)
        #clear output part
        self.tree_GUIFrame.textEdit_results.clear()
        #set the input part and button inactive
        self.tree_GUIFrame.lineEdit_command.setEnabled(False)
        self.tree_GUIFrame.button_cancel.setEnabled(True)
        self.tree_GUIFrame.button_run.setEnabled(False)
        self.commStat = "run"
        #get the result
        th = threading.Thread(target=self.getCommResult)
        th.start()

    def getCommResult(self):
        """get the resut of command commandの出力結果を取得する。
        command is excuted as thread, so dont access normaly
        if access the thread, make event and access in the event.
        """
        #get the output of subprocess realTime
        f = open(self.commRes)
        line = ""
        while (line != "end\n" and 
                self.commStat == "run" and 
                self.tree_GUIFrame.flagThread == "run"):
            line = f.readline()
            if line != "end\n" and line != "":
                #line = line.decode("utf-8")
                if line[-1] == "\n":
                    line = line[:-1]
                self.tree_GUIFrame.textEdit_results.reloadSignal.emit(line)
            elif line == "":
                time.sleep(0.1)
        line = "---command finished---"
        self.commStat = "stop"
        self.tree_GUIFrame.textEdit_results.reloadSignal.emit(line)
        #set each button as active
        self.tree_GUIFrame.threadEndSignal.emit()

    def setEnableButtons(self):
        """set each button as active"""
        self.tree_GUIFrame.lineEdit_command.setEnabled(True)
        self.tree_GUIFrame.button_cancel.setEnabled(False)
        self.tree_GUIFrame.button_run.setEnabled(True)


    def cancelCommand(self):
        """suspend the command"""
        if self.commStat == "run":
            os.killpg(os.getpgid(self.commProc.pid), signal.SIGTERM)
            self.commStat = "stop"

        
    def actionOnExitButton(self):
        """
        when Exit button
        @type event:Event 
        @param event: mouse clock 
        """
        #print("actionOnExitButton()")
        #message = _('Will you exit?')
        message = ('Will you exit?')
        ret =  QMessageBox.question(None, "My message", message,  QMessageBox.Yes,  QMessageBox.No)      
        if ret ==  QMessageBox.Yes:
                self.tree_GUIFrame.close()
        elif ret ==  QMessageBox.No:
                return
        
    def searchset_projDirselectDir(self,selectDir):
        if os.path.basename(selectDir)=="SourceCase":
            words = selectDir.split("/")
            projDir = "/".join(words[:len(words)-1])
            return projDir, selectDir 

        words = selectDir.split("/")
        for i in range(len(words)):
            name = words[len(words)-i-1]
            if name[:len("layer")] == "layer":
                projDir = "/".join(words[:len(words)-i-1])
                try:
                    f=open(selectDir + "/path2instance.csv")
                    selectDir = projDir + "/" + f.read()
                    f.close()
                    return projDir,selectDir
                except:
                    print("path2inscance.csv not found")
                    return None, None

            if name[:len("div2_")] == "div2_":
                projDir = "/".join(words[:len(words)-i-1])
                return projDir,selectDir
        return None, None


    def actionOnpattern_execButton(self):
        global nProcs

        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        projDir, selectDir = self.searchset_projDirselectDir(selectDir)
        print("projDir: " + projDir)

        platformDir = os.getcwd()

        onlyCsv = str(int(self.tree_GUIFrame.checkBox1.checkState()))
        lcg_flag = str(int(self.tree_GUIFrame.checkBox0.checkState()))
        lcg_constant = self.tree_GUIFrame.typeComboBox3.currentText()

        PatternCode = self.tree_GUIFrame.typeComboBox2.currentText()
        logging.debug(PatternCode)

        nProcs = int(self.tree_GUIFrame.nOutParallel.text())

##########################################nPpu_perCase(inner parallel number) send to Excuter but not implemented############################################################
        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
               + onlyCsv +  " " + TreeType +  " " + PatternCode + " " + lcg_flag +  " " + lcg_constant  +  " pattern_exec" + " &")
#        comm += "python target.py" + " " + str(1) + " " + str(1) + " " + selectDir + " " + sourceDir + " " + platformDir + " " + onlyCsv + " &"
#        comm += "python target.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " " + selectDir + " " + sourceDir + " " + platformDir + " " + onlyCsv + " &"

        os.system(comm)


    def actionOneachparam_execButton(self):
        global nProcs
        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        platformDir = os.getcwd()
        onlyCsv = str(int(self.tree_GUIFrame.checkBox1.checkState()))
        lcg_flag = str(int(self.tree_GUIFrame.checkBox0.checkState()))
        lcg_constant = self.tree_GUIFrame.typeComboBox3.currentText()

        PatternCode = self.tree_GUIFrame.typeComboBox2.currentText()

        projDir, selectDir = self.searchset_projDirselectDir(selectDir)

        parentDir = "/".join(selectDir.split("/")[:-1])
        parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
        myself_div,myself_list = CommonUtil.divname2num(os.path.basename(selectDir))

        if (parent_div+1==myself_div):
            exTreeType = "Pascal"
        elif (parent_div*2==myself_div) and TreeType=="Binary_plusC":
            exTreeType = "Binary_plusC"
        elif (parent_div*2==myself_div):
            exTreeType = "Binary"

            
        elif ( parent_div%3==0 and myself_div== (parent_div//3)*4 ) or ( parent_div%3!=0 and myself_div==(parent_div//2)*3 ) and TreeType=="fcPascal_plusC":
             exTreeType = "fcPascal_plusC"

        elif ( parent_div%3==0 and myself_div== (parent_div//3)*4 ) or ( parent_div%3!=0 and myself_div==(parent_div//2)*3 ) :
             exTreeType = "fcPascal"

        else:
            logging.debug("selectDir can't be traced the direction")
            return

        logging.debug(exTreeType)

        logging.debug("projDir: " + projDir)

        logging.debug(selectDir)
        nProcs = int(self.tree_GUIFrame.nOutParallel.text())
##########################################nPpu_perCase(inner parallel number) send to Excuter but not implemented###################################################################
        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
                 + onlyCsv +  " " + exTreeType +  " " + PatternCode + " " + lcg_flag +  " " + lcg_constant  + " eachparam_exec" + " &")

        os.system(comm)


    def actionOnsamedirect_execButton(self):

        global nProcs

        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        platformDir = os.getcwd()
        onlyCsv = str(int(self.tree_GUIFrame.checkBox1.checkState()))
        lcg_flag = str(int(self.tree_GUIFrame.checkBox0.checkState()))
        lcg_constant = self.tree_GUIFrame.typeComboBox3.currentText()

        PatternCode = self.tree_GUIFrame.typeComboBox2.currentText()


        projDir,selectDir = self.searchset_projDirselectDir(selectDir)
        logging.debug("projDir: " + projDir)
        logging.debug(selectDir)
        
        parentDir = "/".join(selectDir.split("/")[:-1])
        parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
        myself_div,myself_list = CommonUtil.divname2num(os.path.basename(selectDir))
        exTreeType=""

        if (parent_div+1==myself_div):
            exTreeType = "Pascal"
        elif (parent_div*2==myself_div):
            exTreeType = "Binary_plusC"
        elif (parent_div*2 > myself_div) and (parent_div+1 < myself_div):
            exTreeType = "fcPascal"
        else:
            print("selectDir can't be traced the direction")

        logging.debug(exTreeType)        
        
        
        nProcs = int(self.tree_GUIFrame.nOutParallel.text())
##########################################nPpu_perCase(inner parallel number) send to Excuter but not implemented###################################################################
#        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
#                + onlyCsv +  " " + exTreeType +  " " + PatternCode +  " " + lcg_flag +  " " + lcg_constant + " samedirect_exec" + " &")

        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
                + onlyCsv +  " " + TreeType +  " " + PatternCode +  " " + lcg_flag +  " " + lcg_constant + " samedirect_exec" + " &")


        os.system(comm)
        #print("calculate done")


    def actionOnOsamedirect_execButton(self):

        global nProcs

        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        platformDir = os.getcwd()
        onlyCsv = str(int(self.tree_GUIFrame.checkBox1.checkState()))
        lcg_flag = str(int(self.tree_GUIFrame.checkBox0.checkState()))
        lcg_constant = self.tree_GUIFrame.typeComboBox3.currentText()

        PatternCode = self.tree_GUIFrame.typeComboBox2.currentText()


        projDir,selectDir = self.searchset_projDirselectDir(selectDir)
        logging.debug("projDir: " + projDir)
        logging.debug(selectDir)
        
        parentDir = "/".join(selectDir.split("/")[:-1])
        parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
        myself_div,myself_list = CommonUtil.divname2num(os.path.basename(selectDir))
        exTreeType=""

        if (parent_div+1==myself_div):
            exTreeType = "Pascal"
        elif (parent_div*2==myself_div):
            exTreeType = "Binary_plusC"
        elif (parent_div*2 > myself_div) and (parent_div+1 < myself_div):
            exTreeType = "fcPascal"
        else:
            print("selectDir can't be traced the direction")

        logging.debug(exTreeType)        
        
        
        nProcs = int(self.tree_GUIFrame.nOutParallel.text())
##########################################nPpu_perCase(inner parallel number) send to Excuter but not implemented###################################################################
#        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
#                + onlyCsv +  " " + exTreeType +  " " + PatternCode +  " " + lcg_flag +  " " + lcg_constant + " Osamedirect_exec" + " &")

        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
                + onlyCsv +  " " + TreeType +  " " + PatternCode +  " " + lcg_flag +  " " + lcg_constant + " Osamedirect_exec" + " &")


        os.system(comm)
        #print("calculate done")






    def actionOnselect_execButton(self):
        global nProcs

        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        platformDir = os.getcwd()
        onlyCsv = str(int(self.tree_GUIFrame.checkBox1.checkState()))
        lcg_flag = str(int(self.tree_GUIFrame.checkBox0.checkState()))
        lcg_constant = self.tree_GUIFrame.typeComboBox3.currentText()

        PatternCode = self.tree_GUIFrame.typeComboBox2.currentText()

        projDir, selectDir = self.searchset_projDirselectDir(selectDir)
        logging.debug("projDir: " + projDir)

        logging.debug(selectDir)
        nProcs = int(self.tree_GUIFrame.nOutParallel.text())
##########################################nPpu_perCase(inner parallel number) send to Excuter but not implemented###################################################################
        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
                + onlyCsv +  " " + TreeType +  " " + PatternCode +  " " + lcg_flag +  " " + lcg_constant  + " select_exec" + " &")

        os.system(comm)

        #print("calculate done")



    def actionOnnearbyGrid_execButton(self):
        global nProcs
        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        platformDir = os.getcwd()
        onlyCsv = str(int(self.tree_GUIFrame.checkBox1.checkState()))
        lcg_flag = str(int(self.tree_GUIFrame.checkBox0.checkState()))
        lcg_constant = self.tree_GUIFrame.typeComboBox3.currentText()

        PatternCode = self.tree_GUIFrame.typeComboBox2.currentText()

        projDir, selectDir = self.searchset_projDirselectDir(selectDir)

        parentDir = "/".join(selectDir.split("/")[:-1])
        parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
        myself_div,myself_list = CommonUtil.divname2num(os.path.basename(selectDir))


        fixTreeType = "fcPascal"


        logging.debug("projDir: " + projDir)

        logging.debug(selectDir)
        nProcs = int(self.tree_GUIFrame.nOutParallel.text())
##########################################nPpu_perCase(inner parallel number) send to Excuter but not implemented###################################################################
        comm = ("python3 -u Executor_Tree.py" + " " + str(nProcs) + " " + str(nCpu_perCase) + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' " 
                 + onlyCsv +  " " + fixTreeType +  " " + PatternCode + " " + lcg_flag +  " " + lcg_constant  + " nearbyGrid_exec" + " &")

        os.system(comm)









    def okCancelDialog(self, title, mess):
        #msgBox =  QMessageBox()
        #res = msgBox.information( QDialog(), title, mess, msgBox.Cancel, msgBox.Ok)
        msgBox =  QMessageBox()
        res = msgBox.information( QDialog(), title, mess, msgBox.Cancel, msgBox.Ok)
        if res == msgBox.Ok:
            ans = "OK"
        else:
            ans = "CANCEL"
        return ans

    def okDialog(self, title, mess):
        msgBox =  QMessageBox()
        msgBox.information( QDialog(), title, mess, msgBox.Ok)

    def errDialog(self, title, mess):
        msgBox =  QMessageBox()
        msgBox.critical( QDialog(), title, mess, msgBox.Ok)



    def actionOnViewMeshButton(self):
        """
        not use
        """
        logging.debug("ViewMesh")


    # def isRunningTableGui(self):
    #     """ """
    #     return os.path.exists(flagTableGui)

    def actionOnTable_GUIButton(self):
        """ ignite TableGUI"""
        #
        # if self.isRunningTableGui() == True:
        #     title = "run TableGUI"
        #     mess = "TableGUI is already running.\n"
        #     mess += "could not run TableGUI."
        #     self.errDialog(title, mess)
        #     return

        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        projDir, selectDir = self.searchset_projDirselectDir(selectDir)
        platformDir = os.getcwd()

        #comm = ("python3 -u Table_GUI.py '" + selectDir +  "' '" + platformDir
        #      + "' None 2>&1 | tee " + LogTableGui + " &")
        comm = ("python3 -u Table_GUI.py '" + selectDir +  "' '" + platformDir
              + "' None  &")
        os.system(comm)

        #app = Table_GUI.gridTable(rowLabels, colLabels, colData1)
        #app = Table_GUI.gridTable([""], [""], colData1)
        #app.main()

    # def isRunningTableGuiLoad(self):
    #     return os.path.exists(flagTableGuiLoad)

    def actionOnTable_fromloadDirButton(self):
        """check of  TableGUI_fromLoadDir"""

        #
        # if self.isRunningTableGuiLoad() == True:
        #     title = "run TableGUI_fromLoadDir"
        #     mess = "TableGUI_fromLoadDir is already running.\n"
        #     mess += "could not run TableGUI_fromLoadDir."
        #     self.errDialog(title, mess)
        #     return

        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        projDir, selectDir = self.searchset_projDirselectDir(selectDir)
        parentDir = "/".join(selectDir.split("/")[:-1])

        platformDir = os.getcwd()
#20201109edit

#        self.selectDir(selDir)

        self.tree_GUIFrame.tree.selectDir(parentDir)
        selItems = self.tree_GUIFrame.tree.getSelectedItems() 
        currDir = self.tree_GUIFrame.tree.getDirFromItem(selItems[0])
        selectDirName = os.getenv("OptPlatform") + "/selectDir"
        f = open(selectDirName, "w")
        f.write(currDir)
        f.close()
#20201109edit

        #comm = ("python3 -u Table_GUI.py '" + parentDir +  "' '" + platformDir
        #      + "' '" + selectDir + "' 2>&1 | tee " + LogTableGuiLoad + " &")
        comm = ("python3 -u Table_GUI.py '" + parentDir +  "' '" + platformDir
              + "' '" + selectDir + "' &")
        os.system(comm)


    def actionOnDiv12_Table_GUIButton(self):
        """check of  TableGUI_fromLoadDir"""

        #
        # if self.isRunningTableGuiLoad() == True:
        #     title = "run TableGUI_fromLoadDir"
        #     mess = "TableGUI_fromLoadDir is already running.\n"
        #     mess += "could not run TableGUI_fromLoadDir."
        #     self.errDialog(title, mess)
        #     return

        items = self.tree_GUIFrame.tree.treeWidget.selectedItems()
        selectDir = self.tree_GUIFrame.tree.getDirFromItem(items[0])

        projDir, selectDir = self.searchset_projDirselectDir(selectDir)
        #parentDir = "/".join(selectDir.split("/")[:-1])
        #need layer item case
        
        baseDir = "Temp"
        words = selectDir.split("/")
        for i in range(len(words)):
            name = words[len(words)-i-1]

            if name[:len("div4_")] == "div4_" or name[:len("div3_")] == "div3_":
            
                #20221016adjust
                baseDir = "/".join(words[:len(words)-i])
                break
        if baseDir == "Temp":
            print("not appropriate node as Div12table ignite")
            return



        platformDir = os.getcwd()
#20201109edit
#        self.selectDir(selDir)

        self.tree_GUIFrame.tree.selectDir(baseDir)
        selItems = self.tree_GUIFrame.tree.getSelectedItems() 
        currDir = self.tree_GUIFrame.tree.getDirFromItem(selItems[0])
        selectDirName = os.getenv("OptPlatform") + "/selectDir"
        f = open(selectDirName, "w")
        f.write(currDir)
        f.close()
#20201109edit


#20221030edit
        selectDir_name = os.path.basename(selectDir)
        #parentDir_name = os.path.basename(parentDir)

        Dividor, pre_loadDir = CommonUtil.divname2num(selectDir_name)
        #parent_div, parent_list = CommonUtil.divname2num(parentDir_name)

        loadDir = []
        #loadDir = CommonUtil.direction_decode2str(learnDir, init_loadDir)
        #Dividor , pre_loadDir = CommonUtil.divname2num(init_loadDir.split("/")[-1])
        if Dividor == 4 or Dividor == 6 or Dividor == 12:
            loadDir = [(n*12//Dividor) for n in pre_loadDir]
        #else:
            #Dividor , pre_loadDir = CommonUtil.divname2num(learnDir.split("/")[-1])
            #if Dividor == 4:
                #loadDir = [str(n*12//Dividor) for n in pre_loadDir]
            #else:
                #print("loadDir,learnDir not intended name, So set defaut value (6,Center)")
                #loadDir=["6"] * (len(rowLabels)-1)

        loadDir_name = CommonUtil.num2divname(12, loadDir)

        if os.path.exists(selectDir +  "/" + "score.csv")==True and not os.path.exists(baseDir + "'/" + loadDir_name):
            comm = "mkdir '" + baseDir + "'/" + loadDir_name
            os.system(comm)
            comm = "cp '" + selectDir + "'/score.csv" + " '" + baseDir + "'/" + loadDir_name
            os.system(comm)
#20221030edit


        #comm = ("python3 -u Table_GUI.py '" + parentDir +  "' '" + platformDir
        #      + "' '" + selectDir + "' 2>&1 | tee " + LogTableGuiLoad + " &")
        comm = ("python3 -u Abs_Table_GUI.py '" + baseDir +  "' '" + platformDir
              + "' '" + selectDir + "' &")
        os.system(comm)







    def actionOnTreeRadioButton(self):
        """
        radioButton
        """
        global TreeType

        if self.tree_GUIFrame.radioButton_p.isChecked() == True :
            TreeType = "Pascal"
        else:
            pass

        if self.tree_GUIFrame.radioButton_f.isChecked() == True :
            TreeType = "fcPascal"
        else:
            pass

        if self.tree_GUIFrame.radioButton_fc.isChecked() == True :
            TreeType = "fcPascal_plusC"
        else:
            pass

        if self.tree_GUIFrame.radioButton_b.isChecked() == True :
            TreeType = "Binary"
        else :
            pass

        if self.tree_GUIFrame.radioButton_bc.isChecked() == True :
            TreeType = "Binary_plusC"
        else :
            pass


    #
    #  runOptlogThead
    #-----------------
    def runOptlogThread(self):
        """
        read the content of logFile and ignite thread logFile
        """
        th = threading.Thread(target=self.getOptlog)
        self.tree_GUIFrame.flagThread = "run"
        th.start()

    def getOptlog(self):
        f = open(LogFile)
        lines = f.read()    #latch
        while self.tree_GUIFrame.flagThread == "run":
            line = f.readline()
            if line != "":
                if line[-1] == "\n":
                    line = line[:-1]
                self.tree_GUIFrame.textEdit_log.reloadSignal.emit(line)
            else:
                time.sleep(0.1)

#
#  commandReturnCont
#--------------------
def commandReturnCont(comm, isOut=True):
    """excute command get the result 
    
    Args:
        comm (str)  :command
        isOut (bool):also output standar-dOut（default=True)
    Returns:
        stat (str)      :"OK" or "ERROR"
        resCont (str)   :result of excute
        errCont (str) ) :content of error"""
    #command excute
    results = []
    #os.chdir(self.caseDir)
    proc = subprocess.Popen(
        comm,
        shell=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE )
    #get the result at readline and output
    for line in iter(proc.stdout.readline, b""):
        resLine = line.rstrip().decode("utf-8")
        results.append(resLine)
        if isOut == True:
            print(resLine)
    #recognize the result of excute
    errCont = proc.stderr.read().decode("utf-8")
    resCont = "\n".join(results) + "\n"
    if errCont == "":
        stat = "OK"
    else:
        if isOut == True:
            print(errCont)
        stat = "ERROR"
    return (stat, resCont, errCont)

#
#  isRunningOpt
#----------------
def isRunningOpt():
    """ find whether OptPlatform is ignited or not"""
    #comm = 'pgrep -l " " -f "Tree_GUI.py"'
    comm = 'pgrep -l -f "Tree_GUI.py"'
    print(comm)
    results = commandReturnCont(comm, False)
    print("".join(results[1:]))
    flag = False
    if len(results) >= 2:
        resCont = results[1]
        lines = resCont[:-1].split("\n")
        pids = list(map(lambda x: x.split()[0], lines))
        #print("running OptPlatform PID ---> ", resCont, end="")
        print("running OptPlatform PID ---> ", " ".join(pids))
        #if len(resCont.split()) > 1:
        if len(pids) > 1:
            print("Tree_GUI is already running.")
            flag = False
    return flag

#
#  writeStartingFile
#--------------------
def writeStartingFile(cont):
    """ output to startingFile"""
    comm = "echo '" + cont + "' >> " + os.getenv("startingFile")
    os.system(comm)

#
#  initialize
#--------------
def initStartingDialog():
    """ initilization"""
    global Version
    #write version
    f = open(os.getenv("OptPlatform") + "/version", "w")
    f.write(Version); f.close()
    #make startingFile or initialization
    fileName = os.getenv("startingFile")
    comm = "echo 'starting OptParaSol...' > " + fileName
    os.system(comm)


#=============
#  main
#=============
def main():
    """
    main method
    """
    global refinementOption, selectDir
    
    #recogniza the state of Opt
    if isRunningOpt() == True:
        #stop when ignite
        exit()
    
    #initialization
    initStartingDialog()

    refinementOption = 1

    app =  QApplication([])
    
    mainWindow =  QMainWindow()

    #cfMeshSettingMainControl = MainControl()
    #cfMeshSettingMainControl.setupView()
    #ignite=ViewControl(mainWindow)
    #ignite.ignition(os.environ['HOME'])

    #read the selectDir
    selectDir = os.getenv("HOME")
    optDir = os.getenv("OptPlatform")
    fileName = optDir + "/selectDir"
    if os.path.exists(fileName):
        f = open(fileName); selDir = f.read(); f.close()
        if os.path.exists(selDir):
            selectDir = selDir

    #output the state of ignition
    writeStartingFile("reading directory...")

    viewCon = ViewControl(mainWindow)
    #viewCon.ignite(os.environ['HOME'])
    viewCon.ignite(selectDir)

    mainWindow.show()

    #Final message
    writeStartingFile("Welcome to OptParaSol !!")
    #close startingDialog
    writeStartingFile("close")

    app.exec_()

if __name__ == '__main__':
    """
     start point of this software
    """
    selectDir = ""
    main()

