#!/usr/bin/python3
#  coding:  utf-8
#
"""
Opt_platform.py
Copyright (C) 2020 Shigeki Fujii, Tsunehiro Watanabe all rights reserved.

This software is released under the MIT License.
http://opensource.org/licenses/mit-license.php
"""

import logging
logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)


#from PySide import QtCore, QtGui
#from PySide.QtGui import *
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from functools import partial
from decimal import Decimal
import sys
import os.path
import gettext
import tempfile
import math
import subprocess
from subprocess import Popen
import shutil
import glob
import threading

import re

import copy
import CommonUtil
import ExecUtil


#import Table_GUI

import multiprocessing
import time
import csv
import six

#dialog表示の為、定義
app = QApplication([])

dialogApp = ""

def showDialog():
    """ messagetDialogを表示させる"""
    global dialogApp
    comm = "python3 messageDialogApp.py"
    dialogApp = subprocess.Popen(comm, shell=True, stdin=subprocess.PIPE)

def closeDialog():
    """ dilogを閉じる"""
    global dialogApp
    dialogApp.stdin.write(b"close\n")
    dialogApp.kill()



def okCancelDialog(title, mess,excerpt_lists):

    class messageDialog:

        def __init__(self, title, mess,excerpt_lists):
            self.title = title
            self.mess = mess
            self.excerpt_lists = excerpt_lists
            self.status = "CANCEL"

        def setupDialog(self,object):
            Dialog.setObjectName("Dialog")
            self.dialog = Dialog
            self.verticalLayout = QVBoxLayout(Dialog)
            #label
            self.label = QLabel(Dialog)
            self.label.setText(self.mess)
            self.verticalLayout.addWidget(self.label)

            self.horizontalLayout = QHBoxLayout()

#            spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
#            self.horizontalLayout.addItem(spacerItem)

            #cancelButton
            self.pushButtonCancel = QPushButton(Dialog)
            self.pushButtonCancel.setText(u"Cancel")
            self.horizontalLayout.addWidget(self.pushButtonCancel)
            #OKbutton
            self.pushButtonOk = QPushButton(Dialog)
            self.pushButtonOk.setText(u"OK")
            self.horizontalLayout.addWidget(self.pushButtonOk)

            spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
            self.horizontalLayout.addItem(spacerItem)

            self.verticalLayout.addLayout(self.horizontalLayout)

            #excerpt_lists
#            self.below = QLabel(Dialog)
            self.below = QTextEdit(Dialog)
            self.below.setText(self.excerpt_lists)
            self.verticalLayout.addWidget(self.below)

            QMetaObject.connectSlotsByName(Dialog)
            self.pushButtonCancel.clicked.connect(self.onCancel)
            self.pushButtonOk.clicked.connect(self.onOk)

        def close(self, *args):
            self.dialog.close()

        def onCancel(self):
            self.status = "CANCEL"
            self.close()

        def onOk(self):
            self.status = "OK"
            self.close()

    #app = QApplication([])
    Dialog = QDialog()
    ui = messageDialog(title, mess,excerpt_lists)
    ui.setupDialog(Dialog)
    Dialog.show()
    
    app.exec_()
    return ui.status




def makestartnode():

    f = open(projDir + "/param_boundary.csv"); lines = f.readlines(); f.close()
#    upperx = map(float, lines[0].replace(" ", "").split(","))
#    lowerx = map(float, lines[1].replace(" ", "").split(","))

    upperx = list(map(float, lines[0].replace(" ", "").split(",")))
    lowerx = list(map(float, lines[1].replace(" ", "").split(",")))



    param_string = "1" * len(upperx)

    startnode = projDir + "/div2_"+ param_string

    print(startnode)
    if not os.path.exists(startnode):
        #comm = "mkdir "+ startnode
        os.mkdir(startnode)

    prejob_lists=[]
    job_lists=[]



    p_list= [1] * len(upperx)
    prejob_lists.append(p_list)
    parentDir = "/".join(selectDir.split("/")[:-1])

    stat = showJobNumDialog(parentDir, 2, prejob_lists)
    if stat != "OK":
        return

    showDialog()

    param_string = "2" * len(upperx)

    inherit_node = startnode + "/div4_"+ param_string

    if not os.path.exists(inherit_node):
        comm = "mkdir "+ inherit_node
        os.system(comm)



    caseDirs = ExecUtil.createCaseDirs(projDir, projDir, prejob_lists, 2)


    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    time.sleep(0.01)

    if os.path.exists(startnode + "/score.csv") and os.path.exists(inherit_node) and not(os.path.exists(inherit_node+"/score.csv")):
        comm = "cp '" + startnode + "/score.csv" + "' " + inherit_node
        print(comm)
        os.system(comm)
        print(startnode)
        print(inherit_node)
        print("score copied to div4")
    #dialogを閉じる
    closeDialog()


def pattern_exec():

    selectDir_name = os.path.basename(selectDir)
    parentDir = "/".join(selectDir.split("/")[:-1])
    parentDir_name = os.path.basename(parentDir)



    logging.debug(selectDir_name)

    if selectDir_name=="SourceCase":
        logging.debug(selectDir_name)
        makestartnode()
        return

    myself_div, myself_list = CommonUtil.divname2num(selectDir_name)
    parent_div, parent_list = CommonUtil.divname2num(parentDir_name)
    
    ExecUtil.DictateScore_copy(TreeType, selectDir)
        
    
    num_param = len(myself_list)        

#        pattern = selectDir + "/" + self.cfMeshFrame.typeComboBox2.currentText()
    pattern = platformDir + "/" + PatternCode

    logging.debug(pattern)

    if TreeType == "Binary_plusC" or TreeType == "fcPascal_plusC" :
        pattern = pattern  + "_plusC"
#20200111prevent same_parameter_exec
                                        

    logging.debug(pattern)

    if os.path.exists(pattern)==False:
        print("Pattern file is not exits")
        exit()
    else:
        f=open(pattern)
        x=f.read()
        f.close()
        lines = [i for i in re.split(r'\n',x) if i != '']
        length = len(lines)
        cut_lines = []
        merge_lines = []
        passed_lines = []
        #numpy_lines = []


        parent =  selectDir.split("/")[-1]
        logging.debug(parent)

#        lcg_flag=0

        for line in lines:
            cut_line =line[0:num_param]
            cut_line = ExecUtil.line_adaptedlcg(cut_line,256,lcg_flag,lcg_constant)
            cut_lines.append(cut_line)

        merge_lines = list(set(cut_lines))
        merge_lines.sort()


    directions = []
    for merge_line in merge_lines:

        char_direction=list(merge_line)
        direction=[int(s) for s in char_direction]
        directions.append(direction)


    prejob_lists, job_div = ExecUtil.create_prejob_lists(TreeType, directions, selectDir)

    job_lists = ExecUtil.deleteDubjob_lists(TreeType, selectDir, prejob_lists)

    pair_job_lists=[]
    for i in range(len(job_lists)):
        if i%2 == 0:
            pair_job_lists.append(job_lists[i//2])
        if i%2 == 1:
            pair_job_lists.append(job_lists[len(job_lists)-i//2-1])

    logging.debug(prejob_lists)
    logging.debug("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
    logging.debug(job_lists)
    logging.debug("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
    logging.debug(pair_job_lists)



    pC_direction = []
    if TreeType == "fcPascal_plusC":
        pC_direction = ExecUtil.make_pCdirection(TreeType,selectDir )
                                 
        if pC_direction!=[]:
            temp_pC_list, temp_myself_div = ExecUtil.create_prejob_list(TreeType, pC_direction, selectDir)

        if pC_direction!= [] and (temp_pC_list in pair_job_lists) == False:
            pair_job_lists.append(temp_pC_list)
            logging.debug("pC exists on job_list")
        else:
            logging.debug("pC not exists on job_list")
                


    
    stat = showJobNumDialog(selectDir, job_div, pair_job_lists)
    if stat != "OK":
        return

    #adapter計算中のdialog表示
    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, pair_job_lists, job_div)

    try:
        if ('temp_myself_div' in locals()) and ('temp_pC_list' in locals()):
            ExecUtil.addNoteCsv2job_list(temp_myself_div, temp_pC_list, "pC" , selectDir)
    except:
        pass


    #nProcs毎に計算する
    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)


    #dialogを閉じる
    closeDialog()

#def ignite_target(seed_job_lists, myself_div,selectDir,sourceDir,platformDir, nProcs, nCpu_perCase):
#def eachparam_exec(seed_job_lists, selectDir,projDir,platformDir, nProcs, nCpu_perCase,TreeType,PatternCode):
def eachparam_exec():

    parentDir = "/".join(selectDir.split("/")[:-1])

    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
    myself_div,myself_list = CommonUtil.divname2num(os.path.basename(selectDir))

    logging.debug(parentDir)
    logging.debug(parent_list)

    _, ancestor_direction = CommonUtil.direction_decode( parentDir, selectDir)

    if not ancestor_direction:
        print("selectDir is invalid for eachparam_exec")
        exit()
    

    directions=[]
    directions.append(ancestor_direction)    
    
    tempdirection=[]

    for n in range(len(myself_list)):
        if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
            if ancestor_direction[n]==0:
                tempdirection = ancestor_direction[:n] + [1] + ancestor_direction[n+1:]
                directions.append(tempdirection)
                tempdirection = ancestor_direction[:n] + [2] + ancestor_direction[n+1:]
                directions.append(tempdirection)
            elif ancestor_direction[n]==1:
                tempdirection = ancestor_direction[:n] + [2] + ancestor_direction[n+1:]
                directions.append(tempdirection)
                tempdirection = ancestor_direction[:n] + [0] + ancestor_direction[n+1:]
                directions.append(tempdirection)
            else:
                tempdirection = ancestor_direction[:n] + [1] + ancestor_direction[n+1:]
                directions.append(tempdirection)
                tempdirection = ancestor_direction[:n] + [0] + ancestor_direction[n+1:]
                directions.append(tempdirection)

        else:
            tempdirection = ancestor_direction[:n] + [2] + ancestor_direction[n+1:]
            directions.append(tempdirection)
            tempdirection = ancestor_direction[:n] + [0] + ancestor_direction[n+1:]
            directions.append(tempdirection)

    logging.debug(directions)
    
    prejob_lists, job_div = ExecUtil.create_prejob_lists(TreeType, directions, parentDir )

    job_lists = ExecUtil.deleteDubjob_lists(TreeType, parentDir, prejob_lists)


    stat = showJobNumDialog(parentDir, job_div, job_lists)
    if stat != "OK":
        return
    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, parentDir, job_lists, job_div)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    logging.debug("@@@@@@@@@@@@addtryentry@@@@@@@@@@")
#    addtryjob_lists=[]
#need seed append on prejob_lists)

    addtryjob_lists = createpre_addtryjob_lists(prejob_lists, job_div,parentDir)

    job_lists = ExecUtil.deleteDubjob_lists(TreeType, parentDir, addtryjob_lists)

    caseDirs = ExecUtil.createCaseDirs(projDir, parentDir, job_lists, job_div)

    logging.debug(addtryjob_lists)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    #dialogを閉じる
    closeDialog()


def samedirect_exec():


    parentDir = "/".join(selectDir.split("/")[:-1])

    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
    myself_div,myself_list = CommonUtil.divname2num(os.path.basename(selectDir))

    ExecUtil.DictateScore_copy(TreeType, selectDir)

    logging.debug("logging debug test point")
    logging.debug(parentDir)
#    logging.debug(parent_div,parent_list)


    ancestor_direction = []
    ancestor_direction2 = []
    ancestor_direction3 = [1] * len(myself_list)
    ancestor_direction4 = []


    _,ancestor_direction = CommonUtil.direction_decode(parentDir,selectDir)
    ancestor_direction2 = CommonUtil.inversed_direction(ancestor_direction)

    if not ancestor_direction:
        print("selectDir is invalid for samedirect_exec")
        exit()


    directions=[]

##### future add inverse-ancestor_direction######
    directions.append(ancestor_direction)
    directions.append(ancestor_direction2)
    directions.append(ancestor_direction3)

#    if 'ancestor_direction4' in locals():

    if TreeType == "fcPascal_plusC" or TreeType == "fcPascal":
        ancestor_direction4 = ExecUtil.make_pCdirection(TreeType,selectDir )
    
    if ancestor_direction4 != []:
        temp_pC_list, temp_myself_div = ExecUtil.create_prejob_list(TreeType, ancestor_direction4, selectDir)
        if (ancestor_direction4 in directions) == False:
            directions.append(ancestor_direction4)
      


    logging.debug(directions)


    prejob_lists, job_div = ExecUtil.create_prejob_lists(TreeType, directions, selectDir)

    job_lists = ExecUtil.deleteDubjob_lists(TreeType, selectDir, prejob_lists)


    stat = showJobNumDialog(selectDir, job_div, job_lists)
    if stat != "OK":
        return

    #adapter計算中のdialog表示
    showDialog()


    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, job_div)
    try:
        if ('temp_myself_div' in locals()) and ('temp_pC_list' in locals()) :
            logging.debug("pC write")
            ExecUtil.addNoteCsv2job_list(temp_myself_div, temp_pC_list, "pC" , selectDir)
    except:
        pass


    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)


    #dialogを閉じる
    closeDialog()

#def select_exec(seed_job_list, selectDir,projDir,platformDir, nProcs, nCpu_perCase,TreeType,PatternCode):
def select_exec():


    selectDir_name = os.path.basename(selectDir)

    #if selectDir_name=="SourceCase":
        #logging.debug(selectDir_name)
        #makestartnode()
        #return


    if os.path.exists(selectDir + "/score.csv")==False:
        print("try exec")
    else:
        print("already calculated")
        exit()

    selectDir_name = os.path.basename(selectDir)
    myself_div,myself_list= CommonUtil.divname2num(selectDir_name)
    myself_lists =[]
    myself_lists.append(myself_list)

    parentDir = "/".join(selectDir.split("/")[:-1])

    stat = showJobNumDialog(parentDir, myself_div, myself_lists)
    if stat != "OK":
        return

#################選択caseの一つ上を、新たに選択caseとし変数名はselectDir2とする(targetは一つ下ディレクトリに作成する要領のため)#######

#    clearall(myself_div, job_list)

    if os.path.exists(selectDir) == True and os.path.exists(selectDir+"/score.csv") == True:
        pass
    else:
        ExecUtil.copyCase(projDir, selectDir)

#    comm = "python '" + projDir + "/target.py'" + " " + str(nProcs) + " '" + selectDir + "' > '" + selectDir + "/proc.log'"

    showDialog()

    comm = "cd '" + selectDir + "';" + "python3 '"+projDir+"/target.py' " +  " > '" + selectDir + "/proc.log'"

    os.system(comm)

    closeDialog()




def showJobNumDialog(myselfDir, div_num,job_lists):    
    
    title = u"Confirmation"
    mess = u"The number of execution is" + "\n"
    mess += "" + str(len(job_lists)) + u"   items from the node \n"
    mess += "          " + os.path.basename(myselfDir) + " \n"
    mess += u"Will you start?"
    
    
    excerpt_lists = "Lists of exec_node \n\n"

    if len(job_lists) != 0:
        max_column = 280
        max_row = 1280
        num_excerpt = min(len(job_lists),max_row)
        for i in range(num_excerpt):
            excerpt_list = CommonUtil.num2divname(div_num,job_lists[i])
            if len(excerpt_list) <= max_column:
                excerpt_lists += excerpt_list + " \n"
            else:
                excerpt_lists += excerpt_list[0:max_column] + "... \n"
        if len(job_lists) > max_row:
            excerpt_lists += "..."
    
    stat = okCancelDialog(title, mess, excerpt_lists )
    return stat





def createpre_addtryjob_lists(Firstfinished_lists,myself_div,startDir):
    addtry_up_direction = []
    addtry_down_direction= []
    myself_list = Firstfinished_lists[0] #this is just a n_list generated from "direction" of above code
    addtry_up_direction=copy.deepcopy( myself_list)
    addtry_down_direction=copy.deepcopy( myself_list)
    myself_score= CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div, myself_list) )

    if TreeType == "Binary_plusC" or TreeType == "fcPascal_plusC":

        for i in range(len(Firstfinished_lists)):
            if i%2==1:
                for j in range(len(myself_list)):
                    if myself_list[j]!=Firstfinished_lists[i][j]:
                        job_score1 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i]))
                        job_score2 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i+1]))

                        if myself_score==None or job_score1==None or job_score2==None:
                            pass
                        elif job_score1 <= job_score2:
                            if myself_score <= job_score2:
                                addtry_up_direction= addtry_up_direction[:j]+[Firstfinished_lists[i+1][j]]+addtry_up_direction[j+1:]                    
                            if myself_score > job_score1:
                                addtry_down_direction= addtry_down_direction[:j]+[Firstfinished_lists[i][j]]+addtry_down_direction[j+1:]
                        elif job_score1 > job_score2:# job_score  job
                            if myself_score <= job_score1:
                                addtry_up_direction= addtry_up_direction[:j]+[Firstfinished_lists[i][j]]+addtry_up_direction[j+1:]                    
                            if myself_score > job_score2:
                                addtry_down_direction= addtry_down_direction[:j]+[Firstfinished_lists[i+1][j]]+addtry_down_direction[j+1:]
                        else:
                            pass


    else: #TreeType Binary or Pascal
        for i in range(len(Firstfinished_lists)):
            for j in range(len(myself_list)):
                if myself_list[j]!=Firstfinished_lists[i][j]:
                    job_score = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i]))
                    if myself_score==None or job_score==None:
                        pass
                    elif myself_score <= job_score: 
                        addtry_up_direction= addtry_up_direction[:j]+[Firstfinished_lists[i][j]]+addtry_up_direction[j+1:]
                        logging.debug(addtry_up_direction)
                    elif myself_score > job_score:
                        addtry_down_direction= addtry_down_direction[:j]+[Firstfinished_lists[i][j]]+addtry_down_direction[j+1:]
                        logging.debug(addtry_down_direction)
                    else:
                        pass

    addtryjob_lists = []
    addtryjob_lists.append(addtry_up_direction)
    addtryjob_lists.append(addtry_down_direction)
    return addtryjob_lists



if __name__ == "__main__":
    nProcs = sys.argv[1]
    nCpu_perCase = sys.argv[2]
    selectDir = sys.argv[3]
    projDir = sys.argv[4]
    platformDir = sys.argv[5]
    onlyCsv = sys.argv[6]
    TreeType = sys.argv[7]
    PatternCode = sys.argv[8]
    lcg_flag = sys.argv[9]
    lcg_constant = int(sys.argv[10])
    funcname = sys.argv[11]

    #projDir = "/".join(sourceDir.split("/")[:-1])

    if os.path.basename(selectDir)=="SourceCase":
        main_select_div=2
    else:
        main_select_div,_ = CommonUtil.divname2num(os.path.basename(selectDir))


    if (main_select_div<=3) and (TreeType=="fcPascal" or TreeType=="fcPascal_plusC") and funcname!="select_exec":
        print("fcPascal validates only when div-number of select-node is 4 or more.")
        exit()

    nProcs = int(nProcs)
    nCpu_perCase = int(nCpu_perCase)
    #f = open(platformDir + "/seed_job_list.csv","r")
    if os.path.exists(projDir + "/seed_job_list.csv") == True:
        main_f = open(projDir + "/seed_job_list.csv","r")
        main_reader = csv.reader(main_f)
        seed_job_list = [main_row for main_row in main_reader]
        logging.debug(seed_job_list)
        main_f.close()
    else:
        seed_job_list = []

    eval(funcname)()

