#!/usr/bin/python3
#  coding:  utf-8
#
"""
Executor_Table.py
Copyright (C) 2020 Shigeki Fujii, Tsunehiro Watanabe all rights reserved.

This software is released under the MIT License.
http://opensource.org/licenses/mit-license.php
"""
import logging
logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)


#from PySide import QtCore, QtGui
#from PySide.QtGui import *
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from functools import partial
from decimal import Decimal
import sys
import os.path
import gettext
import tempfile
import math
import subprocess
from subprocess import Popen
import shutil
import glob
import threading

import re

#import Table_GUI

import numpy as np

import multiprocessing
import time
import csv
import six

import copy

from itertools import product

import CommonUtil
import ExecUtil


#dialog表示の為、定義
app = QApplication()

dialogApp = ""

def showDialog():
    """ messagetDialogを表示させる"""
    global dialogApp
    comm = "python3 messageDialogApp.py"
    dialogApp = subprocess.Popen(comm, shell=True, stdin=subprocess.PIPE)

def closeDialog():
    """ dilogを閉じる"""
    global dialogApp
    dialogApp.stdin.write(b"close\n")
    dialogApp.kill()



def createpre_addtryjob_lists(Firstfinished_lists,myself_div,startDir):
    addtry_list = []

    myself_list = Firstfinished_lists[0] #this is just a n_list generated from "vector" of above code
    addtry_list=copy.deepcopy( myself_list)

    myself_score= CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div, myself_list) )


    counter =0

    for n,elem in enumerate(num_bind_list):
    #20210413 intend include upper aim4s, but no need?
        if fix_list[n]==True:
            pass
        else:

            job_score1 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[2*counter+1]))
            job_score2 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[2*counter+2]))

            if myself_score==None or job_score1==None or job_score2==None:
                pass
            elif (aim_header[0] == "upper_aim4s") ^ (job_score1 <= job_score2):
                if (aim_header[0] == "upper_aim4s") ^ (myself_score > job_score1 ):
                    addtry_list= addtry_list[:n]+[Firstfinished_lists[2*counter+1][n]]+addtry_list[n+1:]                    


            elif (aim_header[0] == "upper_aim4s") ^ (job_score1 > job_score2):
                if  (aim_header[0] == "upper_aim4s") ^ (myself_score > job_score2):
                    addtry_list= addtry_list[:n]+[Firstfinished_lists[2*counter+2][n]]+addtry_list[n+1:]                    
            else:
                pass
            counter = counter +1
                
    addtryjob_lists = []
    addtryjob_lists.append(addtry_list)
    return addtryjob_lists


    #if i%2==1:
    #    job_score1 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i]))
    #    job_score2 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i+1]))

    #if myself_score==None or job_score1==None or job_score2==None:
    #    pass
    #elif (aim_header[0] == "upper_aim4s") ^ (job_score1 <= job_score2):
    #    if myself_score > job_score1:
    #        addtry_list= addtry_list[:(i-1)//2]+[Firstfinished_lists[i][(i-1)//2]]+addtry_list[(i-1)//2+1:]                    

    #    elif (aim_header[0] == "lower_aim4s") ^ (job_score1 <= job_score2):
    #        if myself_score > job_score2:
    #            addtry_list= addtry_list[:(i-1)//2]+[Firstfinished_lists[i+1][(i-1)//2]]+addtry_list[(i-1)//2+1:]                    
    #        else:
    #            pass                
def createpre_addtryjob_lists4eachobj(Firstfinished_lists,myself_div,startDir):
    addtry_list = []

    myself_list = Firstfinished_lists[0] #this is just a n_list generated from "vector" of above code
    addtry_list=copy.deepcopy( myself_list)

    myself_score= CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div, myself_list) )


    counter =0

    for n,elem in enumerate(num_bind_list):
    #20210413 intend include upper aim4s, but no need?
        if fix_list[n]==True or obj_list[n]!="obj":
            pass
        else:

            job_score1 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[2*counter+1]))
            job_score2 = CommonUtil.getscore(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[2*counter+2]))

            if myself_score==None or job_score1==None or job_score2==None:
                pass
            elif (aim_header[0] == "upper_aim4s") ^ (job_score1 <= job_score2):
                if (aim_header[0] == "upper_aim4s") ^ (myself_score > job_score1 ):
                    addtry_list= addtry_list[:n]+[Firstfinished_lists[2*counter+1][n]]+addtry_list[n+1:]                    


            elif (aim_header[0] == "upper_aim4s") ^ (job_score1 > job_score2):
                if  (aim_header[0] == "upper_aim4s") ^ (myself_score > job_score2):
                    addtry_list= addtry_list[:n]+[Firstfinished_lists[2*counter+2][n]]+addtry_list[n+1:]                    
            else:
                pass
            counter = counter +1
                
    addtryjob_lists = []
    addtryjob_lists.append(addtry_list)
    return addtryjob_lists
    
    
    




def createpre_addtryjob_lists4eachbind(Firstfinished_lists,myself_div,startDir,indexes,len_maxelemsub):

    #20210409 set of default list from FirstFinished_lists
    #    addtry_list = []
    #    myself_list = Firstfinished_lists[0] #this is just a n_list generated from "vector" of above code
    #    addtry_list=copy.deepcopy( myself_list)
    #    myself_score= CommonUtil.getscores(startDir+"/"+CommonUtil.num2divname(myself_div, myself_list) )
    #    float_scores=[]
    #    for i in  range(len(Firstfinished_lists)):
    #        float_scores.append(CommonUtil.getscores(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i])))
    #    print(float_scores)
    #    print(addtry_list)
    #    if aim_header[0]=="upper_aim4s":
    #        Provisionalbest_index,_ = max(enumerate(float_scores),key=lambda x: x[1][0] )
    #    else:
    #        Provisionalbest_index,_ = min(enumerate(float_scores),key=lambda x: x[1][0] )
    #    addtry_best_list = []
    #    addtry_best_list = [Firstfinished_lists[0][i] if fix_list[i]==True else Firstfinished_lists[Provisionalbest_index][i] for i in range(len(addtry_list))]
    #    print(addtry_best_list)
    #20210409 set of default list from FirstFinished_lists
    #    for i in range(len(addtry_list)):
    #20210408 adjust nuetral score of bind column

    float_scores=[]
    Finished_lists=[]

    folderDirs = glob.glob(startDir + "/*")
    for folderDir in folderDirs:
        scoreFile = folderDir + "/score.csv"
        if os.path.exists(scoreFile):
            result_div,result_list = CommonUtil.divname2num(os.path.basename(folderDir))
            if myself_div==result_div:
                float_scores.append(CommonUtil.getscores(folderDir))
                Finished_lists.append(result_list)

    if aim_header[0]=="upper_aim4s":
        Provisionalbest_index,_ = max(enumerate(float_scores),key=lambda x: x[1][0] )
    else:
        Provisionalbest_index,_ = min(enumerate(float_scores),key=lambda x: x[1][0] )

    Provisionalbest_list = Finished_lists[Provisionalbest_index] #this is just a n_list generated from "vector" of above code
        
    addtry_best_list = [Firstfinished_lists[0][i] if fix_list[i]==True else Provisionalbest_list[i] for i in range(len(Firstfinished_lists[0]))]

    float_scores=[]
    for i in  range(len(Firstfinished_lists)):
        float_scores.append(CommonUtil.getscores(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i])))

    leader_indexes=[]
    #index_temp=0

    for n in range(len_maxelemsub):
        for i,elem in enumerate(indexes):
            #print elem[i]
            if ( TreeType != "Pascal" ) and len(elem)!=0 and i!=0:
                #aim[0](mean socre) is not 
                if aim_header[i][:5]=="upper":
                    temp_max = max(float_scores[0][i],float_scores[2*n+1][i],float_scores[2*n+2][i])
                    if float_scores[2*n+1][i]==temp_max:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    elif float_scores[2*n+2][i]==temp_max:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+2][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    else:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        #pass
                elif aim_header[i][:5]=="lower":
                    temp_min = min(float_scores[0][i],float_scores[2*n+1][i],float_scores[2*n+2][i])
                    if float_scores[2*n+1][i]==temp_min:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    elif float_scores[2*n+2][i]==temp_min:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+2][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    else:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        #pass
                    logging.debug(i)
                    logging.debug(addtry_best_list)

                elif aim_header[i][:5]=="value" and type(value_header[i]) is float:
                    #temp_min = min(float_scores[0][i],float_scores[2*n+1][i],float_scores[2*n+2][i])
                    
                    temp_min = min(abs(float_scores[0][i]-value_header[i]),abs(float_scores[2*n+1][i]-value_header[i]),abs(float_scores[2*n+2][i]-value_header[i]))
                    if abs(float_scores[2*n+1][i] -value_header[i])==temp_min:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    elif abs(float_scores[2*n+2][i] - value_header[i])==temp_min:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+2][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    else:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        #pass
                    logging.debug(i)
                    logging.debug(addtry_best_list)


                else:
                    if aim_header[0][:5]=="upper":
                        temp_max = max(float_scores[0][0],float_scores[2*n+1][0],float_scores[2*n+2][0])
                        if float_scores[2*n+1][0]==temp_max:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        elif float_scores[2*n+2][0]==temp_max:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+2][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        else:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                            #pass
                    else:
                        temp_min = min(float_scores[0][0],float_scores[2*n+1][0],float_scores[2*n+2][0])
                        if float_scores[2*n+1][0]==temp_min:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        elif float_scores[2*n+2][0]==temp_min:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[2*n+2][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        else:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]                        
                            #pass

            elif len(elem)!=0 and i!=0:
                if aim_header[i][:5]=="upper":
                    temp_max = max(float_scores[0][i],float_scores[n+1][i])
                    if float_scores[n+1][i]==temp_max:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    else:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        #pass
                elif aim_header[i][:5]=="lower":
                    temp_min = min(float_scores[0][i],float_scores[n+1][i])
                    if float_scores[n+1][i]==temp_min:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    else:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        #pass

                elif aim_header[i][:5]=="value" and type(value_header[i]) is float:
                    temp_min = min(abs(float_scores[0][i]-value_header[i]),abs(float_scores[n+1][i]-value_header[i]))
                    if abs(float_scores[n+1][i]-value_header[i])==temp_min:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                    else:
                        addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        #pass


                else:
                    if aim_header[0][:5]=="upper":
                        temp_max = max(float_scores[0][0],float_scores[n+1][0])
                        if float_scores[n+1][0]==temp_max:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        else:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                            #pass
                    else:
                        temp_min = min(float_scores[0][0],float_scores[n+1][0])
                        if float_scores[n+1][0]==temp_min:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[n+1][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]
                        else:
                            addtry_best_list = addtry_best_list[:elem[n % len(elem)]] + [Firstfinished_lists[0][elem[n % len(elem)]]] + addtry_best_list[elem[n % len(elem)]+1:]                        
                            #pass
            else:
                pass

    logging.debug(addtry_best_list)

    addtryjob_lists = []
    addtryjob_lists.append(addtry_best_list)
    return addtryjob_lists


def createpre_addtryjob_lists4eachparambind(Firstfinished_lists,myself_div,startDir,indexes,len_maxelemsub):


    float_scores=[]
    Finished_lists=[]

    folderDirs = glob.glob(startDir + "/*")
    for folderDir in folderDirs:
        scoreFile = folderDir + "/score.csv"
        if os.path.exists(scoreFile):
            result_div,result_list = CommonUtil.divname2num(os.path.basename(folderDir))
            if myself_div==result_div:
                float_scores.append(CommonUtil.getscores(folderDir))
                Finished_lists.append(result_list)

    if aim_header[0]=="upper_aim4s":
        Provisionalbest_index,_ = max(enumerate(float_scores),key=lambda x: x[1][0] )
    else:
        Provisionalbest_index,_ = min(enumerate(float_scores),key=lambda x: x[1][0] )

    Provisionalbest_list = Finished_lists[Provisionalbest_index] #this is just a n_list generated from "vector" of above code
    
    
    addtry_best_list = [Firstfinished_lists[0][i] if fix_list[i]==True else Provisionalbest_list[i] for i in range(len(Firstfinished_lists[0]))]



    float_scores=[]
    for i in  range(len(Firstfinished_lists)):
        float_scores.append(CommonUtil.getscores(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i])))

    leader_indexes=[]

    counter=0
    if TreeType!="Pascal":
        for n,elem in enumerate(num_bind_list):
        #20210413 intend include upper aim4s, but no need?
            if fix_list[n]==True:
                pass
            else:
                if aim_header[elem][:5] == "upper":
                    temp_max = max(float_scores[0][elem],float_scores[2*counter+1][elem],float_scores[2*counter+2][elem])
                    if float_scores[2*counter+1][elem]==temp_max:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+1][n]] + addtry_best_list[n+1:]
                    elif float_scores[2*counter+2][elem]==temp_max:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+2][n]] + addtry_best_list[n+1:]
                    else:
                        
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]
                #20210413 intend include lower aim4s, but no need?
                elif aim_header[elem][:5] == "lower":
                    temp_min = min(float_scores[0][elem],float_scores[2*counter+1][elem],float_scores[2*counter+2][elem])
                    if float_scores[2*counter+1][elem]==temp_min:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+1][n]] + addtry_best_list[n+1:]
                    elif float_scores[2*counter+2][elem]==temp_min:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+2][n]] + addtry_best_list[n+1:]
                    else:
                        #pass
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]

                elif aim_header[elem][:5] == "value" and type(value_header[elem]) is float:
                    temp_min = min(abs(float_scores[0][elem]-value_header[elem]),abs(float_scores[2*counter+1][elem]-value_header[elem]),abs(float_scores[2*counter+2][elem]-value_header[elem]))
                    if abs(float_scores[2*counter+1][elem]-value_header[elem])==temp_min:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+1][n]] + addtry_best_list[n+1:]
                    elif abs(float_scores[2*counter+2][elem]-value_header[elem])==temp_min:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+2][n]] + addtry_best_list[n+1:]
                    else:
                        #pass
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]


                #if aim is ignore or follow, reference main score
                else:
                    if aim_header[0][:5]=="upper":
                        temp_max = max(float_scores[0][0],float_scores[2*counter+1][0],float_scores[2*counter+2][0])
                        if float_scores[2*counter+1][0]==temp_max:
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+1][n]] + addtry_best_list[n+1:]
                        elif float_scores[2*counter+2][0]==temp_max:
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+2][n]] + addtry_best_list[n+1:]
                        else:
                           
                           addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]
                            #pass
                    else:
                        temp_min = min(float_scores[0][0],float_scores[2*counter+1][0],float_scores[2*counter+2][0])
                        if float_scores[2*counter+1][0]==temp_min:
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+1][n]] + addtry_best_list[n+1:]
                        elif float_scores[2*n+2][0]==temp_min:
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[2*counter+2][n]] + addtry_best_list[n+1:]
                        else:
                            
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]
                            #pass

                    logging.debug(i)
                    logging.debug(addtry_best_list)
                
                counter = counter +1


    else:
        for n,elem in enumerate(num_bind_list):
            #20210413 intend include upper aim4s, but no need?
            if fix_list[n]==True:
                pass
            else:
                if aim_header[elem][:5] == "upper":
                    temp_max = max(float_scores[0][elem],float_scores[counter+1][elem])
                    if float_scores[counter+1][elem]==temp_max:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[counter+1][n]] + addtry_best_list[n+1:]
                    else:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]
                #20210413 intend include lower aim4s, but no need?
                elif aim_header[elem][:5] == "lower":
                    temp_min = min(float_scores[0][elem],float_scores[counter+1][elem])
                    if float_scores[counter+1][elem]==temp_min:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[counter+1][n]] + addtry_best_list[n+1:]
                    else:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]

                #if aim is ignore or follow, reference main score
                elif aim_header[elem][:5] == "value" and type(value_header[elem]) is float:
                    temp_min = min(abs(float_scores[0][elem]-value_header[elem]),abs(float_scores[counter+1][elem]-value_header[elem]))
                    if abs(float_scores[counter+1][elem]-value_header[i])==temp_min:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[counter+1][n]] + addtry_best_list[n+1:]
                    else:
                        addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]                
                
                
                else:
                    if aim_header[0][:5]=="upper":
                        temp_max = max(float_scores[0][0],float_scores[counter+1][0])
                        if float_scores[counter+1][0]==temp_max:
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[counter+1][n]] + addtry_best_list[n+1:]
                        else:
                           addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]
                           #pass
                    else:
                        temp_min = min(float_scores[0][0],float_scores[2*counter+1][0])
                        if float_scores[counter+1][0]==temp_min:
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[counter+1][n]] + addtry_best_list[n+1:]
                        else:
                            addtry_best_list = addtry_best_list[:n] + [Firstfinished_lists[0][n]] + addtry_best_list[n+1:]
                            #pass
           
                        #pass
                    logging.debug(i)
                    logging.debug(addtry_best_list)
                
                counter = counter +1


    logging.debug(addtry_best_list)

    addtryjob_lists = []
    addtryjob_lists.append(addtry_best_list)
    return addtryjob_lists



def createpre_addtryjob_lists4bind(Firstfinished_lists,myself_div,startDir,indexes):

    float_scores=[]
    Finished_lists=[]

    folderDirs = glob.glob(startDir + "/*")
    for folderDir in folderDirs:
        scoreFile = folderDir + "/score.csv"
        if os.path.exists(scoreFile):
            result_div,result_list = CommonUtil.divname2num(os.path.basename(folderDir))
            if myself_div==result_div:
                float_scores.append(CommonUtil.getscores(folderDir))
                Finished_lists.append(result_list)

    if aim_header[0]=="upper_aim4s":
        Provisionalbest_index,_ = max(enumerate(float_scores),key=lambda x: x[1][0] )
    else:
        Provisionalbest_index,_ = min(enumerate(float_scores),key=lambda x: x[1][0] )

    Provisionalbest_list = Finished_lists[Provisionalbest_index] #this is just a n_list generated from "vector" of above code


    addtry_best_list = [Firstfinished_lists[0][i] if fix_list[i]==True else Provisionalbest_list[i] for i in range(len(Firstfinished_lists[0]))]

    addtry_list = addtry_best_list

    float_scores=[]
    for i in  range(len(Firstfinished_lists)):
        float_scores.append(CommonUtil.getscores(startDir+"/"+CommonUtil.num2divname(myself_div,Firstfinished_lists[i])))
    #############20201022testprint################
    logging.debug(float_scores)
    logging.debug(addtry_list)

    ############20201022testprint #20201031 index_temp ################
    leader_indexes=[]
    index_temp=0

    for i in range(len(aim_header)):
        index_temp = 0    
        if i==0:
            if aim_header[i]=="upper_aim4s":
                index_temp,_ = max(enumerate(float_scores),key=lambda x: x[1][0] )                
                logging.debug("upper_aim4s")
            else:
                index_temp,_ = min(enumerate(float_scores),key=lambda x: x[1][0] )
                logging.debug("lower_aim4s")
        else:
            if aim_header[i]=="upper_aim":
                index_temp,_ = max(enumerate(float_scores),key=lambda x: x[1][i] )
                logging.debug("upper_aim")
            elif aim_header[i]=="lower_aim":
                index_temp,_ = min(enumerate(float_scores),key=lambda x: x[1][i] )
                logging.debug("lower_aim")
            elif aim_header[i]=="value_aim" and type(value_header[i]) is float:
                index_temp,_ = min(enumerate(float_scores),key=lambda x: abs(x[1][i]-value_header[i]) )
                logging.debug("value_aim")                
                
            else:
            #if aim of subscore is not upper lower, index_temp is (mainscore
                index_temp=leader_indexes[0]
                logging.debug("other")
        logging.debug(index_temp)
        logging.debug(Firstfinished_lists[index_temp])                
        leader_indexes.append(index_temp)
    logging.debug("leader_indexes")
    logging.debug(leader_indexes)

    #addtry_list =copy.deepcopy(Firstfinished_lists[leader_indexes[0]])

    for i,index in enumerate(indexes):
        logging.debug(i)
        logging.debug(Firstfinished_lists[leader_indexes[i]])
        
        #202104009add i!=0
        if len(index)!=0 and i!=0:
            for elem in index:
                addtry_list = addtry_list[:elem] + [Firstfinished_lists[leader_indexes[i]][elem]] + addtry_list[elem+1:]
        else:
            pass
    addtryjob_lists = []
    addtryjob_lists.append(addtry_list)
    logging.debug(addtryjob_lists)
    return addtryjob_lists

def createpre_addtryjob_lists4bind_allchiLdDir(Firstfinished_lists,myself_div,startDir,indexes):

    float_scores=[]
    Finished_lists=[]

    folderDirs = glob.glob(startDir + "/*")
    for folderDir in folderDirs:
        scoreFile = folderDir + "/score.csv"
        if os.path.exists(scoreFile):
            result_div,result_list = CommonUtil.divname2num(os.path.basename(folderDir))
            if myself_div==result_div:
                float_scores.append(CommonUtil.getscores(folderDir))
                Finished_lists.append(result_list)

    if aim_header[0]=="upper_aim4s":
        Provisionalbest_index,_ = max(enumerate(float_scores),key=lambda x: x[1][0] )
    else:
        Provisionalbest_index,_ = min(enumerate(float_scores),key=lambda x: x[1][0] )

    Provisionalbest_list = Finished_lists[Provisionalbest_index] #this is just a n_list generated from "vector" of above code

    leader_indexes=[]
    index_temp=0

    for i in range(len(aim_header)):
        index_temp = 0    
        if i==0:
            if aim_header[i]=="upper_aim4s":
                index_temp,_ = max(enumerate(float_scores),key=lambda x: x[1][0] )                
                logging.debug("upper_aim4s")
            else:
                index_temp,_ = min(enumerate(float_scores),key=lambda x: x[1][0] )
                logging.debug("lower_aim4s")
        else:
            if aim_header[i]=="upper_aim":
                index_temp,_ = max(enumerate(float_scores),key=lambda x: x[1][i] )
                logging.debug("upper_aim")
            elif aim_header[i]=="lower_aim":
                index_temp,_ = min(enumerate(float_scores),key=lambda x: x[1][i] )
                logging.debug("lower_aim")
            elif aim_header[i]=="value_aim" and type(value_header[i]) is float:
                index_temp,_ = min(enumerate(float_scores),key=lambda x: abs(x[1][i]-value_header[i]) )
                logging.debug("lower_aim")                
                                
                
            else:
            #if aim of subscore is not upper lower, index_temp is (mainscore
                index_temp=leader_indexes[0]
                logging.debug("other")
        logging.debug(index_temp)
        logging.debug(Finished_lists[index_temp])                
        leader_indexes.append(index_temp)
    logging.debug("leader_indexes")
    logging.debug(leader_indexes)

    addtry_list = [Firstfinished_lists[0][i] if fix_list[i]==True else Provisionalbest_list[i] for i in range(len(Firstfinished_lists[0]))]

    for i,index in enumerate(indexes):
        logging.debug(i)
        logging.debug(Finished_lists[leader_indexes[i]])
        if len(index)!=0:
            for elem in index:
                addtry_list = addtry_list[:elem] + [Finished_lists[leader_indexes[i]][elem]] + addtry_list[elem+1:]
        else:
            pass
    addtryjob_lists = []
    addtryjob_lists.append(addtry_list)
    logging.debug(addtryjob_lists)
    return addtryjob_lists



def eachparam_exec():
#    parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    logging.debug("test point")
    logging.debug(parent_list)

    directions=[]
    tempdirection=[]

    np_importance_list = np.array(importance_list)
    rank_importance_list=np_importance_list.argsort()

    directions.append(base_direction)
    for n in range(len(parent_list)):
        #20201222edit
        #if (rank_importance_list[n]<=num_var and not (ML_list[n]=="ML" and ML_fix==True)) or obj_list[n]=="obj":

        if (rank_importance_list[n]<=num_var and not (ML_list[n]=="ML" and ML_fix==True)  ) and not fix_list[n]==True:

            if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
                if base_direction[n]==0:
                    tempdirection = base_direction[:n] + [attract(2,base_direction[n])] + base_direction[n+1:]
                    directions.append(tempdirection)
                    tempdirection = base_direction[:n] + [1] + base_direction[n+1:]
                    directions.append(tempdirection)
                elif base_direction[n]==1:
                    tempdirection = base_direction[:n] + [2] + base_direction[n+1:]
                    directions.append(tempdirection)
                    tempdirection = base_direction[:n] + [0] + base_direction[n+1:]
                    directions.append(tempdirection)
                else:
                    tempdirection = base_direction[:n] + [1] + base_direction[n+1:]
                    directions.append(tempdirection)
                    tempdirection = base_direction[:n] + [attract(0,base_direction[n])] + base_direction[n+1:]
                    directions.append(tempdirection)

            #            elif TreeType=="Binary" or TreeType=="fcPascal":
            #                tempdirection = base_direction[:n] + [2] + base_direction[n+1:]
            #                directions.append(tempdirection)
            #                tempdirection = base_direction[:n] + [0] + base_direction[n+1:]
            #                directions.append(tempdirection)

            else:
                tempdirection = base_direction[:n] + [attract(2,base_direction[n])] + base_direction[n+1:]
                directions.append(tempdirection)
                tempdirection = base_direction[:n] + [attract(0,base_direction[n])] + base_direction[n+1:]
                directions.append(tempdirection)
        else:
            pass

    logging.debug(directions)


    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    

    stat = showJobNumDialog(selectDir, myself_div, job_lists)
    if stat != "OK":
        return

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)


#    print(addtry_flag)
    if addtry_flag == "0":
        closeDialog()
        return

    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print("@               addtryentry               @")
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

    #dialogを閉じる

    if max(num_bind_list) == 0:
        print("if want also addtry1,2,3 , please set bind-column")


    addtryjob_lists_sum = []

    addtryjob_lists = createpre_addtryjob_lists(prejob_lists, myself_div,selectDir)


    #addtryjob_lists1 = createpre_addtryjob_lists4eachbind(prejob_lists, myself_div,selectDir,indexes,len_maxelemsub)
    addtryjob_lists1 = createpre_addtryjob_lists4eachparambind(prejob_lists,myself_div,selectDir,indexes,len_maxelemsub)

    addtryjob_lists2 = createpre_addtryjob_lists4bind(prejob_lists, myself_div,selectDir,indexes)

    ####20201120 edit (max assembled in folders#################################
    addtryjob_lists3 = createpre_addtryjob_lists4bind_allchiLdDir(prejob_lists,myself_div,selectDir,indexes)

    for elem in addtryjob_lists:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists1:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists2:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists3:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)
    ####20201120 edit (max assembled in folders#################################

    job_lists = ExecUtil.deleteDubjob_lists(TreeType, selectDir, addtryjob_lists_sum)
    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists, "atrye0", selectDir)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists1, "atrye1", selectDir)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atrye2", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists3, "atrye3", selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    #dialogを閉じる
    closeDialog()


def Pattern_exec():
    logging.debug(TreeType)
    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    ExecUtil.DictateScore_copy(TreeType, selectDir)

    endnode_name = os.path.basename(selectDir)
    no_use, temp_paramlist = CommonUtil.divname2num(endnode_name)
    num_param = len(temp_paramlist)

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    direction=[]
    directions=[]
    #directions.append(direction)
    tempdirection=[]


    directions4ML=[]
    #prejob_lists=[]
    #job_lists=[]

    active_index = []


    ################20210413 use fix_list########################
    #if ML_fix== True:

    #for i in range(len(ML_list)):
    #    if ML_list[i]!="ML":
    #                active_index.append(i)
    #    else:
    #        active_index = list(range(len(ML_list)))
    ################20210413 use fix_list########################

    for n in range(len(ML_list)):
        #if (rank_importance_list[n]<=num_var and not (ML_list[n]=="ML" and ML_fix==True)  ) and not fix_list[n]==True:
        if not (ML_list[n]=="ML" and ML_fix==True)  and not fix_list[n]==True:
            active_index.append(n)


    pattern = platformDir + "/" + PatternCode

    logging.debug(pattern)
    logging.debug(TreeType)

    if TreeType == "Binary_plusC" or TreeType == "fcPascal_plusC":
        pattern = pattern  + "_plusC"
        #print("Now _plusC innactive")

    logging.debug(pattern)

    if os.path.exists(pattern)==False:
        print("Pattern file is not exits")
        exit()
    else:
        f=open(pattern)
        x=f.read()
        f.close()
        lines = [i for i in re.split(r'\n',x) if i != '']
        length = len(lines)
        cut_lines = []
        merge_lines = []
        passed_lines = []
        #numpy_lines = []


        parent =  selectDir.split("/")[-1]
        logging.debug(parent)

        #20201107 lcg postpone
        #        lcg_flag=0
        #        for line in lines:
        #            if (lcg_flag != "0"):
        #                line = line_adaptedlcg(line,64)

        #need only max_sub
        #            line = line[0:len(active_index)]
        #            cut_lines.append(line)


        for line in lines:
            cut_line =line[0:len(active_index)]
            cut_line = ExecUtil.line_adaptedlcg(cut_line,256,lcg_flag,lcg_constant)
            cut_lines.append(cut_line)


        merge_lines = list(set(cut_lines))
        merge_lines.sort()

        for merge_line in merge_lines:

            char_direction=list(merge_line)
            num_direction=[int(s) for s in char_direction]
            #num_list=np.array(n_list)
            #lines_numpy.append(num_list)
            logging.debug(char_direction)

            directions4ML.append(num_direction)


    if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
        for n in range(len(directions4ML)):
            tempdirection=copy.deepcopy(base_direction)
            if len(active_index)!=0:
                for i,elem in enumerate(active_index):
                    #tempdirection = tempdirection[:elem]+ [directions4ML[n][i]] + tempdirection[elem+1:]
                    tempdirection = tempdirection[:elem]+ [attract(directions4ML[n][i],base_direction[elem])] + tempdirection[elem+1:]
            else:
                pass
            directions.append(tempdirection)

    elif TreeType=="Binary" or TreeType=="fcPascal":
        for n in range(len(directions4ML)):
            tempdirection=copy.deepcopy(base_direction)
            if len(active_index)!=0:
                for i,elem in enumerate(active_index):
                    #tempdirection = tempdirection[:elem]+ [directions4ML[n][i]] + tempdirection[elem+1:]
                    tempdirection = tempdirection[:elem]+ [attract(directions4ML[n][i],base_direction[elem])] + tempdirection[elem+1:]
            else:
                pass
            directions.append(tempdirection)

    else:
        for n in range(len(directions4ML)):
            tempdirection=copy.deepcopy(base_direction)
            if len(active_index)!=0:
                for i,elem in enumerate(active_index):
                    tempdirection = tempdirection[:elem]+ [directions4ML[n][i]] + tempdirection[elem+1:]
                    #tempdirection = tempdirection[:elem]+ [attract(directions4ML[n][i],base_direction[elem])] + tempdirection[elem+1:]
            else:
                pass
            directions.append(tempdirection)

    print(directions)

    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    
    pair_job_lists=[]
    for i in range(len(job_lists)):
        if i%2 == 0:
            pair_job_lists.append(job_lists[i//2])
        if i%2 == 1:
            pair_job_lists.append(job_lists[len(job_lists)-i//2-1])

    stat = showJobNumDialog(selectDir, myself_div, pair_job_lists)
    if stat != "OK":
        return

    pC_direction = []
    if TreeType == "fcPascal_plusC":
        pC_direction = ExecUtil.make_pCdirection(TreeType,selectDir )
                                 
        if pC_direction!=[]:
            temp_pC_list, temp_myself_div = ExecUtil.create_prejob_list(TreeType, pC_direction, selectDir)

        if pC_direction!= [] and (temp_pC_list in pair_job_lists) == False:
            pair_job_lists.append(temp_pC_list)
            logging.debug("pC exists on job_list")
        else:
            logging.debug("pC not exists on job_list")

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, pair_job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)


    try:
        if ('temp_myself_div' in locals()) and ('temp_pC_list' in locals()):
            ExecUtil.addNoteCsv2job_list(temp_myself_div, temp_pC_list, "pC" , selectDir)
    except:
        pass




    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    if addtry_flag == "0":
        closeDialog()
        return

    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print("@               addtryentry               @")
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")


    if max(num_bind_list) == 0:
        print("if want addtry2,3, please set bind-column")
        exit()

    addtryjob_lists_sum = []

    addtryjob_lists2 = createpre_addtryjob_lists4bind(prejob_lists, myself_div,selectDir,indexes)

    ####20201120 edit (max assembled in folders#################################
    addtryjob_lists3 = createpre_addtryjob_lists4bind_allchiLdDir(prejob_lists,myself_div,selectDir,indexes)


    for elem in addtryjob_lists2:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists3:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)
    ####20201120 edit (max assembled in folders#################################

    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, addtryjob_lists_sum)
    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atryp2", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists3, "atryp3", selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)
    #dialogを閉じる
    closeDialog()


def caseappend_routine(tempdirections, direction_elem, obj_flag,index):
    returndirections =[]
    if obj_flag=="-":
        for tempdirection in tempdirections:
            returndirections.append(tempdirection[:index]+[direction_elem]+tempdirection[index+1:])
        return returndirections
    else:
        if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
            for tempdirection in tempdirections:
                returndirections.append(tempdirection[:index]+[0]+tempdirection[index+1:])
                returndirections.append(tempdirection[:index]+[1]+tempdirection[index+1:])
                returndirections.append(tempdirection[:index]+[2]+tempdirection[index+1:])
            return returndirections
        else:
            for tempdirection in tempdirections:
                returndirections.append(tempdirection[:index]+[0]+tempdirection[index+1:])
                returndirections.append(tempdirection[:index]+[2]+tempdirection[index+1:])
            return returndirections

def attract(a,b):
    if localize == True:
        if a==2 and b==2:
            return 2
        if a==0 and b==0:
            return 0
        return a+b-1
    else:
        return a


def eachbind_exec():
    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    directions=[]
    tempdirection=[]

    np_importance_list = np.array(importance_list)
    rank_importance_list=np_importance_list.argsort()


    if max(num_bind_list) == 0:
        logging.debug("Please set column of bind")
        exit()

    iter3_list=[]
    iter2_list=[]

    iterator = product(range(3),repeat=len_maxelemsub)
    for idxs in iterator:
        iter3_list.append(list(idxs[::-1]))
    logging.debug(iter3_list)

    iterator = product(range(2),repeat=len_maxelemsub)
    for idxs in iterator:
        iter2_list.append(list(idxs[::-1]))
    logging.debug(iter2_list)

    #return

    directions = []
    directions.append(base_direction)

    for n in range(len_maxelemsub):
        #tempdirection0=copy.deepcopy(vector)
        #tempdirection1=copy.deepcopy(vector)
        #tempdirection2=copy.deepcopy(vector)

        #if TreeType=="Binary_plusC" and len(elem)!=0:
        if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
            tempdirection0=copy.deepcopy(base_direction)
            tempdirection1=copy.deepcopy(base_direction)

            #print elem[i]
            for i,elem in enumerate(indexes):

                if i!=0 and len(elem)!=0:#no need this judgement?
                    if base_direction[elem[n % len(elem)]]== 0:
                        tempdirection0 = tempdirection0[:elem[n % len(elem)]] + [1] + tempdirection0[elem[n % len(elem)]+1:]
                        tempdirection1 = tempdirection1[:elem[n % len(elem)]] + [attract(2,base_direction[elem[n % len(elem)]])] + tempdirection1[elem[n % len(elem)]+1:]
                    elif base_direction[elem[n % len(elem)]]== 1:
                        tempdirection0 = tempdirection0[:elem[n % len(elem)]] + [2] + tempdirection0[elem[n % len(elem)]+1:]
                        tempdirection1 = tempdirection1[:elem[n % len(elem)]] + [0] + tempdirection1[elem[n % len(elem)]+1:]
                    else:
                        tempdirection0 = tempdirection0[:elem[n % len(elem)]] + [1] + tempdirection0[elem[n % len(elem)]+1:]
                        tempdirection1 = tempdirection1[:elem[n % len(elem)]] + [attract(0,base_direction[elem[n % len(elem)]])] + tempdirection1[elem[n % len(elem)]+1:]
            directions.append(tempdirection0)
            directions.append(tempdirection1)

        elif TreeType=="Binary" or TreeType=="fcPascal":
            tempdirection0=copy.deepcopy(base_direction)
            tempdirection1=copy.deepcopy(base_direction)

            for i,elem in enumerate(indexes):

                #print(elem[n % len(elem)])
                if i!=0 and len(elem)!=0:#no need this judgement?
                    tempdirection0 = tempdirection0[:elem[n % len(elem)]] + [attract(2,base_direction[elem[n % len(elem)]])] + tempdirection0[elem[n % len(elem)]+1:]
                    tempdirection1 = tempdirection1[:elem[n % len(elem)]] + [attract(0,base_direction[elem[n % len(elem)]])] + tempdirection1[elem[n % len(elem)]+1:]
            directions.append(tempdirection0)
            directions.append(tempdirection1)


        else:
            tempdirection0=copy.deepcopy(base_direction)

            for i,elem in enumerate(indexes):

                #print(elem[n % len(elem)])
                if i!=0 and len(elem)!=0:#no need this judgement?
                    if base_direction[elem[n % len(elem)]]== 0:
                        tempdirection0 = tempdirection0[:elem[n % len(elem)]] + [attract(2,base_direction[elem[n % len(elem)]])] + tempdirection0[elem[n % len(elem)]+1:]
                    else:
                        tempdirection0 = tempdirection0[:elem[n % len(elem)]] + [attract(0,base_direction[elem[n % len(elem)]])] + tempdirection0[elem[n % len(elem)]+1:]
            directions.append(tempdirection0)

    logging.debug(directions)

    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)

    stat = showJobNumDialog(selectDir, myself_div, job_lists)
    if stat != "OK":
        return

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    if addtry_flag == "0":
        closeDialog()
        return

    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print("@               addtryentry               @")
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")


#def createpre_addtryjob_lists4bind(Firstfinished_lists,myself_div,startDir,indexes):

    addtryjob_lists_sum =[]

    addtryjob_lists1 = createpre_addtryjob_lists4eachbind(prejob_lists, myself_div,selectDir,indexes,len_maxelemsub)

    print(" value_test1")

    addtryjob_lists2 = createpre_addtryjob_lists4bind(prejob_lists, myself_div,selectDir,indexes)

    print(" value_test2")

    ####20201120 edit (max assembled in folders#################################
    addtryjob_lists3 = createpre_addtryjob_lists4bind_allchiLdDir(prejob_lists,myself_div,selectDir,indexes)
    ####20201120 edit (max assembled in folders#################################

    print(" value_test3")

    for elem in addtryjob_lists1:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists2:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists3:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    print(addtryjob_lists_sum)

    logging.debug(addtryjob_lists_sum)

    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, addtryjob_lists_sum)
    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)
    
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists1, "atryeb1", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atryeb2", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists3, "atryeb3", selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)
    
    #dialogを閉じる
    closeDialog()


def Patternbind_exec():
    logging.debug(TreeType)
    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    ExecUtil.DictateScore_copy(TreeType, selectDir)

    endnode_name = os.path.basename(selectDir)
    no_use, temp_paramlist = CommonUtil.divname2num(endnode_name)
    num_param = len(temp_paramlist)

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    direction=[]
    directions=[]
    #directions.append(direction)
    tempdirection=[]

    directions4sub=[]

    if max(num_bind_list) == 0:
        print("Please set column of bind")
        exit()

    pattern = platformDir + "/" + PatternCode

    logging.debug(pattern)
    logging.debug(TreeType)

    if TreeType == "Binary_plusC" or TreeType == "fcPascal_plusC":
        pattern = pattern  + "_plusC"
        #print("Now _plusC innactive")

    logging.debug(pattern)

    if os.path.exists(pattern)==False:
        logging.debug("Pattern file is not exits")
        exit()
    else:
        f=open(pattern)
        x=f.read()
        f.close()
        lines = [i for i in re.split(r'\n',x) if i != '']
        length = len(lines)
        cut_lines = []
        merge_lines = []
        passed_lines = []
        #numpy_lines = []


        parent =  selectDir.split("/")[-1]
        logging.debug(parent)

    #20201107 lcg postpone
    #        lcg_flag=0

    #        for line in lines:
    #            if (lcg_flag != "0"):
    #                line = line_adaptedlcg(line,64)

    #need only max_sub
    #            line = line[0:len_maxelemsub]
    #            cut_lines.append(line)

        for line in lines:
            cut_line =line[0:len_maxelemsub]
            cut_line = ExecUtil.line_adaptedlcg(cut_line,256,lcg_flag,lcg_constant)
            cut_lines.append(cut_line)


        merge_lines = list(set(cut_lines))
        merge_lines.sort()

        for merge_line in merge_lines:

            char_direction=list(merge_line)
            num_direction=[int(s) for s in char_direction]
            #num_list=np.array(n_list)
            #lines_numpy.append(num_list)
            logging.debug(char_direction)

            directions4sub.append(num_direction)


    if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
        for n in range(len(directions4sub)):
            tempdirection=copy.deepcopy(base_direction)
            for counter,index in enumerate(indexes):
                if len(index)!=0 and counter!=0:
                    for i,elem in enumerate(index):
                        #tempdirection = tempdirection[:elem]+ [directions4sub[n][i]] + tempdirection[elem+1:]
                        tempdirection = tempdirection[:elem]+ [attract(directions4sub[n][i],base_direction[elem])] + tempdirection[elem+1:]
                else:
                    pass
            directions.append(tempdirection)

    elif TreeType=="Binary" or TreeType=="fcPascal":
        for n in range(len(directions4sub)):
            tempdirection=copy.deepcopy(base_direction)
            for counter,index in enumerate(indexes):
                if len(index)!=0 and counter!=0:
                    for i,elem in enumerate(index):
                        #tempdirection = tempdirection[:elem]+ [directions4sub[n][i]] + tempdirection[elem+1:]
                        tempdirection = tempdirection[:elem]+ [attract(directions4sub[n][i],base_direction[elem])] + tempdirection[elem+1:]
                else:
                    pass
            directions.append(tempdirection)

    else:
        for n in range(len(directions4sub)):
            tempdirection=copy.deepcopy(base_direction)
            for counter,index in indexes:
                if len(index)!=0 and counter!=0:
                    for i,elem in enumerate(index):
                        tempdirection = tempdirection[:elem]+ [directions4sub[n][i]] + tempdirection[elem+1:]
                        #tempdirection = tempdirection[:elem]+ [attract(directions4sub[n][i],base_direction[elem])] + tempdirection[elem+1:]
                else:
                    pass
            directions.append(tempdirection)

    logging.debug(directions)

    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    
    pair_job_lists=[]
    for i in range(len(job_lists)):
        if i%2 == 0:
            pair_job_lists.append(job_lists[i//2])
        if i%2 == 1:
            pair_job_lists.append(job_lists[len(job_lists)-i//2-1])

    stat = showJobNumDialog(selectDir, myself_div, pair_job_lists)
    if stat != "OK":
        return


    pC_direction = []
    if TreeType == "fcPascal_plusC":
        pC_direction = ExecUtil.make_pCdirection(TreeType,selectDir )
                                 
        if pC_direction!=[]:
            temp_pC_list, temp_myself_div = ExecUtil.create_prejob_list(TreeType, pC_direction, selectDir)

        if pC_direction!= [] and (temp_pC_list in pair_job_lists) == False:
            pair_job_lists.append(temp_pC_list)
            logging.debug("pC exists on job_list")
        else:
            logging.debug("pC not exists on job_list")


    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, pair_job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    try:
        if ('temp_myself_div' in locals()) and ('temp_pC_list' in locals()):
            ExecUtil.addNoteCsv2job_list(temp_myself_div, temp_pC_list, "pC" , selectDir)
    except:
        pass

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    if addtry_flag == "0":
        closeDialog()
        return

    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print("@               addtryentry               @")
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")


    addtryjob_lists_sum = []

    addtryjob_lists2 = createpre_addtryjob_lists4bind(prejob_lists, myself_div,selectDir,indexes)

    ####20201120 edit (max assembled in folders#################################
    addtryjob_lists3 = createpre_addtryjob_lists4bind_allchiLdDir(prejob_lists,myself_div,selectDir,indexes)


    for elem in addtryjob_lists2:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists3:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)
    ####20201120 edit (max assembled in folders#################################

    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, addtryjob_lists_sum)
    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atryep2", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists3, "atryep3", selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    #dialogを閉じる
    closeDialog()


def allbind_exec():
    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    direction=[]
    directions=[]
    #directions.append(direction)
    tempdirection=[]


    if max(num_bind_list) == 0:
        print("Please set column of bind")
        exit()


    iter3_list=[]
    iter2_list=[]

    iterator = product(range(3),repeat=len_maxelemsub)
    for idxs in iterator:
        iter3_list.append(list(idxs[::-1]))
    logging.debug(iter3_list)

    iterator = product(range(2),repeat=len_maxelemsub)
    for idxs in iterator:
        iter2_list.append(list(idxs[::-1]))
    logging.debug(iter2_list)


    directions = []
    #directions.append(base_direction)


    if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
        for n in range(len(iter3_list)):
            tempdirection=copy.deepcopy(base_direction)
            for counter,index in enumerate(indexes):
                if len(index)!=0 and counter !=0:
                    for i,elem in enumerate(index):
                        #tempdirection = tempdirection[:elem]+ [iter3_list[n][i]] + tempdirection[elem+1:]
                        tempdirection = tempdirection[:elem]+ [attract(iter3_list[n][i],base_direction[elem])] + tempdirection[elem+1:]                        
                else:
                    pass
            directions.append(tempdirection)
    elif TreeType=="Binary" or TreeType=="fcPascal":
        for n in range(len(iter2_list)):
            tempdirection=copy.deepcopy(base_direction)
            for counter,index in enumerate(indexes):
                if len(index)!=0 and counter !=0:
                    for i,elem in enumerate(index):
                        tempdirection = tempdirection[:elem]+ [attract(2*iter2_list[n][i],base_direction[elem])] + tempdirection[elem+1:]
                else:
                    pass
            directions.append(tempdirection)
    else:
        for n in range(len(iter2_list)):
            tempdirection=copy.deepcopy(base_direction)
            for counter, index in enumerate(indexes):
                if len(index)!=0 and counter !=0:
                    for i,elem in enumerate(index):
                        tempdirection = tempdirection[:elem]+ [2*iter2_list[n][i]] + tempdirection[elem+1:]

                        #tempdirection = tempdirection[:elem]+ [iter2_list[n][i]] + tempdirection[elem+1:]
                else:
                    pass
            directions.append(tempdirection)

    logging.debug(directions)

    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    
    pair_job_lists=[]
    for i in range(len(job_lists)):
        if i%2 == 0:
            pair_job_lists.append(job_lists[i//2])
        if i%2 == 1:
            pair_job_lists.append(job_lists[len(job_lists)-i//2-1])

    stat = showJobNumDialog(selectDir, myself_div, job_lists)
    if stat != "OK":
        return

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, pair_job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    if addtry_flag == "0":
        closeDialog()
        return
        
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print("@               addtryentry               @")
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")


    #20201229edit

    addtryjob_lists_sum = []


    addtryjob_lists2 = createpre_addtryjob_lists4bind(prejob_lists, myself_div,selectDir,indexes)


    ####20201120 edit (max assembled in folders#################################
    addtryjob_lists3 = createpre_addtryjob_lists4bind_allchiLdDir(prejob_lists,myself_div,selectDir,indexes)


    for elem in addtryjob_lists2:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists3:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)
    ####20201120 edit (max assembled in folders#################################


    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, addtryjob_lists_sum)
    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atryab2", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists3, "atryab3", selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    #dialogを閉じる
    closeDialog()

#def ignite_target(seed_job_lists, myself_div,selectDir,sourceDir,platformDir, nProcs, nCpu_perCase):

def eachobj_exec():
    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    directions=[]
    tempdirection=[]

    np_importance_list = np.array(importance_list)
    rank_importance_list=np_importance_list.argsort()

    directions.append(base_direction)
    for n in range(len(parent_list)):
        if obj_list[n]=="obj" and fix_list[n]==False:
            if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
                if base_direction[n]==0:
                    tempdirection = base_direction[:n] + [attract(1,base_direction[n])]  + base_direction[n+1:]
                    directions.append(tempdirection)
                    tempdirection = base_direction[:n] + [attract(2,base_direction[n])] + base_direction[n+1:]
                    directions.append(tempdirection)
                elif base_direction[n]==1:
                    tempdirection = base_direction[:n] + [attract(2,base_direction[n])] + base_direction[n+1:]
                    directions.append(tempdirection)
                    tempdirection = base_direction[:n] + [attract(0,base_direction[n])] + base_direction[n+1:]
                    directions.append(tempdirection)
                else:
                    tempdirection = base_direction[:n] + [attract(1,base_direction[n])] + base_direction[n+1:]
                    directions.append(tempdirection)
                    tempdirection = base_direction[:n] + [attract(0,base_direction[n])] + base_direction[n+1:]
                    directions.append(tempdirection)

            #elif TreeType=="Binary" or TreeType=="fcPascal":
            #tempdirection = base_direction[:n] + [2] + base_direction[n+1:]
            #directions.append(tempdirection)
            #tempdirection = base_direction[:n] + [0] + base_direction[n+1:]
            #directions.append(tempdirection)

            else:
                if base_direction[n]==0:
                    tempdirection = base_direction[:n] + [2] + base_direction[n+1:]
                    directions.append(tempdirection)
                else:
                    tempdirection = base_direction[:n] + [0] + base_direction[n+1:]
                    directions.append(tempdirection)
        else:
            pass

    logging.debug(directions)

        
    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    
    stat = showJobNumDialog(selectDir, myself_div, job_lists)
    if stat != "OK":
        return

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    if addtry_flag == "0":
        closeDialog()
        return
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print("@               addtryentry               @")
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

    addtryjob_lists_sum = []

    addtryjob_lists = createpre_addtryjob_lists4eachobj(prejob_lists,myself_div,selectDir)
 

    addtryjob_lists2 = createpre_addtryjob_lists4bind(prejob_lists, myself_div,selectDir,indexes)


    ####20201120 edit (max assembled in folders#################################
    addtryjob_lists3 = createpre_addtryjob_lists4bind_allchiLdDir(prejob_lists,myself_div,selectDir,indexes)

    for elem in addtryjob_lists:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists2:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists3:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)
    ####20201120 edit (max assembled in folders#################################


    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, addtryjob_lists_sum)
    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atryeo0", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atryeo2", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists3, "atryeo3", selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    #dialogを閉じる
    closeDialog()


def Patternobj_exec():
    logging.debug(TreeType)
    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    endnode_name = os.path.basename(selectDir)
    no_use, temp_paramlist = CommonUtil.divname2num(endnode_name)
    num_param = len(temp_paramlist)

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    direction=[]
    directions=[]
    #directions.append(direction)
    tempdirection=[]


    directions4ML=[]
    #prejob_lists=[]
    #job_lists=[]

    obj_index = []

    for i in range(len(obj_list)):
        if obj_list[i]=="obj" and fix_list[i]==False:
            obj_index.append(i)

    #edit_20201027
    #for i in range(max(num_bind_list)):
    #for i in range(len(num_bind_list)):

    #indexes.append([j for j,x in enumerate(num_bind_list) if x==i])
    #print(indexes) 
    #len_maxelemsub = max([len(x) for x in indexes])


    pattern = platformDir + "/" + PatternCode

    logging.debug(pattern)
    logging.debug(TreeType)

    if TreeType == "Binary_plusC" or TreeType == "fcPascal_plusC":
        pattern = pattern  + "_plusC"
        #print("Now _plusC innactive")

    logging.debug(pattern)

    if os.path.exists(pattern)==False:
        print("Pattern file is not exits")
        exit()
    else:
        f=open(pattern)
        x=f.read()
        f.close()
        lines = [i for i in re.split(r'\n',x) if i != '']
        length = len(lines)
        cut_lines = []
        merge_lines = []
        passed_lines = []
        #numpy_lines = []


        parent =  selectDir.split("/")[-1]
        logging.debug(parent)

        #20201107 lcg postpone
        #        lcg_flag=0

        #        for line in lines:
        #            if (lcg_flag != "0"):
        #                line = line_adaptedlcg(line,64)


        #need only max_sub
        #line = line[0:len(obj_index)]
        #cut_lines.append(line)


        for line in lines:
            cut_line =line[0:len(obj_index)]
            cut_line = ExecUtil.line_adaptedlcg(cut_line,256,lcg_flag,lcg_constant)
            cut_lines.append(cut_line)

        merge_lines = list(set(cut_lines))
        merge_lines.sort()

        for merge_line in merge_lines:

            char_direction=list(merge_line)
            num_direction=[int(s) for s in char_direction]
            #num_list=np.array(n_list)
            #lines_numpy.append(num_list)
            logging.debug(char_direction)

            directions4ML.append(num_direction)


    if TreeType=="Binary_plusC" or TreeType=="fcPascal_plusC":
        for n in range(len(directions4ML)):
            tempdirection=copy.deepcopy(base_direction)
            if len(obj_index)!=0:
                for i,elem in enumerate(obj_index):
                    #tempdirection = tempdirection[:elem]+ [directions4ML[n][i]] + tempdirection[elem+1:]
                    tempdirection = tempdirection[:elem]+ [attract(directions4ML[n][i],base_direction[elem])] + tempdirection[elem+1:]
            else:
                pass
            directions.append(tempdirection)

    elif TreeType=="Binary" or TreeType=="fcPascal":
        for n in range(len(directions4ML)):
            tempdirection=copy.deepcopy(base_direction)
            if len(obj_index)!=0:
                for i,elem in enumerate(obj_index):
                        #tempdirection = tempdirection[:elem]+ [directions4ML[n][i]] + tempdirection[elem+1:]
                    tempdirection = tempdirection[:elem]+ [attract(directions4ML[n][i],base_direction[elem])] + tempdirection[elem+1:]
            else:
                pass
            directions.append(tempdirection)

    else:
        for n in range(len(directions4ML)):
            tempdirection=copy.deepcopy(base_direction)
            if len(obj_index)!=0:
                for i,elem in enumerate(obj_index):
                    tempdirection = tempdirection[:elem]+ [directions4ML[n][i]] + tempdirection[elem+1:]
                    #tempdirection = tempdirection[:elem]+ [attract(directions4ML[n][i],base_direction[elem])] + tempdirection[elem+1:]
            else:
                pass
            directions.append(tempdirection)

    logging.debug(directions)

    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    
    pair_job_lists=[]
    for i in range(len(job_lists)):
        if i%2 == 0:
            pair_job_lists.append(job_lists[i//2])
        if i%2 == 1:
            pair_job_lists.append(job_lists[len(job_lists)-i//2-1])

    stat = showJobNumDialog(selectDir, myself_div, pair_job_lists)
    if stat != "OK":
        return

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, pair_job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    if addtry_flag == "0":
        closeDialog()
        return
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
    print("@               addtryentry               @")
    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")

    addtryjob_lists_sum = []

 
    addtryjob_lists2 = createpre_addtryjob_lists4bind(prejob_lists, myself_div,selectDir,indexes)


    ####20201120 edit (max assembled in folders#################################
    addtryjob_lists3 = createpre_addtryjob_lists4bind_allchiLdDir(prejob_lists,myself_div,selectDir,indexes)

 
    for elem in addtryjob_lists2:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)

    for elem in addtryjob_lists3:
        if elem!=[]:
            addtryjob_lists_sum.append(elem)
    ####20201120 edit (max assembled in folders#################################


    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, addtryjob_lists_sum)
    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists2, "atryap2", selectDir)
    ExecUtil.addNoteCsv2job_lists(myself_div, addtryjob_lists3, "atryap3", selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    #dialogを閉じる
    closeDialog()



def allobj_exec():

    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    direction=[]
    directions=[]
    #directions.append(direction)
    tempdirection=[]

    np_importance_list = np.array(importance_list)
    rank_importance_list=np_importance_list.argsort()

    for n in range(len(parent_list)):
        direction.append(1)
    directions.append(direction)

    for n in range(len(parent_list)):
        directions = caseappend_routine(directions, base_direction[n], obj_list[n],n)

    logging.debug("@@######@@#")
    logging.debug(directions)
    logging.debug("@@######@@#")

    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    logging.debug(prejob_lists)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    
    pair_job_lists=[]
    for i in range(len(job_lists)):
        if i%2 == 0:
            pair_job_lists.append(job_lists[i//2])
        if i%2 == 1:
            pair_job_lists.append(job_lists[len(job_lists)-i//2-1])

    stat = showJobNumDialog(selectDir, myself_div, job_lists)
    if stat != "OK":
        return

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, pair_job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)
    
    #dialogを閉じる
    closeDialog()


def select_exec():

    #parentDir = "/".join(selectDir.split("/")[:-1])
    parent_div,parent_list = CommonUtil.divname2num(os.path.basename(selectDir))

    logging.debug("test point")
    logging.debug(parent_div)
    logging.debug(parent_list)

    directions=[]
    tempdirection=[]


    np_importance_list = np.array(importance_list)
    rank_importance_list=np_importance_list.argsort()

    directions.append(base_direction)
        
    prejob_lists, myself_div = ExecUtil.create_prejob_lists(TreeType,directions, selectDir)
    job_lists = ExecUtil.deleteDubjob_lists(TreeType,selectDir, prejob_lists)
    
    stat = showJobNumDialog(selectDir, myself_div, job_lists)
    if stat != "OK":
        return

    ###################note.csvの追加文字列確認ダイアログ追加############################
    title = u"Writing note"
    mess = u"Please write note-attribute(showed note-column)"
    (stat, inputText) = inputDialog(title, mess)
    if stat == "OK":
        note = inputText
    else:
        note = ""
    ###################note.csvの追加文字列確認ダイアログ追加############################

    showDialog()

    caseDirs = ExecUtil.createCaseDirs(projDir, selectDir, job_lists, myself_div)

    ExecUtil.addNoteCsv2job_lists(myself_div, job_lists, note, selectDir)

    ExecUtil.assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv)

    #dialogを閉じる
    closeDialog()




def showJobNumDialog(myselfDir, div_num,job_lists):
    
    title = u"Confirmation"
    mess = u"The number of execution is" + "\n"
    mess += "" + str(len(job_lists)) + u"   items from the node \n"
    mess += "          " + os.path.basename(myselfDir) + " \n"
    mess += u"Will you start?"
    
        
    excerpt_lists = "Lists of exec_node \n\n"

    if len(job_lists) != 0:
        max_column = 280
        max_row = 1280
        num_excerpt = min(len(job_lists),max_row)
        for i in range(num_excerpt):
            excerpt_list = CommonUtil.num2divname(div_num,job_lists[i])
            if len(excerpt_list) <= max_column:
                excerpt_lists += excerpt_list + " \n"
            else:
                excerpt_lists += excerpt_list[0:max_column] + "... \n"
        if len(job_lists) > max_row:
            excerpt_lists += "..."
    
    stat = okCancelDialog(title, mess, excerpt_lists )
    return stat



def inputDialog(title, mess):

    class dialog:

        def __init__(self, title, mess):
            self.title = title
            self.mess = mess
            self.status = "CANCEL"
            self.inputText = ""

        def setupDialog(self, object):
            Dialog.setObjectName("Dialog")
            self.verticalLayout = QVBoxLayout(Dialog)
            #label
            self.label = QLabel(Dialog)
            self.label.setText(self.mess)
            self.verticalLayout.addWidget(self.label)
            #lineEdit配置
            self.lineEdit = QLineEdit(Dialog)
            self.verticalLayout.addWidget(self.lineEdit)
            #cancel, ok button 配置
            #  spacer配置
            self.horizontalLayout = QHBoxLayout()
            spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
            self.horizontalLayout.addItem(spacerItem)
            #  calcelButton
            self.pushButtonCancel = QPushButton(Dialog)
            self.pushButtonCancel.setText(u"Cancel")
            self.horizontalLayout.addWidget(self.pushButtonCancel)
            #  okButton
            self.pushButtonOk = QPushButton(Dialog)
            self.pushButtonOk.setText(u"OK")
            self.horizontalLayout.addWidget(self.pushButtonOk)
            #  button配置
            self.verticalLayout.addLayout(self.horizontalLayout)
            #event
            QMetaObject.connectSlotsByName(Dialog)
            self.pushButtonCancel.clicked.connect(self.onCancel)
            self.pushButtonOk.clicked.connect(self.onOk)

        def close(self, *args):
            Dialog.close()

        def onCancel(self):
            self.status = "CANCEL"
            self.inputText = ""
            self.close()

        def onOk(self):
            self.status = "OK"
            self.inputText = self.lineEdit.text()
            self.close()

    #app = QApplication([])
    Dialog = QDialog()
    ui = dialog(title, mess)
    ui.setupDialog(Dialog)
    Dialog.show()
    app.exec_()
    return (ui.status, ui.inputText)


def okCancelDialog(title, mess,excerpt_lists):

    class messageDialog:

        def __init__(self, title, mess, excerpt_lists):
            self.title = title
            self.mess = mess
            self.excerpt_lists = excerpt_lists
            self.status = "CANCEL"

        def setupDialog(self,object):
            Dialog.setObjectName("Dialog")
            self.dialog = Dialog
            self.verticalLayout = QVBoxLayout(Dialog)
            #label
            self.label = QLabel(Dialog)
            self.label.setText(self.mess)
            self.verticalLayout.addWidget(self.label)

            self.horizontalLayout = QHBoxLayout()
            #spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
            #self.horizontalLayout.addItem(spacerItem)

            #cancelButton
            self.pushButtonCancel = QPushButton(Dialog)
            self.pushButtonCancel.setText(u"Cancel")
            self.horizontalLayout.addWidget(self.pushButtonCancel)
            #OKbutton
            self.pushButtonOk = QPushButton(Dialog)
            self.pushButtonOk.setText(u"OK")
            self.horizontalLayout.addWidget(self.pushButtonOk)

            spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
            self.horizontalLayout.addItem(spacerItem)

            self.verticalLayout.addLayout(self.horizontalLayout)

            #excerpt_lists
            self.below = QTextEdit(Dialog)
            self.below.setText(self.excerpt_lists)
            self.verticalLayout.addWidget(self.below)

            QMetaObject.connectSlotsByName(Dialog)
            self.pushButtonCancel.clicked.connect(self.onCancel)
            self.pushButtonOk.clicked.connect(self.onOk)

        def close(self, *args):
            self.dialog.close()

        def onCancel(self):
            self.status = "CANCEL"
            self.close()

        def onOk(self):
            self.status = "OK"
            self.close()

    #app = QApplication([])
    Dialog = QDialog()
    ui = messageDialog(title, mess,excerpt_lists)
    ui.setupDialog(Dialog)
    Dialog.show()
    app.exec_()
    return ui.status

    # #msgBox = QMessageBox()
    # #res = msgBox.information(QDialog(), title, mess, msgBox.Cancel, msgBox.Ok)
    # msgBox = QMessageBox()
    # res = msgBox.information(QDialog(), title, mess, msgBox.Cancel, msgBox.Ok)
    # if res == msgBox.Ok:
    #     ans = "OK"
    # else:
    #     ans = "CANCEL"
    # return ans


# 64length
#def line_adaptedlcg(line,length):
#    mod_length = length
#    return_line=""
#    temp=0
#    for i in range(length):
#        return_line += line[(12^i % mod_length)-1]
#constant is 3,7,11,15,19,23,27,31
#        temp = temp*33 + lcg_constant
#        return_line += line[(temp % mod_length)]
#    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
#    print(mod_length, return_line)
#    return return_line




if __name__ == "__main__":

    logging.debug(sys.argv)
    nProcs = sys.argv[1]
    nCpu_perCase = sys.argv[2]
    selectDir = sys.argv[3]
    projDir = sys.argv[4]
    platformDir = sys.argv[5]
    learnDir = sys.argv[6]
    onlyCsv = sys.argv[7]
    TreeType = sys.argv[8]
    PatternCode = sys.argv[9]
    num_var = sys.argv[10]
    ML_fix = sys.argv[11]
    localize = sys.argv[12]
    lcg_flag = sys.argv[13]
    lcg_constant = int(sys.argv[14])
    addtry_flag = sys.argv[15]
    
    funcname = sys.argv[16]

    #targetPath = "/".join(sourceDir.split("/")[:-1])

    #nProcs = "1" 
    #nCpu_perCase = "1"
    #selectDir = os.getenv("HOME") + "/test/div2_11111111"
    #sourceDir = os.getenv("HOME") + "/test/div2_11111111"

    main_select_div,_ = CommonUtil.divname2num(os.path.basename(selectDir))

    if (main_select_div<=3) and (TreeType=="fcPascal" or TreeType=="fcPascal_plusC"):
        print("fcPascal validates only when div-number of select-node is 4 or more.")
        exit()

    nProcs = int(nProcs)
    num_var = int(num_var)
    nCpu_perCase = int(nCpu_perCase)
    #f = open(platformDir + "/seed_job_list.csv","r")
    #    if os.path.exists(projDir + "/seed_job_list.csv") == True:
    #        main_f = open(projDir + "/seed_job_list.csv","r")
    #        main_reader = csv.reader(main_f)
    #        seed_job_list = [main_row for main_row in main_reader]
    #        print seed_job_list
    #        main_f.close()
    #    else:
    #        seed_job_lists = []
    if os.path.exists(projDir + "/seed_direction_info.csv") == True:
        main_f2 = open(projDir + "/seed_direction_info.csv","r")
        main_reader2 = csv.reader(main_f2)
        seed_direction_info = [main_row2 for main_row2 in main_reader2]
        seed_list=seed_direction_info[0]


        base_direction=[0] * len(seed_list)

        for main_iterator in range(len(seed_list)):
            if seed_list[main_iterator]=="Inappropriate":
                logging.debug("this direction is invalid")
                exit()
            if seed_list[main_iterator]=="Up":
                base_direction[main_iterator]=2
            elif seed_list[main_iterator]=="Down":
                base_direction[main_iterator]=0
            else:
                base_direction[main_iterator]=1

        ML_list=seed_direction_info[1]
        importance_list=seed_direction_info[2]
        obj_list=seed_direction_info[3]
        bind_list=seed_direction_info[4]

        logging.debug(seed_direction_info)
        main_f2.close()
    else:
        seed_direction_info = []

    aim_header = []

    if os.path.exists(learnDir + "/aim_header.csv"):
        logging.debug("tryread_header")
        try:
            #main_f3 = open(projDir + "/aim_header.csv")
            main_f3 = open(learnDir + "/aim_header.csv")
            main_header_string = main_f3.read();main_f3.close()
            main_header_list = main_header_string[:-1].split(',')
            logging.debug("tryread_header2")
            for main_j in range(len(main_header_list)):
                aim_header.append(main_header_list[main_j])
            logging.debug("tryread_success")

        except:

            aim_header.append("lower_aim4s")
            for main_j in range(len(main_header_list)-1):
                aim_header.append("lower")
    logging.debug("main_header at Executor_Table is")
    logging.debug(aim_header)

    value_header = CommonUtil.get_value_header(learnDir)

    #ML_fix=False
    if ML_fix == "0":
        ML_fix = False
    else:
        ML_fix = True

    #make num_bind_list, indexes, len_maxsubs
    num_bind_list=[]
    fix_list =[]
    indexes = []
    for main_iterator in range(len(bind_list)):
        try:
            if ML_fix==False or ML_list[main_iterator] != "ML":
                num_bind_list.append(int(bind_list[main_iterator][len("sub"):]))
            else:
                num_bind_list.append(0)
        except:
            num_bind_list.append(0)
        if bind_list[main_iterator] =="fix":
            fix_list.append(True)
        else:
            fix_list.append(False)


    for main_iterator in range(max(num_bind_list)+1):
        #index 0 means "score", other 1,2,3.. is sub1,sub2,sub3..
        indexes.append([main_j for main_j,main_x in enumerate(num_bind_list) if main_x==main_iterator])
        #len_maxelemsub = max([len(main_x) for main_x in indexes])
    if len(indexes) == 1:
        len_maxelemsub = max([len(main_x) for main_x in indexes])
    else:
        len_maxelemsub = max([len(main_x) for main_x in indexes[1:]])

    #for pattern exec,allbind, possible need maxlen
    #len_maxelemsub = max([len(main_x) for main_x in indexes])

    if localize == "0":
        localize = False
    else:
        localize = True
    #step to the execution code
    eval(funcname)()

