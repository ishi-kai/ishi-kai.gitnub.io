#!/usr/bin/python3
# -*- coding: utf-8 -*-
#
#   startingDialog.py
#
#       起動中の状況を表示するdialog
#

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import sys, os
import threading
import time

#-----------------------
#  Ui_mainWindow class
#-----------------------
class Ui_MainWindow(object):
    """ GUI作成用class"""

    #
    #  setupUi
    #----------
    def setupUi(self, MainWindow):
        """ GUIのpartsをセットアップする"""
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(376, 202)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QLabel(self.centralwidget)
        self.label.setText("")
        self.label.setPixmap(QPixmap("optPlatform.png"))
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.label_2 = QLabel(self.centralwidget)
        font = QFont()
        font.setFamily("Ubuntu Mono")
        font.setPointSize(30)
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.horizontalLayout.addWidget(self.label_2)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.label_ver = QLabel(self.centralwidget)
        font = QFont()
        font.setFamily("Ubuntu Mono")
        self.label_ver.setFont(font)
        self.label_ver.setAutoFillBackground(False)
        self.label_ver.setAlignment(Qt.AlignCenter)
        self.label_ver.setObjectName("label_ver")
        self.verticalLayout.addWidget(self.label_ver)
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.label_runCont = QLabel(self.centralwidget)
        font = QFont()
        font.setFamily("Ubuntu Mono")
        self.label_runCont.setFont(font)
        self.label_runCont.setObjectName("label_runCont")
        self.horizontalLayout_2.addWidget(self.label_runCont)
        self.pushButton = QPushButton(self.centralwidget)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy)
        font = QFont()
        font.setFamily("Ubuntu Mono")
        self.pushButton.setFont(font)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout_2.addWidget(self.pushButton)
        self.verticalLayout.addLayout(self.horizontalLayout_2)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QCoreApplication.translate
        self.label_2.setText(_translate("MainWindow", "OptParaSol"))
        self.label_ver.setText(_translate("MainWindow", "Version  1.00"))
        self.label_runCont.setText(_translate("MainWindow", "TextLabel"))
        self.pushButton.setText(_translate("MainWindow", "close"))

#------------------
#  winApp class
#------------------
class winApp(Ui_MainWindow):
    """ GUIを表示する。
    Ui_MainWindow classを継承"""

    def __init__(self):
        global MainWindow
        #GUIのpartsを配置
        self.setupUi(MainWindow)
        #タイトルバーを非表示設定
        MainWindow.setWindowFlags((Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint))
        #signalの設定
        self.pushButton.clicked.connect(self.close)
        #MainWindowを画面中央に表示させる
        #  画面サイズを取得
        ap = qApp
        desktop = ap.desktop()
        geometry = desktop.screenGeometry()
        #  MainWindowサイズを取得
        framesize = MainWindow.frameSize()
        #  画面中央に移動
        MainWindow.move(geometry.width() // 2 - framesize.width() // 2, geometry.height() // 2 - framesize.height() // 2)
        #labelの内容を設定
        self.label_runCont.setText("Welcome to OptParaSol!!")
        #変数の設定
        self.startingFileName = os.getenv("startingFile")   #起動時の読み込みfile
        self.startingFile = ""
        self.timerCount = 0

    #
    #  close
    #---------
    def close(self, *args):
        """ MainWindowを閉じる"""
        self.timerCount = 300       #theadを停止
        qApp.quit()                 #close

    #
    #  main
    #--------
    def main(self):
        """ mainの処理"""
        global MainWindow
        #GUI表示
        MainWindow.show()
        #初期化
        self.initialize()

    #
    #  initialize
    #-------------
    def initialize(self):
        """ 初期化"""
        #OptPlatformのversionを設定
        f = open(os.getenv("OptPlatform") + "/version")
        version = f.read(); f.close()
        self.label_ver.setText("Version " + version)
        #threadを起動
        th = threading.Thread(target=self.readInputData)
        th.start()

    #
    #  readInputData
    #----------------
    def readInputData(self):
        """ 起動状況を読み込むthread
        最大5秒まで表示する。"""
        self.timerCount = 0
        self.startingFile = open(self.startingFileName)
        #5秒間繰り返す
        while self.timerCount < 50:
            #startingFileの内容を読み込む
            line = self.startingFile.readline()
            if line != "":
                if line[:len("close")] == "close":
                    #1秒保持する
                    time.sleep(1.0)
                    break
                else:
                    cont = line.split("\n")[0]
                    self.label_runCont.setText(cont)
            time.sleep(0.1)
            self.timerCount += 1
        #mainWindowを閉じる
        self.startingFile.close()
        #MainWidowを閉じる
        self.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    MainWindow = QMainWindow()
    ui = winApp()
    ui.main()
    sys.exit(app.exec_())

