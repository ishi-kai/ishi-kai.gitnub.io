#!/usr/bin/python3
#  coding: utf-8
#
"""
Table_GUI.py
Copyright (C) 2020  Tsunehiro Watanabe, Shigeki Fujii all rights reserved.

This software is released under the MIT License.
http://opensource.org/licenses/mit-license.php
"""

import logging
logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)

import sys
import os
import csv
import math

import copy

from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
import numpy as np
import re

import shutil
import glob
import multiprocessing
import threading
import time

#from PyQt4 import QtCore, QtGui
#from PySide import QtCore, QtGui
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
#from PySide.QtGui import *

import Util_Table

import CommonUtil


fontName = "Monospace"
#ML_depth = 2
num_var = 1

#default tree type
nProcs = max(multiprocessing.cpu_count() // 2, 1)   #並列数
nCpu_perCase = 1
TreeType ="Binary_plusC"
nOutParallel, nInParallel = "", ""                  #OFの並列数

#-------------------
#  textEdit class
#-------------------
class textEdit(QTextEdit):
    try:
        reloadSignal =  pyqtSignal(str)
    except:
        reloadSignal =  Signal(str)


#----------------------
#  Ui_MainWindow class
#----------------------
class Ui_MainWindow(object):
    """ gridTableのGUIを作成する"""

    def __init__(self):
        self.showSelectDir = ""
        self.loadDir = ""

    def setupUi(self, MainWindow, Table, showSelectDir, loadDir ):       #tableWidgetを追加
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(509, 270)

        #MainwindowをcentralWidgetにセット
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        #全体のlayout
        self.verticalLayout_top = QVBoxLayout(self.centralwidget)
        self.verticalLayout_top.setObjectName("verticalLayout_top")

        #frameを定義(splitter上側)
        self.frameUp = QFrame()
        self.frameUp.setFrameShape(QFrame.StyledPanel)
        self.frameUp.setFrameShadow(QFrame.Raised)

        #このlayout内に各partsを配置し、verticalLayout_topにセット
        self.verticalLayout = QVBoxLayout(self.frameUp)
        self.verticalLayout.setObjectName("verticalLayout")

        #hLayoutに(buttons)をセット
        self.hLayout_buttons = QHBoxLayout()
        self.hLayout_buttons.setObjectName("hLayout_buttons")
        self.verticalLayout.addLayout(self.hLayout_buttons)
        
        #tableをセット
        self.tableWidget = Table                #置き換え
        self.tableWidget.setRowCount(3)
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setObjectName("tableWidget")
        self.verticalLayout.addWidget(self.tableWidget)
        self.showSelectDir = showSelectDir
        self.loadDir = loadDir

        self.hLayout_6 = QHBoxLayout()
        self.typeComboBox2 = QComboBox()#self.frame2を削除
        self.typeComboBox2.addItem("logcode")
        self.typeComboBox2.addItem("logcode_xor")
        self.typeComboBox2.addItem("logcode_xor_andnand")
        self.typeComboBox2.addItem("4C2")
        self.typeComboBox2.addItem("6C3")
        self.typeComboBox2.addItem("8C4")
        self.typeComboBox2.addItem("10C5")
        self.typeComboBox2.addItem("12C6")
        self.typeComboBox2.addItem("5C2")
        self.typeComboBox2.addItem("5C3")
        self.typeComboBox2.addItem("7C3")
        self.typeComboBox2.addItem("7C4")


        self.hLayout_6.addWidget(self.typeComboBox2)
        
        self.checkBox0 =  QCheckBox()
        self.checkBox0.setText(u"modulation")
        self.hLayout_6.addWidget(self.checkBox0)

        self.label_b_constant =  QLabel()
        self.label_b_constant.setObjectName("b_constant")
        self.label_b_constant.setText("b_constant")
        self.hLayout_6.addWidget(self.label_b_constant)

        self.typeComboBox3 =  QComboBox()
        self.typeComboBox3.addItem("131")
        self.typeComboBox3.addItem("135")
        self.typeComboBox3.addItem("139")
        self.typeComboBox3.addItem("143")
        self.typeComboBox3.addItem("147")
        self.typeComboBox3.addItem("151")
        self.typeComboBox3.addItem("155")
        self.typeComboBox3.addItem("159")

        self.hLayout_6.addWidget(self.typeComboBox3)
        
        spacerItem6 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.hLayout_6.addItem(spacerItem6)


        #checkBox
        self.checkBox2 = QCheckBox()
        self.checkBox2.setText(u"addtry")
        self.hLayout_6.addWidget(self.checkBox2)
        self.checkBox2.setChecked(True)


        #label nOutPara
        self.label_nOutPara = QLabel()#self.frame2を削除
        self.label_nOutPara.setObjectName("nCase")
        self.label_nOutPara.setText("nCase")
        self.hLayout_6.addWidget(self.label_nOutPara)
        #lineEdit nOutPara
        self.nOutParallel = QLineEdit()#self.frame2を削除
        self.nOutParallel.setFixedWidth(90)
        
        self.nOutParallel.setObjectName("nCase")
        self.nOutParallel.setText(str(nProcs))
        self.hLayout_6.addWidget(self.nOutParallel)
        #label nInPara
        self.label_nInPara = QLabel()#self.frame2を削除
        self.label_nInPara.setObjectName("nCpu_perCase")
        self.label_nInPara.setText("nCpu_perCase")

        #lineEdit nInPara
        nInParallel = QLineEdit()#self.frame2を削除
        nInParallel.setObjectName("nCpu_perCase")
        nInParallel.setText(str(nCpu_perCase))
 
        #checkBox
        self.checkBox1 = QCheckBox()
        self.checkBox1.setText(u"only csv")
        self.hLayout_6.addWidget(self.checkBox1)

        self.vLayout_6 = QVBoxLayout()
        self.vLayout_6.addLayout(self.hLayout_6)

        #button export2
        self.horizontalLayout_6 = QHBoxLayout()
        self.eachparam_execButton = QPushButton()#self.frame2を削除
        self.eachparam_execButton.setObjectName("eachparam_execButton")
        self.eachparam_execButton.setText("eachparam_exec")
        self.horizontalLayout_6.addWidget(self.eachparam_execButton)

        self.Pattern_execButton = QPushButton()#self.frame2を削除
        self.Pattern_execButton.setObjectName("Pattern_execButton")
        self.Pattern_execButton.setText("Pattern_exec")
        self.horizontalLayout_6.addWidget(self.Pattern_execButton)

        #label num_var
        self.label_numVar = QLabel()#self.frame2を削除
        self.label_numVar.setObjectName("label_numVar")
        self.label_numVar.setText("num_var:")

        #linEdit num_var
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.lineEdit_numVar = QLineEdit()#self.frame2を削除
        self.lineEdit_numVar.setObjectName("numVar")
        self.lineEdit_numVar.setText("1")
        self.lineEdit_numVar.setSizePolicy(sizePolicy)

        #button load2
        self.eachobj_execButton = QPushButton()#self.frame2を削除
        self.eachobj_execButton.setObjectName("eachobj_execButton")
        self.eachobj_execButton.setText("eachobj_exec")
        self.horizontalLayout_6.addWidget(self.eachobj_execButton)

        #button load2
        self.Patternobj_execButton = QPushButton()#self.frame2を削除
        self.Patternobj_execButton.setObjectName("Patternobj_execButton")
        self.Patternobj_execButton.setText("Patternobj_exec")
        self.horizontalLayout_6.addWidget(self.Patternobj_execButton)
                
        #button Edit2
        self.allobj_execButton = QPushButton()#self.frame2を削除
        self.allobj_execButton.setObjectName("allobj_execButton")
        self.allobj_execButton.setText("allobj_exec")
        self.horizontalLayout_6.addWidget(self.allobj_execButton)
        #button makeMesh2        
        self.eachbind_execButton = QPushButton()#self.frame2を削除
        self.eachbind_execButton.setObjectName("eachbind_execButton")
        self.eachbind_execButton.setText("eachbind_exec")
        self.horizontalLayout_6.addWidget(self.eachbind_execButton)
        #button Patternbind_exec        
        self.Patternbind_execButton = QPushButton()#self.frame2を削除
        self.Patternbind_execButton.setObjectName("Patternbind_execButton")
        self.Patternbind_execButton.setText("Patternbind_exec")
        self.horizontalLayout_6.addWidget(self.Patternbind_execButton)

        #button viewMesh
        self.allbind_execButton = QPushButton()#self.frame2を削除
        self.allbind_execButton.setObjectName("allbind_execButton")
        self.allbind_execButton.setText("allbind_exec")
        self.horizontalLayout_6.addWidget(self.allbind_execButton)

        #button viewMesh
        self.select_execButton = QPushButton()#self.frame2を削除
        self.select_execButton.setObjectName("select_execButton")
        self.select_execButton.setText("select_exec")
        self.horizontalLayout_6.addWidget(self.select_execButton)

        #  checkBox ML_fix
        self.check_MLfix = QCheckBox()
        self.check_MLfix.setText(u"ML_fix")
        self.horizontalLayout_6.addWidget(self.check_MLfix)
        self.check_MLfix.setChecked(False)
        
        #  checkBox ML_fix
        self.check_localize = QCheckBox()
        self.check_localize.setText(u"localize")
        self.horizontalLayout_6.addWidget(self.check_localize)
        self.check_localize.setChecked(False)

        spacerItem_button = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout_6.addItem(spacerItem_button)

        #button exit2
        self.exit2Button = QPushButton()#self.frame2を削除
        self.exit2Button.setObjectName("exit2Button")
        self.exit2Button.setText("Exit")
        self.horizontalLayout_6.addWidget(self.exit2Button)
        self.vLayout_6.addLayout(self.horizontalLayout_6)

        #spacer
        spacerItem2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout_6.addItem(spacerItem2)

        #group action2
        self.horizontalGroupBox6 = QGroupBox('PatternCode / option@exec /       exec_button / Exit')
        #self.horizontalGroupBox6.setLayout(self.horizontalLayout_6)
        self.horizontalGroupBox6.setLayout(self.vLayout_6)

        #radioButton
        self.horizontalLayout_7 = QHBoxLayout()
        self.radioButton_p = QRadioButton()#self.frame2を削除
        self.radioButton_p.setObjectName("radioButton_p")
        self.radioButton_p.setText("Pascal")

        self.radioButton_f = QRadioButton()#self.frame2を削除
        self.radioButton_f.setObjectName("radioButton_f")
        self.radioButton_f.setText("fcPascal")

        self.radioButton_fc = QRadioButton()#self.frame2を削除
        self.radioButton_fc.setObjectName("radioButton_fc")
        self.radioButton_fc.setText("fcPascal_plusC")

        self.radioButton_b = QRadioButton()#self.frame2を削除
        self.radioButton_b.setObjectName("radioButton_b")
        self.radioButton_b.setText("Binary")

        self.radioButton_bc = QRadioButton()#self.frame2を削除
        self.radioButton_bc.setObjectName("radioButton_bc")
        self.radioButton_bc.setText("Binary_plusC")
        self.radioButton_bc.setChecked(1)

        self.radioButton = QButtonGroup()#self.frame2を削除

        self.radioButton.addButton(self.radioButton_p,1)
        self.radioButton.addButton(self.radioButton_f,2)
        self.radioButton.addButton(self.radioButton_fc,3)
        self.radioButton.addButton(self.radioButton_b,4)
        self.radioButton.addButton(self.radioButton_bc,5)
        self.horizontalLayout_7.addWidget(self.radioButton_p)
        self.horizontalLayout_7.addWidget(self.radioButton_f)
        self.horizontalLayout_7.addWidget(self.radioButton_fc)
        self.horizontalLayout_7.addWidget(self.radioButton_b)
        self.horizontalLayout_7.addWidget(self.radioButton_bc)

        #spacer
        spacerItem2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout_7.addItem(spacerItem2)

        #  showSelectDirを挿入
        self.label_showSelectDir = QLabel()
        self.label_showSelectDir.setObjectName("label_showSelectDir")
        self.label_showSelectDir.setText("runDir: " + self.showSelectDir)
        self.horizontalLayout_7.addWidget(self.label_showSelectDir)

        #group TreeType
        self.horizontalGroupBox7 = QGroupBox('TreeType')
        self.horizontalGroupBox7.setLayout(self.horizontalLayout_7)

        self.verticalLayout.addWidget(self.horizontalGroupBox7)
        self.verticalLayout.addWidget(self.horizontalGroupBox6)

        #frameを定義（splitterの下側）
        self.frameDown = QFrame()
        self.frameDown.setFrameShape(QFrame.StyledPanel)
        self.frameDown.setFrameShadow(QFrame.Raised)
        #verticalLayout_logを定義
        self.verticalLayout_log = QVBoxLayout(self.frameDown)
        self.verticalLayout_log.setObjectName("verticalLayout_log")
        #labelを定義、セット
        self.label_log = QLabel()
        self.label_log.setObjectName("label_log")
        self.label_log.setText("tableGUI_log")
        self.verticalLayout_log.addWidget(self.label_log)
        #textEditを定義、セット
        self.textEdit_log = textEdit()
        self.textEdit_log.setObjectName("textEdit_log")
        self.verticalLayout_log.addWidget(self.textEdit_log)

        #spltterの定義、設定
        self.splitter = QSplitter(Qt.Vertical)
        self.splitter.addWidget(self.frameUp)
        self.splitter.addWidget(self.frameDown)
        #splitterを埋め込む
        self.verticalLayout_top.addWidget(self.splitter)
        #spliterの位置を設定（8:2に設定）
        spSize = self.splitter.size().height()
        self.splitter.setSizes([spSize * 0.9, spSize * 0.1])

        MainWindow.setCentralWidget(self.centralwidget)

        #label, lineEditをhLayout_buttonsに追加
        #  reloadButton
        self.button_open = QPushButton()
        self.button_open.setObjectName("button_open")
        self.button_open.setText("")
        self.button_open.setIcon(QPixmap("calculator32ML.png"))
        self.button_open.setIconSize(QSize(24,24))
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.button_open.setSizePolicy(sizePolicy)
        self.hLayout_buttons.addWidget(self.button_open)

        #  label_depth
        self.label_depth = QLabel()
        self.label_depth.setText("ML(Decision-Tree)depth:")
        self.label_depth.setSizePolicy(sizePolicy)
        self.hLayout_buttons.addWidget(self.label_depth)
        #  lineEdit
        self.lineEdit_depth = QLineEdit()#self.frame2を削除
        self.lineEdit_depth.setFixedWidth(90)
        self.lineEdit_depth.setObjectName("")
        self.lineEdit_depth.setText(str(ML_depth))
        self.lineEdit_depth.setSizePolicy(sizePolicy)
        self.hLayout_buttons.addWidget(self.lineEdit_depth)

        #  reloadButton
        self.button_open2 = QPushButton()
        self.button_open2.setObjectName("button_open2")
        self.button_open2.setText("")
        #self.button_open2.setIcon(QPixmap("reload2.png"))
        self.button_open2.setIcon(QPixmap("calculator32Grad.png"))
        self.button_open2.setIconSize(QSize(24,24))
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.button_open2.setSizePolicy(sizePolicy)
        self.hLayout_buttons.addWidget(self.button_open2)

        self.use_underchild_checkBox = QCheckBox()
        self.use_underchild_checkBox.setText(u"use_alldescendents_fromlearnDir")
        self.hLayout_buttons.addWidget(self.use_underchild_checkBox)

        #  stretcherを挿入
        self.label_sp = QLabel()
        self.label_sp.setText("")
        self.hLayout_buttons.addWidget(self.label_sp)

        #  reloadButton
        self.button_open3 = QPushButton()
        self.button_open3.setObjectName("button_open3")
        self.button_open3.setText("")
        #self.button_open3.setIcon(QPixmap("reload3.png"))
        self.button_open3.setIcon(QPixmap("reloadSetLoad.png"))
        self.button_open3.setIconSize(QSize(24,24))
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.button_open3.setSizePolicy(sizePolicy)
        self.hLayout_buttons.addWidget(self.button_open3)

        #  calculatorButton
        self.button_calc = QPushButton()
        self.button_calc.setObjectName("button_calc")
        self.button_calc.setText("")
        #self.button_calc.setIcon(QPixmap("calculator32.png"))
        self.button_calc.setIcon(QPixmap("reloadSetBind.png"))
        self.button_calc.setIconSize(QSize(24,24))
        self.button_calc.setSizePolicy(sizePolicy)
        self.hLayout_buttons.addWidget(self.button_calc)
        #  closeButton
        self.button_close = QPushButton()
        self.button_close.setObjectName("button_calc")
        self.button_close.setText("")
        self.button_close.setIcon(QPixmap("close.png"))
        self.button_close.setIconSize(QSize(24,24))
        self.button_close.setSizePolicy(sizePolicy)
        #  showSelectDirを挿入
        self.label_loadDir = QLabel()
        self.label_loadDir.setObjectName("label_loadDir")
        self.label_loadDir.setText("loadDir: " + self.loadDir)
        self.hLayout_buttons.addWidget(self.label_loadDir)

        #---------------------
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        #mainWindowのcolorを設定（lightGray）
        MainWindow.setAutoFillBackground(True)
        p = MainWindow.palette()
        p.setColor(MainWindow.backgroundRole(), Qt.lightGray)
        MainWindow.setPalette(p)

        QMetaObject.connectSlotsByName(MainWindow)


    def retranslateUi(self, MainWindow):
        #MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow", None))
        MainWindow.setWindowTitle("MainWindow")




#------------------
#  gridTable class
#------------------
class gridTable(Ui_MainWindow):
    """ simpleTableのUi_mainWindowクラスを継承"""

    def __init__(self, rowLabels, colLabels, rowColVals):
        titleDir = learnDir
        if len(titleDir) > 80:
            titleDir = "..." + titleDir[-77:]
        self.showSelectDir = titleDir

        loadDir = init_loadDir
        if len(loadDir) > 80:
            loadDir = "..." + loadDir[-77:]
        self.loadDir = loadDir

        self.MainWindow = QMainWindow()           #redefine
        self.Table = Util_Table.Table()             #use original tablewidget
        self.setupUi(self.MainWindow, self.Table, self.showSelectDir, self.loadDir)       #making GUI
        #font setting
        font = QFont()
        font.setFamily(fontName)
        self.MainWindow.setFont(font)
        #eventを作成
        self.createEvent()
        #attribute
        self.rowLabels = rowLabels
        self.colLabels = colLabels
        self.rowColVals = rowColVals
        self.maskEvent = True                       #for masking event
        #titleを設定
        title = (u"learnDir(target-nodes of calculation belong) is :") + titleDir
        self.MainWindow.setWindowTitle(title)
        #selectDirの設定
        #self.showSelectDir = titleDir
        #widowSizeを取得
        optDir = os.getenv("OptPlatform")
        fileName = optDir + "/gridTable_winSize"
        self.width = 500
        self.height = 300
        if os.path.exists(fileName):
            f = open(fileName); line = f.read(); f.close()
            words = line.split()
            if len(words) >= 2:
                self.width = int(words[0])
                self.height = int(words[1])
        #thread関連の設定
        self.flagThread = "run"     #thread停止flag
        self.runLogThread()         #thread起動
        #starting処理
        #starting()

    #
    #  main
    #---------------
    def main(self):
        self.createMatrix()     #row, colLabelをセット
        self.setMatrixData()    #cellにデータをセット
        self.MainWindow.resize(self.width, self.height)
        self.MainWindow.show()

    #
    #  close
    #----------
    def close(self):
        self.flagThread = "stop"        #thread停止
        self.save_tableattr()
        qApp.quit()
        #ending処理
        #ending()

    def save_tableattr(self):
        """ windowSizeを保存する"""
        optDir = os.getenv("OptPlatform")
        fileName = optDir + "/gridTable_winSize"
        width = self.MainWindow.width()
        height = self.MainWindow.height()
        line = str(width) + " " + str(height)
        f = open(fileName, "w"); f.write(line); f.close()

        #selectDirの読み込み、表示
        fileName = optDir + "/selectDir"
        f = open(fileName)
        self.showSelectDir = f.read().split()[0]
        f.close() 
        if len(self.showSelectDir) > 80:
            self.showSelectDir = "..." + self.showSelectDir[-77:]
        self.label_showSelectDir.setText("runDir: " + self.showSelectDir)


        #######table attribute save#####################
        table = Util_Table.tableWidget(self.tableWidget)
        selCells = table.selectedCells()

        col_num = self.tableWidget.columnCount()
        row_num = self.tableWidget.rowCount()
        logging.debug("#################col_num###################")
        logging.debug("#################score_length###################")
        score_length = ( (col_num - 7) // 2 ) + 1
        param_length = row_num - 1

        #if len(selCells) == 0:
        #    return
        #(row, col) = selCells[0]

        selectDirName = optDir + "/selectDir"
        f = open(selectDirName); selectDir = f.read(); f.close()
        #words = selectDir.split("/")
        projDir, selectDir = self.searchset_projDirselectDir(selectDir)
        
        #score_length=5
        conts2=""
        for i in range(score_length):
            val = table.getCellValue(0, score_length+i+1)
            conts2 += val +","
        f2 = open(learnDir+"/aim_header.csv", "w"); f2.write(conts2); f2.close()

        conts3=""
        for i in range(param_length):
            val = table.getCellValue(i+1, col_num-1)
            conts3 += val +","
        f3 = open(learnDir+"/bind.csv", "w"); f3.write(conts3); f3.close()

        conts4=""
        for i in range(param_length):
            val = table.getCellValue(i+1, col_num-2)
            conts4 += val +","
        f4 = open(learnDir+"/obj.csv", "w"); f4.write(conts4); f4.close()


    #
    #  createEvent
    #---------------
    def createEvent(self):
        """ event作成"""
        #toolBar
        # self.actionOpen.triggered.connect(self.onReloadTable)
        # self.actionSave.triggered.connect(self.onSaveTable)
        # self.actionClose.triggered.connect(self.onCloseTable)
        #buttons
        self.button_open.clicked.connect(self.onReloadTable)
        self.button_open2.clicked.connect(self.onReloadTable2)
        self.button_open3.clicked.connect(self.onReloadTable3)
        self.button_calc.clicked.connect(self.onSaveTable)
        self.button_close.clicked.connect(self.onCloseTable)       
        # #menuBar
        # self.actionMenuOpen.triggered.connect(self.onOpenNewTable)
        # self.actionMenuSave.triggered.connect(self.onSaveTable)
        # self.actionMenuClose.triggered.connect(self.onCloseTable)
        # self.actionMenuUp.triggered.connect(self.onUpTable)
        # self.actionMenuDown.triggered.connect(self.onDownTable)
        #tableWidget
        self.Table.itemClicked.connect(self.onItemClick)

        ###########################################(20200611)追加ボタンと実装のconnect#####################################################################################
        # QtCore.QObject.connect(self.cfMeshFrame.exit2Button, QtCore.SIGNAL("clicked()"), self.actionOnExitButton)
        # QtCore.QObject.connect(self.load2Button, QtCore.SIGNAL("clicked()"), self.actionOnLoad2Button)

        QObject.connect(self.exit2Button, SIGNAL("clicked()"), self.onCloseTable)
        
        QObject.connect(self.eachparam_execButton, SIGNAL("clicked()"), self.actionOneachparam_execButton)
        QObject.connect(self.Pattern_execButton, SIGNAL("clicked()"), self.actionOnPattern_execButton)
        
        QObject.connect(self.eachobj_execButton, SIGNAL("clicked()"), self.actionOneachobj_execButton)        
        QObject.connect(self.Patternobj_execButton, SIGNAL("clicked()"), self.actionOnPatternobj_execButton)        
        QObject.connect(self.allobj_execButton, SIGNAL("clicked()"), self.actionOnallobj_execButton)
        
        QObject.connect(self.eachbind_execButton, SIGNAL("clicked()"), self.actionOneachbind_execButton)        
        QObject.connect(self.Patternbind_execButton, SIGNAL("clicked()"), self.actionOnPatternbind_execButton)
        QObject.connect(self.allbind_execButton, SIGNAL("clicked()"), self.actionOnallbind_execButton)
        QObject.connect(self.select_execButton, SIGNAL("clicked()"), self.actionOnselect_execButton)

        QObject.connect(self.radioButton_p, SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.radioButton_f, SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.radioButton_fc, SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.radioButton_b, SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        QObject.connect(self.radioButton_bc, SIGNAL("clicked()"), self.actionOnTreeRadioButton)
        ###########################################(20200611)追加ボタンと実装のconnect#####################################################################################

        self.textEdit_log.reloadSignal.connect(self.setLogText)

    #------- event handler ------------
    def onReloadTable(self):
        self.setMatrixData2()
    def onReloadTable2(self):
        self.setMatrixData3()
    def onReloadTable3(self):

        selectDirName = os.getenv("OptPlatform") + "/selectDir"
        f = open(selectDirName); selectDir = f.read(); f.close()
        projDir, selectDir = self.searchset_projDirselectDir(selectDir)

        self.loadDir = selectDir
        if len(self.loadDir) > 80:
            self.loadDir = "..." + self.loadDir[-77:]
        self.label_loadDir.setText("loadDir: " + self.loadDir)
        print("loadDir changing")

        score_len=CommonUtil.getscorelen(selectDir)
        if score_len==0:
            print("score_length cannnot get")
            return
        div,param=CommonUtil.divname2num(os.path.basename(selectDir))

        parentDir = "/".join(selectDir.split("/")[:-1])

        parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
        myself_div,myself_list = CommonUtil.divname2num(os.path.basename(selectDir))

        logging.debug("test point")
        logging.debug(parentDir)
        logging.debug(parent_list)


        table = Util_Table.tableWidget(self.tableWidget)


        loadDir = CommonUtil.direction_decode2str(parentDir, selectDir ) 

        if not loadDir:
            print("selectDir is invalid for loadDir")
            return
#            for i in range(len(param)):
#                table.setCellValue( i+1, 2*score_len+2, " ")
        
        else:
            for i in range(len(param)):
                table.setCellValue( i+1, 2*score_len+2, loadDir[i])



#        if (parent_div+1==myself_div):
#            logging.debug("Pascal")
#            direction=[2*(x1 - x2) for (x1,x2) in zip(myself_list,parent_list)]
#            for i in range(len(direction)):
#                if direction[i]==2:
#                    table.setCellValue(i+1, 2*score_len+2 , "Up")
#                else:
#                    table.setCellValue(i+1, 2*score_len+2 , "Down")

#        elif (parent_div*2==myself_div):
#            logging.debug("Binary")
#            direction=[x1 - 2*x2 + 1 for (x1,x2) in zip(myself_list,parent_list)]

#            for i in range(len(direction)):
#                if direction[i]==0:
#                    table.setCellValue(i+1, 2*score_len+2 , "Down")
#                elif direction[i]==1:
#                    table.setCellValue(i+1, 2*score_len+2 , "Center")
#                else:
#                    table.setCellValue(i+1, 2*score_len+2 , "Up")


#        elif ( parent_div%3==0 and myself_div== (parent_div//3)*4 ) or ( parent_div%3!=0 and myself_div==(parent_div//2)*3 ) :

#            logging.debug("fcPascal")
#            # direction=[2*(x1 - x2) for (x1,x2) in zip(myself_list,parent_list)]
#            # float_direction=[ ( float(x1) / myself_div - float(x2) / parent_div ) for (x1,x2) in zip(myself_list,parent_list)]
#            epsilon = 0.00000000000000001

#            for i, (x1, x2) in enumerate(zip(myself_list,parent_list)):
#                if x1 < (myself_div+1)//2 and (parent_div%2==0 and x2!=parent_div//2) and x1 == min( myself_div//2 -2  ,max(1, math.floor(( (x2/parent_div - 1/(2*myself_div)))  * myself_div - epsilon)  ))  + 1:
#                    table.setCellValue(i+1, 2*score_len+2 , "Center")
#                elif x1 > myself_div//2 and (parent_div%2==0 and x2!=parent_div//2) and x1 == max( (myself_div+1)//2 +2 ,min(myself_div-1, math.ceil(( (x2/parent_div + 1/(2*myself_div) )) * myself_div + epsilon) )) -1:
#                    table.setCellValue(i+1, 2*score_len+2 , "Center")
#                elif myself_div%2==0 and  x1 == myself_div//2 and parent_div%2==0 and  x2 == parent_div//2:
#                    table.setCellValue(i+1, 2*score_len+2 , "Center")
#                elif float(x1) / myself_div - float(x2) / parent_div > 0:
#                    table.setCellValue(i+1, 2*score_len+2 , "Up")
#                else:
#                    table.setCellValue(i+1, 2*score_len+2 , "Down")

#        else:
#            print("selectDir can't be traced the direction")
#            return


    def onSaveTable(self):

        ###########3Dirextract#########################################################
        selectDirName = os.getenv("OptPlatform") + "/selectDir"
        f = open(selectDirName); selectDir = f.read(); f.close()
        projDir, selectDir = self.searchset_projDirselectDir(selectDir)
        ###################score長取得(引数にした方が良いかも？###########################################

        score_len=CommonUtil.getscorelen(selectDir)
        if score_len==0:
            print("score_length cannnot get")
            return
        div,param=CommonUtil.divname2num(os.path.basename(selectDir))

        table = Util_Table.tableWidget(self.tableWidget)

        for i in range(self.tableWidget.rowCount()):
            conts = []

            # importance.append(val)
            if i != 0:

                for j in range(score_len-1):
                    val = float(table.getCellValue(0, j+1)) * float(table.getCellValue(i, j+1))
                    conts.append(val)
                max_value = max(conts)
                if max_value> 0.00000001:
                    max_index = conts.index(max_value)
                    table.setCellValue(i, 2*score_len+4 , "sub" + str(max_index+1))
                else:
                    table.setCellValue(i, 2*score_len+4 , "score")

                # table.setCellValue(i, 2*len(float_score)+4 , vals)
            else:
                pass



    def onCloseTable(self):
        self.close()
    def onUpTable(self):
        logging.debug("----up")
    def onDownTable(self):
        logging.debug("----down")
    def onItemClick(self, widgetItem):
        row = widgetItem.row()
        col = widgetItem.column()
        num_sub = (col - 5) // 2 

        text = widgetItem.text()
        flag = 0

        if text == "Up":
            newText = "Down"
        elif text == "Down":
            newText = "Center"
        elif text == "Center":
            newText = "Up"
        elif text == "upper_aim4s":
             newText = "lower_aim4s"
        elif text == "lower_aim4s":
             newText = "upper_aim4s"

        elif text == "lower_aim":
            newText = "upper_aim"
        elif text == "upper_aim":      
            newText = "value_aim"            
        elif text == "value_aim":
            newText = "follow"
        elif text == "follow":                
            newText = "ignore"
        elif text == "ignore":
            newText = "lower_aim"

        elif text == "Up(ML)":
            newText = "Down(ML)"
        elif text == "Down(ML)":
            newText = "Center(ML)"
        elif text == "Center(ML)":
            newText = "Up(ML)"
        elif text == "-":
            newText = "obj"
        elif text == "obj":
            newText = "-"
        elif text == "obj":
            newText = "-"
        elif text =="fix":
            if(num_sub==0):
                newText = "score"
            else:
                newText = "score"
        elif text =="score":
            if(num_sub==0):
                newText = "fix"
            else:
                newText = "sub1"



        elif text[:len("sub")] == "sub":
            try:
                temp = int(text[len("sub"):])
                if (temp < num_sub):
                    newText = "sub" + str(temp+1)
                else:
                    newText = "fix"
            except:
                newText = "sub1"

        else:
            flag = 1
        if flag == 0:
            table = Util_Table.tableWidget(self.tableWidget)
            table.setCellValue(row, col, newText)


        ###########################################(20200611)transfer_GUIinformation2adapter#####################################################################################

    def gettupleGUIinfo_writeTableinfo(self):


        selectDirName = os.getenv("OptPlatform") + "/selectDir"
        f = open(selectDirName); selectDir = f.read(); f.close()
        projDir, selectDir = self.searchset_projDirselectDir(selectDir)

        score_len=CommonUtil.getscorelen(selectDir)
        if score_len==0:
            print("score_length cannnot get")
            return
        div,param=CommonUtil.divname2num(os.path.basename(selectDir))

        table = Util_Table.tableWidget(self.tableWidget)
        selCells = table.selectedCells()


        if len(selCells) == 0:
            col = 2*score_len+2
            row = 0
            print("seed direction is set as loadDir")            
        else:
            (row, col) = selCells[0]

        if col<=score_len or col>=2*score_len+3:
            print("select row is not direction, so seed direction is set as loadDir")
            col = 2*score_len+2            

        conts = []
        importance = ""
        obj_flag = ""
        bind_flag = ""

        folderDirs = glob.glob(selectDir + "/*")
        scoreFiles = []



        for i in range(self.tableWidget.rowCount()):
            val = table.getCellValue(i, col)
            conts.append(val)
            val = table.getCellValue(i, score_len)
            val2 = table.getCellValue(i, 2*score_len+3)
            val3 = table.getCellValue(i, 2*score_len+4)
            # importance.append(val)
            if i != 0:
                importance += str(val)+","
                obj_flag += str(val2) +","
                bind_flag += str(val3) +","
            else:
                pass

        jobList = ""
        ML_flag = ""

        for cont in conts[1:]:
            if cont[:len("Center")] == "Center":
                jobList += "Center,"
            elif cont[:len("Up")] == "Up":
                jobList += "Up,"
            elif cont[:len("Down")] == "Down":
                jobList += "Down,"
            else:
                jobList += "Inappropriate,"
            if cont[-len("(ML)"):] == "(ML)":
                ML_flag += "ML,"
            else:
                ML_flag += ","

        line = jobList[:-1]
        ML_flag = ML_flag[:-1]
        importance = importance[:-1]
        obj_flag = obj_flag[:-1]
        bind_flag = bind_flag[:-1]

        #20220818 cooment out
        #print("----", [line], [jobList])

        print("projDir: " + projDir)

        # platformDir = os.getcwd()

        ###########3Dirextract#########################################################

        f2 = open(projDir + "/seed_direction_info.csv","w")

        f2.write(line)
        f2.write("\n")
        f2.write(ML_flag)
        f2.write("\n")
        f2.write(importance)
        f2.write("\n")
        f2.write(obj_flag)
        f2.write("\n")
        f2.write(bind_flag)

        f2.close()

        #1031
        self.save_tableattr()

        onlyCsv = str(int(self.checkBox1.checkState()))

        PatternCode = self.typeComboBox2.currentText()
        logging.debug(PatternCode)

        global nProcs
        nProcs = int(self.nOutParallel.text())
        # num_var = int(self.lineEdit_numVar.text())
        num_var = len(param)
        ML_fix = str(int(self.check_MLfix.checkState()))
        localize = str(int(self.check_localize.checkState()))
        lcg_flag = str(int(self.checkBox0.checkState()))
        lcg_constant = self.typeComboBox3.currentText()
        addtry_flag = str(int(self.checkBox2.checkState()))

        return selectDir, projDir, onlyCsv, PatternCode, nProcs, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag

    def actionOnExitButton(self):
        logging.debug("no func0")



    def actionOnPatternbind_execButton(self):

        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag  = self.gettupleGUIinfo_writeTableinfo()

        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir 
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant + " " + addtry_flag + " Patternbind_exec" + " &")
        os.system(comm)


    def actionOnallbind_execButton(self):
        
        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()        

        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir 
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant + " " + addtry_flag + " allbind_exec" + " &")
        os.system(comm)


    def actionOneachbind_execButton(self):
        
        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()
        
        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant  + " " + addtry_flag + " eachbind_exec" + " &")
        os.system(comm)




    def actionOneachparam_execButton(self):
        
        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()
        
        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant  + " " + addtry_flag + " eachparam_exec" + " &")
        os.system(comm)


    def actionOnPattern_execButton(self):

        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()

        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant  + " " + addtry_flag + " Pattern_exec" + " &")
        os.system(comm)


    def actionOnPatternobj_execButton(self):

        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()

        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant  + " " + addtry_flag + " Patternobj_exec" + " &")
        os.system(comm)


    def actionOnallobj_execButton(self):
    
        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()

        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant  + " " + addtry_flag + " allobj_exec" + " &")
        os.system(comm)

    def actionOneachobj_execButton(self):

        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()

        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant  + " " + addtry_flag + " eachobj_exec" + " &")

        os.system(comm)

    def actionOnselect_execButton(self):

        selectDir, projDir, onlyCsv, PatternCode, nProces, num_var, ML_fix, localize, lcg_flag, lcg_constant, addtry_flag = self.gettupleGUIinfo_writeTableinfo()

        comm = ("python3 Executor_Table.py" + " " + str(nProcs) + " " + str(nCpu_perCase)
                    + " '" + selectDir + "' '" + projDir + "' '" + platformDir + "' '" + learnDir
                    + "' " + onlyCsv +  " " + TreeType +  " " + PatternCode
                    + " " + str(num_var) + " " + ML_fix + " " + localize + " " + lcg_flag +" " + lcg_constant  + " " + addtry_flag + " select_exec" + " &")

        os.system(comm)

    def searchset_projDirselectDir(self,selectDir):
        words = selectDir.split("/")
        for i in range(len(words)):
            name = words[len(words)-i-1]
            if name[:len("layer")] == "layer":
                projDir = "/".join(words[:len(words)-i-1])
                try:
                    f=open(selectDir + "/path2instance.csv")
                    selectDir = projDir + "/" + f.read()
                    f.close()
                    return projDir,selectDir
                except:
                    print("path2inscance.csv not found")
                    return None, None

            if name[:len("div2_")] == "div2_":
                projDir = "/".join(words[:len(words)-i-1])
                return projDir,selectDir
        return None, None

    def inherit_file(self,filename, startDir):
        words = startDir.split("/")
        for i in range(len(words)):
            #name = words[len(words)-i-1]
            # ancestorDir = "/".join(words[:len(words)-i-1])
            ancestorDir = "/".join(words[:len(words)-i])

            folderDirs = glob.glob(ancestorDir + "/*")

            for item in folderDirs:
                if item == ancestorDir +"/" + filename:
                    shutil.copy(ancestorDir + "/" + filename, startDir )
                    logging.debug("found inherit-file")
                    return
        logging.debug("not found inherit-file")
        return







    def actionOnTreeRadioButton(self):

        global TreeType

        if self.radioButton_p.isChecked() == True :
            TreeType = "Pascal"
        else:
            pass

        if self.radioButton_f.isChecked() == True :
            TreeType = "fcPascal"
        else:
            pass

        if self.radioButton_fc.isChecked() == True :
            TreeType = "fcPascal_plusC"
        else:
            pass

        if self.radioButton_b.isChecked() == True :
            TreeType = "Binary"
        else :
            pass

        if self.radioButton_bc.isChecked() == True :
            TreeType = "Binary_plusC"
        else :
            pass
        print(TreeType)

        #(20200611)ボタン機能実装
    #
    #  createMatrix
    #------------------
    def createMatrix(self):
        """ 行、列名を設定"""
        self.maskEvent = True
        table = Util_Table.tableWidget(self.tableWidget)
        table.createTable(self.rowLabels, self.colLabels)
        for col in range(table.tableWidget.columnCount()):
            table.setCellColor_yellow(0, col)
        self.maskEvent = False

    #
    #  setMatrixData
    #-----------------
    def setMatrixData(self):
        """ cellにデータを設定"""
        self.maskEvent = True
        table = Util_Table.tableWidget(self.tableWidget)
        for row in range(len(self.rowLabels)):
            for col in range(len(self.colLabels)):
                value = str(self.rowColVals[row][col])
                table.setCellValue(row, col, value)
        table.adjustCells()
        self.maskEvent = False


    def setMatrixData2(self):
        """ ML button"""
        global ML_depth
        ML_depth = int(self.lineEdit_depth.text())

        use_underchild = str(int(self.use_underchild_checkBox.checkState()))

        Dirname_startpoint=os.path.basename(learnDir)

        div,param=CommonUtil.divname2num(Dirname_startpoint)
        if div == None:
            mess = u"The name of selected node is invaiid"
            mess += u"Please reselect"
            self.errDialog(u"error", mess)
            return
        coef=1./div;
        list_startpoint=[coef*float(s)  for s in param ]
        direction_startpoint=np.array(list_startpoint)

        lists = []        
        scoreFiles = []            

        if use_underchild != "0":
            for tempDir, _dirs, _files in os.walk(learnDir):
                if tempDir.split("/")[-1][:len("div")] == "div":
                    scoreFile = tempDir + "/score.csv"
                    if os.path.exists(scoreFile):
                        scoreFiles.append(scoreFile)
                        # f = open(tempDir + "/score.csv"); cont = f.read(); f.close()

        else:
            folderDirs = glob.glob(learnDir + "/*")
            for folderDir in folderDirs:
                scoreFile = folderDir + "/score.csv"
                if os.path.exists(scoreFile):
                    scoreFiles.append(scoreFile)

        div=2
        param=[]
        scores = []
        float_score = []
        for scoreFile in scoreFiles:
            f = open(scoreFile); cont = f.read(); f.close()
            score = cont.split()[0]
            name = scoreFile.split("/")[-2]
            scores.append([name, score])

            float_score = [float(s) for s in score.split(",")]
            div,param=CommonUtil.divname2num(name)
            if div != None:
                coef=1./div;
                param=[coef*float(s)  for s in param ]
                data_unit = param + float_score
                lists.append(data_unit)

        scores.sort()
        fileName = learnDir + "/totalScore.csv"
        f = open(fileName, "w")

        ###################20201113 edit #########################################

        for unit in lists:
            line = ""

            for elem in unit:
                line = line + str(elem) +","
            line = line + "\n"
            f.write(line)

        ###################20201113 edit #########################################

        f.close()

        logging.debug(lists)


        table = Util_Table.tableWidget(self.tableWidget)
        object_types=[]

        MAT = np.array(lists)

        train_z = MAT[:,len(param)]
        train_y = MAT[:, len(param)+1:]
        train_x = MAT[:,:len(param)]
        Final_npdata= np.empty((len(param)+1,len(float_score)+1))
        npnan_element = [np.nan]

        learner =DecisionTreeRegressor(max_depth=len(float_score),random_state=0)

        for i in range(len(float_score)+1):
            object_type =table.getCellValue(0,len(float_score)+i+1)
            object_types.append(object_type)

            logging.debug(object_type)

            if object_type=="ignore":
                #########20201115edit###############
                train_y[:,i-1]=np.zeros_like(train_y[:,i-1])
                #train_y[:,i-1]=np.zeros(train_y[:,i-1].shape)
                #train_y[:,i-1]=np.full(train_y[:,i-1].shape,0.01)


        if(len(float_score)==1):
            Final_npdata[0,0]=np.nan
        else:
            learner.fit(train_y,train_z)
            Final_npdata[0,:]=np.concatenate([npnan_element,learner.feature_importances_,npnan_element])
            #########################(1)新規追加　最終目的値⇔パラメータ###############

            #learner =DecisionTreeRegressor(max_depth=len(param)-3,random_state=0)
        extract_LR = LinearRegression()
        learner =DecisionTreeRegressor(max_depth=ML_depth,random_state=0)
        learner.fit(train_x,train_z)
        Final_npdata[1:,0]=learner.feature_importances_
        #########################(1)新規追加　最終目的値⇔パラメータ終了###########
        
        value_header = CommonUtil.get_value_header(learnDir)
        
        total_recommend = []

        if object_types[0]=="upper_aim4s":
            searchnode_index = np.argmax(train_z)
            logging.debug("upper_aim4s")
        else:
            searchnode_index = np.argmin(train_z)
            logging.debug("lower_aim4s")

        logging.debug(searchnode_index)
        dp  = learner.decision_path(train_x)
        logging.debug(dp[searchnode_index])

        dense_dp = np.array(dp.todense())[searchnode_index]
        logging.debug(dense_dp)

        recommend_byML = []
        upper_flag=[]
        lower_flag=[]

        for i in range(len(param)):
            recommend_byML.append("Center")
            upper_flag.append(0)
            lower_flag.append(0)


        for i in range(0, len(dense_dp)-1):
            if dense_dp[i] == 1 and learner.tree_.children_left[i]!=learner.tree_.children_right[i]:
                logging.debug(i)
                logging.debug(learner.tree_.feature[i])
                logging.debug(learner.tree_.feature[i+1])
                if dense_dp[i+1] == 0:
                    upper_flag = upper_flag[:learner.tree_.feature[i]] + [1] + upper_flag[learner.tree_.feature[i]+1:]
                else:                    
                    lower_flag = lower_flag[:learner.tree_.feature[i]] + [1] + lower_flag[learner.tree_.feature[i]+1:]

        for i in range(len(param)):
            if upper_flag[i] == 1:
                if lower_flag[i]==1:
                    recommend_byML = recommend_byML[:i]+["Center(ML)"]+recommend_byML[i+1:]
                    logging.debug("--center(ML)--")
                else:
                    recommend_byML = recommend_byML[:i]+["Up(ML)"]+recommend_byML[i+1:]
                    logging.debug("--up(ML)--")
            else:
                if lower_flag[i]==1:
                    recommend_byML = recommend_byML[:i]+["Down(ML)"]+recommend_byML[i+1:]
                    logging.debug("--down(ML)--")
                else:
                    #######################20201114 want to change xyz, but something wrong##########################################
                    extract_LR.fit(train_x[:,i].reshape(-1,1), train_z )
                    if (extract_LR.coef_ > 0.) ^ (object_types[0]=="lower_aim4s"):

                        #if (np.dot( train_z, train_x[:,i] - np.full(len(lists),direction_startpoint[i])) > 0.) ^ (object_types[0]=="lower_aim4s"):
                        #if (np.dot( MAT[:,len(param)], MAT[:,i] - np.full(len(lists),direction_startpoint[i])) > 0.) ^ (object_types[0]=="lower_aim4s"):
                        #20201114 want to change xyz, but something wrong
                        recommend_byML = recommend_byML[:i]+["Up"]+recommend_byML[i+1:]
                        logging.debug("-------------------+---------------------UP")
                    else:
                        recommend_byML = recommend_byML[:i]+["Down"]+recommend_byML[i+1:]
                        logging.debug("+-------------------+---------------------DOWN")
                    #print(np.dot( train_z, train_x[:,i] - np.full(len(lists),direction_startpoint[i])))


        logging.debug(learner.tree_.feature)
        logging.debug(recommend_byML)

        recommend_byML_mainscore=copy.deepcopy(recommend_byML)
        #recommend_byML.insert(0,"")
        recommend_byML.insert(0,object_types[0])

        total_recommend.append(recommend_byML)


        for n in range(len(float_score)-1):

            recommend_byML = []
            upper_flag=[]
            lower_flag=[]

            for i in range(len(param)):
                recommend_byML.append("Center")
                upper_flag.append(0)
                lower_flag.append(0)


            if object_types[n+1]=="follow":
            #############20201113edit need to recheck#####################################
            #train_yn = abs(train_y[:,n]-train_y[searchnode_index,n])
            #learner.fit(train_x,train_yn)

                train_y[:,n] = abs(train_y[:,n]-train_y[searchnode_index,n])
                learner.fit(train_x,train_y[:,n] )


            #############20201113edit need to recheck#####################################
            else:
                learner.fit(train_x,train_y[:,n])

            logging.debug(searchnode_index)
            dp  = learner.decision_path(train_x)
            logging.debug(dp[searchnode_index])

            #learner.fit(train_x,train_y[:,n])

            Final_npdata[1:,n+1]=learner.feature_importances_

            #            maxscore_index = np.argmax(train_y[:,n])
            #            print maxscore_index
            #            dp  = learner.decision_path(train_x)
            #            print dp[maxscore_index]

            if object_types[n+1]=="follow":
                dense_dp = np.array(dp.todense())[searchnode_index]
            elif  object_types[n+1]=="upper_aim":
                dense_dp = np.array(dp.todense())[np.argmax(train_y[:,n])]
            elif object_types[n+1]=="lower_aim":
                dense_dp = np.array(dp.todense())[np.argmin(train_y[:,n])]
            #add value_aim
            elif object_types[n+1]=="value_aim" and type(value_header[n+1]) is float:
                dense_dp = np.array(dp.todense())[np.argmin(abs(train_y[:,n]-value_header[n+1]))]

            ###20201115edite
            #            elif object_types[n+1]=="ignore":
            #                dense_dp = np.array(dp.todense())[np.argmin(train_y[:,n])]
            ###20201115edit
            else:
                dense_dp = np.array(dp.todense())[searchnode_index]

            logging.debug(dense_dp)

            recommend_byML=[]
            for i in range(len(param)):
                recommend_byML.append("Center")


            for i in range(0, len(dense_dp)-1):
                if dense_dp[i] == 1 and learner.tree_.children_left[i]!=learner.tree_.children_right[i]:
                    logging.debug( i)
                    if dense_dp[i+1] == 0:
                        upper_flag = upper_flag[:learner.tree_.feature[i]] + [1] + upper_flag[learner.tree_.feature[i]+1:]
                    else:                    
                        lower_flag = lower_flag[:learner.tree_.feature[i]] + [1] + lower_flag[learner.tree_.feature[i]+1:]

            for i in range(len(param)):
                if upper_flag[i]==1:
                    if lower_flag[i]==1:
                        recommend_byML = recommend_byML[:i]+["Center(ML)"]+recommend_byML[i+1:]
                    else:
                        recommend_byML = recommend_byML[:i]+["Up(ML)"]+recommend_byML[i+1:]
                else:
                    if lower_flag[i]==1:
                        recommend_byML = recommend_byML[:i]+["Down(ML)"]+recommend_byML[i+1:]
                    else:

                        #if (np.dot( train_y[:,n], train_x[:,i] - np.full(len(lists),direction_startpoint[i])) > 0.) ^ (object_types[n+1]=="lower_aim"):
                        #if (np.dot( MAT[:,len(param)+n+1], MAT[:,i] - np.full(len(lists),direction_startpoint[i])) > 0.) ^ (object_types[n+1]=="lower_aim"):

                        extract_LR.fit(train_x[:,i].reshape(-1,1), train_y[:,n])
                        if (object_types[n+1]=="follow"): 
                            recommend_byML = recommend_byML[:i]+[recommend_byML_mainscore[i]]+recommend_byML[i+1:]
                        
                        elif (extract_LR.coef_ > 0.) ^ (object_types[n+1]=="lower_aim"):
                            recommend_byML = recommend_byML[:i]+["Up"]+recommend_byML[i+1:]
                            logging.debug("-------------------+---------------------")
                        else:
                            recommend_byML = recommend_byML[:i]+["Down"]+recommend_byML[i+1:]
                            logging.debug("+-------------------+---------------------+")

            logging.debug(learner.tree_.feature)
            logging.debug(recommend_byML)
            recommend_byML.insert(0,object_types[n+1])            
            total_recommend.append(recommend_byML)


        evaltable_subimportance = np.empty((len(param),len(float_score)-1))
        for i in range(len(float_score)-1):
            evaltable_subimportance[:,i] = Final_npdata[0,i+1] * Final_npdata[1:,i+1] 

        #Final_npData[0,len(float_score)+1]=np.nan
        if(len(float_score)==1):
            Final_npdata[1:,1]=Final_npdata[1:,0]
        else:
            for n in range(len(param)):
                index_mostimportance = np.argmax(evaltable_subimportance[n,:])
                #iparam_rec = total_recommend[index_mostimportance+1][i+1]
                #recommend_byML = recommend_byML[:i]+total_recommend[i,index_mostimportance] + recommend_byML[i+1:]
                logging.debug(Final_npdata[n+1,:])
                logging.debug(evaltable_subimportance[n,index_mostimportance])

                Final_npdata[n+1,len(float_score)] = evaltable_subimportance[n,index_mostimportance]

                #################################
                #calculate and compare the tree_out param
                ################################
                ####################################subscore毎のrecommend集約##################################################
        recommend_byML=[]

        if len(float_score)==1:
            recommend_byML=recommend_byML_mainscore
        else:
            for i in range(len(param)):
                recommend_byML.append("Center")


            evaltable_subimportance = np.empty((len(param),len(float_score)-1))
            for i in range(len(float_score)-1):
                evaltable_subimportance[:,i] = Final_npdata[0,i+1] * Final_npdata[1:,i+1] 

            for i in range(len(param)):
                index_mostimportance = np.argmax(evaltable_subimportance[i,:])
                iparam_rec = total_recommend[index_mostimportance+1][i+1]
            #recommend_byML = recommend_byML[:i]+total_recommend[i,index_mostimportance] + recommend_byML[i+1:]
                recommend_byML = recommend_byML[:i]+ [iparam_rec] + recommend_byML[i+1:]

        recommend_byML.insert(0,object_types[len(float_score)])
        total_recommend.append(recommend_byML)

        ####################################subscore毎のrecommend集約##################################################

        recommend_byML=[]
        for i in range(len(param)):
            recommend_byML.append(table.getCellValue(i+1,2*len(float_score)+2))
        recommend_byML.insert(0,"loadDir_")

        total_recommend.append(recommend_byML)


        ############obj column add#############
        recommend_byML=[]
        for i in range(len(param)):
            #recommend_byML.append("-")
            recommend_byML.append(table.getCellValue(i+1,2*len(float_score)+3))
        recommend_byML.insert(0,"obj_")

        total_recommend.append(recommend_byML)

        ###########20201016 add########################
        recommend_byML=[]
        for i in range(len(param)):
            #recommend_byML.append("sub1")
            recommend_byML.append(table.getCellValue(i+1,2*len(float_score)+4))
        recommend_byML.insert(0,"bind_")
        ###########20201016 add########################

        total_recommend.append(recommend_byML)
        ###################################

        total_recommend = np.array(total_recommend)
        total_recommend = total_recommend.T

        logging.debug(total_recommend)
        #print recommend_byML
        #print Final_npdata
        Final_npdata=np.append(Final_npdata,total_recommend, axis=1)

        colData1 = Final_npdata.tolist()

        logging.debug(colData1)

        #learner.fit(train_z[:,param:-1],train_z[:,-1])
        #colData1 = Final_npdata.tolist()
        #print learner.feature_importances_
        #colData1 = learner_1.feature_importances_.transpose()
        #colData1 = colData1.tolist()
        #colData1 = list(map(lambda x: [x], colData1))
        #colData1 = list(map(lambda x: x + [1,2], colData1))
        #print("----", colData1)
        #"param1", "param2", "param3", "param4", "para5", "para6", "para7"]
        rowLabels = ["score"]
        for i in range(len(param)):
            rowLabels.append("param"+str(i+1))
            
        colLabels = ["score"]
        for i in range(len(float_score)-1):
            colLabels.append("sub"+str(i+1))

        colLabels.append("impmax(sub-param)")

        colLabels.append("rec_byscore")

        for i in range(len(float_score)-1):
            colLabels.append("rec_bysub"+str(i+1))


        colLabels.append("rec_bysubs")
        colLabels.append("loadDir")
        colLabels.append("obj")
        colLabels.append("bind")

        ##############(20201015dummy##########
        #colLabels.append("dummy")

        lines = []
        content4table = []
        line = ",".join([" "] + colLabels) + "\n"
        lines.append(line)
        for i in range(len(rowLabels)):
            # strCol = []
            # for val in colData1[i]:
            #     if type(val) == float:
            #         val1 = "%10.8f" % val
            #     else:
            #         val1 = val
            #     print("---", val1, type(val))
            #     strCol.append(val1)
            #strCol = list(map(lambda x: "%10.8f" % x, colData1[i]))
            strCol = list(map(str, colData1[i]))
            line = ",".join([rowLabels[i]] + strCol) + "\n"

            lines.append(line)
        f3 = open(learnDir + "/importance.csv", "w")
        for line in lines:
            f3.write(line)
        f3.close()

        self.maskEvent = True
        table = Util_Table.tableWidget(self.tableWidget)


        #rowLabels.append("test")
        ####20200801 table reconstruct####################
        table.createTable(rowLabels,colLabels)
        #rowLabels.pop()
        
        for col in range(table.tableWidget.columnCount()):
            table.setCellColor_yellow(0, col)


        ####20200801 table reconstruct####################

        for row in range(len(rowLabels)):
            for col in range(len(colLabels)):
                try:
                    val = float(colData1[row][col])
                    value = "%10.8f" % val
                    if value == "0.00000000":
                        value = "0.0"
                except:
                    value = colData1[row][col]
                #value = str(colData1[row][col])
                table.setCellValue(row, col, value)
        table.adjustCells()
        self.maskEvent = False

        logging.debug(object_types)

    def setMatrixData3(self):

        global ML_depth
        ML_depth = int(self.lineEdit_depth.text())

        use_underchild = str(int(self.use_underchild_checkBox.checkState()))

        Dirname_startpoint=os.path.basename(learnDir)

        div,param=CommonUtil.divname2num(Dirname_startpoint)
        if div == None:
            mess = u"The noame of selected node is invalid"
            mess += u"Please reselect"
            self.errDialog(u"error", mess)
            return
        coef=1./div;
        list_startpoint=[coef*float(s)  for s in param ]
        direction_startpoint=np.array(list_startpoint)

        lists = []        
        scoreFiles = []            

        if use_underchild != "0":
            for tempDir, _dirs, _files in os.walk(learnDir):
                if tempDir.split("/")[-1][:len("div")] == "div":
                    scoreFile = tempDir + "/score.csv"
                    if os.path.exists(scoreFile):
                        scoreFiles.append(scoreFile)
#                        f = open(tempDir + "/score.csv"); cont = f.read(); f.close()

        else:
            folderDirs = glob.glob(learnDir + "/*")
            for folderDir in folderDirs:
                scoreFile = folderDir + "/score.csv"
                if os.path.exists(scoreFile):
                    scoreFiles.append(scoreFile)

        div=2
        param=[]
        scores = []
        float_score = []
        for scoreFile in scoreFiles:
            f = open(scoreFile); cont = f.read(); f.close()
            score = cont.split()[0]
            name = scoreFile.split("/")[-2]
            scores.append([name, score])

            float_score = [float(s) for s in score.split(",")]
            div,param=CommonUtil.divname2num(name)
            if div != None:
                coef=1./div;
                param=[coef*float(s)  for s in param ]
                data_unit = param + float_score
                lists.append(data_unit)

        scores.sort()

        fileName = learnDir + "/totalScore.csv"
        f = open(fileName, "w")

        ###################20201113 edit #########################################

        for unit in lists:
            line = ""

            for elem in unit:
                line = line + str(elem) +","
            line = line + "\n"
            f.write(line)

        ###################20201113 edit #########################################


        f.close()

        logging.debug(lists)

        table = Util_Table.tableWidget(self.tableWidget)
        object_types=[]
        #add value_aim



        MAT = np.array(lists)

        train_z = MAT[:,len(param)]
        train_y = MAT[:, len(param)+1:]
        train_x = MAT[:,:len(param)]
        Final_npdata= np.empty((len(param)+1,len(float_score)+1))
        Final_npdata_importance = np.empty((len(param)+1,len(float_score)+1))
        npnan_element = [np.nan]

        learner =DecisionTreeRegressor(max_depth=len(float_score),random_state=0)
        extract_LR = LinearRegression()

        for i in range(len(float_score)+1):
            object_type =table.getCellValue(0,len(float_score)+i+1)
            object_types.append(object_type)
            if object_type=="ignore":
                train_y[:,i-1]=np.zeros_like(train_y[:,i-1])

        if(len(float_score)==1):
            Final_npdata[0,0]=np.nan
        else:
            extract_LR.fit(train_y,train_z)
            Final_npdata[0,:]=np.concatenate([npnan_element,extract_LR.coef_,npnan_element])
            np.full_like(Final_npdata[0,:],npnan_element)

            #nan_array = np.full(len(float_score)+1,npnan_element)
            #Final_npdata[0,:] = nan_array
            learner.fit(train_y,train_z)

            Final_npdata_importance[0,:]=np.concatenate([npnan_element,learner.feature_importances_,npnan_element])
            #########################(1)新規追加　最終目的値⇔パラメータ###############


            #learner =DecisionTreeRegressor(max_depth=len(param)-3,random_state=0)
        extract_LR = LinearRegression()
        learner =DecisionTreeRegressor(max_depth=ML_depth,random_state=0)
        learner.fit(train_x,train_z)
        Final_npdata_importance[1:,0]=learner.feature_importances_
        #########################(1)新規追加　最終目的値⇔パラメータ終了###########

        value_header = CommonUtil.get_value_header(learnDir)


        for i in range(len(param)):
            #Final_npdata[i+1,0]=np.dot( MAT[:,len(param)], MAT[:,i] - np.full(len(lists),direction_startpoint[i]))/max(0.000000001,np.sum(np.abs(MAT[:,len(param)])))
            #Final_npdata[i+1,0]=np.dot( train_z, train_x[:,i] - np.full(len(lists),direction_startpoint[i]))/ max(0.000000001,np.sum(np.abs(train_z)))
            extract_LR.fit(train_x[:,i].reshape(-1,1), train_z)
            Final_npdata[i+1,0]=extract_LR.coef_

        total_recommend = []

        if object_types[0]=="upper_aim4s":
            searchnode_index = np.argmax(train_z)
            logging.debug("upper_aim4s")
        else:
            searchnode_index = np.argmin(train_z)
            logging.debug("lower_aim4s")

        logging.debug(searchnode_index)
        dp  = learner.decision_path(train_x)
        logging.debug(dp[searchnode_index])

        dense_dp = np.array(dp.todense())[searchnode_index]
        logging.debug(dense_dp)

        recommend_byML = []
        upper_flag=[]
        lower_flag=[]

        for i in range(len(param)):
            recommend_byML.append("Center")
            upper_flag.append(0)
            lower_flag.append(0)


        for i in range(0, len(dense_dp)-1):
            if dense_dp[i] == 1 and learner.tree_.children_left[i]!=learner.tree_.children_right[i]:
                logging.debug(i)
                logging.debug(learner.tree_.feature[i])
                logging.debug(learner.tree_.feature[i+1])
                if dense_dp[i+1] == 0:
                    upper_flag = upper_flag[:learner.tree_.feature[i]] + [1] + upper_flag[learner.tree_.feature[i]+1:]
                else:                    
                    lower_flag = lower_flag[:learner.tree_.feature[i]] + [1] + lower_flag[learner.tree_.feature[i]+1:]

        for i in range(len(param)):
            #if (np.dot( train_z, train_x[:,i] - np.full(len(lists),direction_startpoint[i]))/ max(0.000000001,np.sum(np.abs(train_z))) > 0.) ^ (object_types[0]=="lower_aim4s"):
            #if (np.dot( MAT[:,len(param)], MAT[:,i] - np.full(len(lists),direction_startpoint[i])) > 0.) ^ (object_types[0]=="lower_aim4s"):
            #if (np.dot( train_z, train_x[:,i] - np.full(len(lists),direction_startpoint[i]))/ max(0.000000001,np.sum(np.abs(train_z))) > 0.) ^ (object_types[0]=="lower_aim4s"):
            extract_LR.fit(train_x[:,i].reshape(-1,1),train_z)
            if (extract_LR.coef_ > 0.) ^ (object_types[0]=="lower_aim4s"):
                recommend_byML = recommend_byML[:i]+["Up"]+recommend_byML[i+1:]
            else:
                recommend_byML = recommend_byML[:i]+["Down"]+recommend_byML[i+1:]

            #if upper_flag[i] == 1:
            #if lower_flag[i]==1:
            #                    recommend_byML = recommend_byML[:i]+["Center(ML)"]+recommend_byML[i+1:]
            #                    print("--center(ML)--")
            #                else:
            #                    recommend_byML = recommend_byML[:i]+["Up(ML)"]+recommend_byML[i+1:]
            #                    print("--up(ML)--")
            #            else:
            #                if lower_flag[i]==1:
            #                    recommend_byML = recommend_byML[:i]+["Down(ML)"]+recommend_byML[i+1:]
            #                    print("--down(ML)--")
            #                else:
            #                    if (np.dot( MAT[:,len(param)], MAT[:,i] - np.full(len(lists),direction_startpoint[i])) > 0.) ^ (object_types[0]=="lower_aim4s"):
            #                        recommend_byML = recommend_byML[:i]+["Up"]+recommend_byML[i+1:]
            #                        print("-------------------+---------------------UP")
            #                    else:
            #                        recommend_byML = recommend_byML[:i]+["Down"]+recommend_byML[i+1:]
            #                        print("+-------------------+---------------------DOWN")


        logging.debug(learner.tree_.feature)
        logging.debug(recommend_byML)
            #        recommend_byML.insert(0,"")

        recommend_byML_mainscore = copy.deepcopy(recommend_byML)

        recommend_byML.insert(0,object_types[0])

        total_recommend.append(recommend_byML)


        for n in range(len(float_score)-1):

            recommend_byML = []
            upper_flag=[]
            lower_flag=[]

            for i in range(len(param)):
                recommend_byML.append("Center")
                upper_flag.append(0)
                lower_flag.append(0)


            #############20201113edit need to recheck#####################################
            #                train_yn = abs(train_y[:,n]-train_y[searchnode_index,n])
            #                learner.fit(train_x,train_yn)


            if object_types[n+1]=="follow":
                train_y[:,n] = abs(train_y[:,n]-train_y[searchnode_index,n])
                learner.fit(train_x,train_y[:,n] )
            else:
                learner.fit(train_x,train_y[:,n])

            Final_npdata_importance[1:,n+1]=learner.feature_importances_

            #############20201113edit need to recheck#####################################



            #Final_npdata[1:,n+1]=learner.feature_importances_

            for i in range(len(param)):
                #                Final_npdata[i+1,n+1]=np.dot( train_y[:,n], train_x[:,i] - np.full(len(lists),direction_startpoint[i]))/max(0.000000001,np.sum(np.abs(train_y[:,n])))
                #                Final_npdata[i+1,n+1]=np.dot( MAT[:,len(param)+n+1], MAT[:,i] - np.full(len(lists),direction_startpoint[i]))/max(0.000000001,np.sum(np.abs(MAT[:,len(param)+n+1])))

                extract_LR.fit(train_x[:,i].reshape(-1,1), train_y[:,n] )
                Final_npdata[i+1,n+1]=extract_LR.coef_

            maxscore_index = np.argmax(train_y[:,n])
            logging.debug(maxscore_index)
            dp  = learner.decision_path(train_x)
            logging.debug(dp[maxscore_index])

            if object_types[n+1]=="follow":
                dense_dp = np.array(dp.todense())[searchnode_index]
            elif  object_types[n+1]=="upper_aim":
                dense_dp = np.array(dp.todense())[np.argmax(train_y[:,n])]
            elif object_types[n+1]=="lower_aim":
                dense_dp = np.array(dp.todense())[np.argmin(train_y[:,n])]

            elif object_types[n+1]=="value_aim" and type(value_header[n+1]) is float:
                dense_dp = np.array(dp.todense())[np.argmin(abs(train_y[:,n]-value_header[n+1]))] 
                
            else:
                dense_dp = np.array(dp.todense())[searchnode_index]

            logging.debug(dense_dp)

            recommend_byML=[]
            for i in range(len(param)):
                recommend_byML.append("Center")


            for i in range(0, len(dense_dp)-1):
                if dense_dp[i] == 1 and learner.tree_.children_left[i]!=learner.tree_.children_right[i]:
                    logging.debug(i)
                    if dense_dp[i+1] == 0:
                        upper_flag = upper_flag[:learner.tree_.feature[i]] + [1] + upper_flag[learner.tree_.feature[i]+1:]
                    else:                    
                        lower_flag = lower_flag[:learner.tree_.feature[i]] + [1] + lower_flag[learner.tree_.feature[i]+1:]

            for i in range(len(param)):
                extract_LR.fit(train_x[:,i].reshape(-1,1),train_y[:,n])



                if (object_types[n+1]=="follow"):
                    recommend_byML = recommend_byML[:i]+[recommend_byML_mainscore[i]]+recommend_byML[i+1:]

                elif object_types[n+1]=="value_aim": 
                    recommend_byML = recommend_byML[:i]+["Center"]+recommend_byML[i+1:]                
                        
                elif (extract_LR.coef_ >0.) ^ (object_types[n+1]=="lower_aim"):

                #                if (np.dot( train_y[:,n], train_x[:,i] - np.full(len(lists),direction_startpoint[i]))/max(0.000000001,np.sum(np.abs(train_y[:,n])))>0.) ^ (object_types[n+1]=="lower_aim"):
                    recommend_byML = recommend_byML[:i]+["Up"]+recommend_byML[i+1:]
                else:
                    recommend_byML = recommend_byML[:i]+["Down"]+recommend_byML[i+1:]


            logging.debug(learner.tree_.feature)
            logging.debug(recommend_byML)
            recommend_byML.insert(0,object_types[n+1])            
            total_recommend.append(recommend_byML)


        evaltable_subimportance = np.empty((len(param),len(float_score)-1))
        for i in range(len(float_score)-1):
            evaltable_subimportance[:,i] = Final_npdata_importance[0,i+1] * Final_npdata_importance[1:,i+1] 


        #        Final_npData[0,len(float_score)+1]=np.nan
        if len(float_score)==1:
            Final_npdata[1:,1] = Final_npdata[1:,0]

        else:
            for n in range(len(param)):
                index_mostimportance = np.argmax(evaltable_subimportance[n,:])
                #iparam_rec = total_recommend[index_mostimportance+1][i+1]
                #            recommend_byML = recommend_byML[:i]+total_recommend[i,index_mostimportance] + recommend_byML[i+1:]
                logging.debug(Final_npdata[n+1,:])
                logging.debug(evaltable_subimportance[n,index_mostimportance])

                Final_npdata[n+1,len(float_score)] = evaltable_subimportance[n,index_mostimportance]



                #################################
                #calculate and compare the tree_out param
                ################################

                ####################################subscore毎のrecommend集約##################################################
        recommend_byML=[]
        if len(float_score)==1:
            recommend_byML = recommend_byML_mainscore

        else:
            for i in range(len(param)):
                recommend_byML.append("Center")


            evaltable_subimportance = np.empty((len(param),len(float_score)-1))
            for i in range(len(float_score)-1):
                evaltable_subimportance[:,i] = Final_npdata[0,i+1] * Final_npdata[1:,i+1] 

            for i in range(len(param)):
                index_mostimportance = np.argmax(evaltable_subimportance[i,:])
                iparam_rec = total_recommend[index_mostimportance+1][i+1]
                #            recommend_byML = recommend_byML[:i]+total_recommend[i,index_mostimportance] + recommend_byML[i+1:]
                recommend_byML = recommend_byML[:i]+ [iparam_rec] + recommend_byML[i+1:]

        recommend_byML.insert(0,object_types[len(float_score)])
        total_recommend.append(recommend_byML)

        ####################################subscore毎のrecommend集約##################################################

        recommend_byML=[]
        for i in range(len(param)):
            recommend_byML.append(table.getCellValue(i+1,2*len(float_score)+2))
        recommend_byML.insert(0,"loadDir_")

        total_recommend.append(recommend_byML)


        ############obj column add#############
        recommend_byML=[]
        for i in range(len(param)):
            #            recommend_byML.append("-")
            recommend_byML.append(table.getCellValue(i+1,2*len(float_score)+3))
        recommend_byML.insert(0,"obj_")

        total_recommend.append(recommend_byML)

        ###########20201016 add########################
        recommend_byML=[]
        for i in range(len(param)):
            #            recommend_byML.append("sub1")
            recommend_byML.append(table.getCellValue(i+1,2*len(float_score)+4))
        recommend_byML.insert(0,"bind_")
        ###########20201016 add########################

        total_recommend.append(recommend_byML)
        ###################################

        total_recommend = np.array(total_recommend)
        total_recommend = total_recommend.T

        logging.debug(total_recommend)

        Final_npdata=np.append(Final_npdata,total_recommend, axis=1)

        colData1 = Final_npdata.tolist()

        logging.debug(colData1)

        #        learner.fit(train_z[:,param:-1],train_z[:,-1])
        #colData1 = Final_npdata.tolist()
        #        print learner.feature_importances_
        #        colData1 = learner_1.feature_importances_.transpose()
        #        colData1 = colData1.tolist()
        #        colData1 = list(map(lambda x: [x], colData1))
        #        colData1 = list(map(lambda x: x + [1,2], colData1))
        #        print("----", colData1)
        #         "param1", "param2", "param3", "param4", "para5", "para6", "para7"]
        rowLabels = ["score"]
        for i in range(len(param)):
            rowLabels.append("param"+str(i+1))
        colLabels = ["score"]
        for i in range(len(float_score)-1):
            colLabels.append("sub"+str(i+1))

        colLabels.append("impmax(sub-param)")

        colLabels.append("rec_byscore")

        for i in range(len(float_score)-1):
            colLabels.append("rec_bysub"+str(i+1))


        colLabels.append("rec_bysubs")
        colLabels.append("loadDir")
        colLabels.append("obj")
        colLabels.append("bind")

        #(20201015dummy
        #colLabels.append("dummy")

        lines = []
        content4table = []
        line = ",".join([" "] + colLabels) + "\n"
        lines.append(line)
        for i in range(len(rowLabels)):
            # strCol = []
            # for val in colData1[i]:
            #     if type(val) == float:
            #         val1 = "%10.8f" % val
            #     else:
            #         val1 = val
            #     print("---", val1, type(val))
            #     strCol.append(val1)
            #strCol = list(map(lambda x: "%10.8f" % x, colData1[i]))
            strCol = list(map(str, colData1[i]))
            line = ",".join([rowLabels[i]] + strCol) + "\n"

            lines.append(line)
        f3 = open(learnDir + "/grad.csv", "w")
        for line in lines:
            f3.write(line)
        f3.close()


        self.maskEvent = True
        table = Util_Table.tableWidget(self.tableWidget)

        #20200801 table reconstruct
        table.createTable(rowLabels,colLabels)
        for col in range(table.tableWidget.columnCount()):
            table.setCellColor_yellow(0, col)
        #20200801 table reconstruct end

        for row in range(len(rowLabels)):
            for col in range(len(colLabels)):
                try:
                    val = float(colData1[row][col])
                    value = "%10.8f" % val
                    if value == "0.00000000":
                        value = "0.0"
                except:
                    value = colData1[row][col]
                #value = str(colData1[row][col])
                table.setCellValue(row, col, value)
        table.adjustCells()
        self.maskEvent = False

        logging.debug(object_types)



    def setLogText(self, line):
        """ lineをtextEditに表示する"""
        self.textEdit_log.append(line)

    def runLogThread(self):
        """ threadを起動する"""
        th = threading.Thread(target=self.getTableLog)
        self.flagThread = "run"
        th.start()

    def getTableLog(self):
        """ logFileを読み込み"""
        f = open(logFile)
        lines = f.read()        #空読み
        while self.flagThread == "run":
            line = f.readline()
            if line != "":
                if line[-1] == "\n":
                    line = line[:-1]
                #signalを発信
                self.textEdit_log.reloadSignal.emit(line)
            else:
                time.sleep(0.1)

    def okDialog(self, title, mess):
        msgBox = QMessageBox()
        msgBox.information(QDialog(), title, mess, msgBox.Ok)

    def errDialog(self, title, mess):
        msgBox = QMessageBox()
        msgBox.critical(QDialog(), title, mess, msgBox.Ok)


def inherit_file(filename, startDir):
    words = startDir.split("/")
    for i in range(len(words)):
        #name = words[len(words)-i-1]
        #ancestorDir = "/".join(words[:len(words)-i-1])
        ancestorDir = "/".join(words[:len(words)-i])

        folderDirs = glob.glob(ancestorDir + "/*")

        for item in folderDirs:
            if item == ancestorDir +"/" + filename:
                shutil.copy(ancestorDir + "/" + filename, startDir )
                print("use ancestor-settingfile")
                return
    print("not use ancestor-settingfile")
    return



def showGui(learnDir,init_loadDir):

    score_len=CommonUtil.getscorelen(learnDir)
    if score_len==0:
        print("score_length cannnot get")
        #exit()
        return
    div,param=CommonUtil.divname2num(os.path.basename(learnDir))

    rowLabels = ["score"]
    for i in range(len(param)):
        rowLabels.append("param"+str(i+1))
    colLabels = ["score"]
    for i in range(score_len-1):
        colLabels.append("sub"+str(i+1))
    colLabels.append("impmax(sub-param)")

    colLabels.append("rec_byscore")

    for i in range(score_len-1):
        colLabels.append("rec_bysub"+str(i+1))

    colLabels.append("rec_bysubs")
    colLabels.append("loadDir")
    colLabels.append("obj")
    colLabels.append("bind")
 
    aim_header_file = learnDir + "/aim_header.csv"
    obj_file =learnDir + "/obj.csv"
    bind_file = learnDir + "/bind.csv"

    #initial data of Gridtable
    colData2 = []


    temp_line = []

    for sub in range(score_len+1):
        temp_line.append(" ")

    try:
        inherit_file("aim_header.csv",learnDir)
        inherit_file("value_header.csv",learnDir)
    except:
        pass


    if os.path.exists(aim_header_file):
        logging.debug("tryread_header")
        try:
            f = open(aim_header_file)
            header_string = f.read();f.close()
            header_list = header_string[:-1].split(',')
            logging.debug("tryread_header2")
            for j in range(score_len):
                temp_line.append(header_list[j])
            logging.debug("tryread_success")

        except:
            #pass
            temp_line.append("lower_aim4s")
            for j in range(score_len-1):                        
                temp_line.append("lower_aim")
        temp_line.append("rec_bysubs")
        temp_line.append("loadDir_")
        temp_line.append("obj_")
        temp_line.append("bind_")

    else:

        temp_line.append("lower_aim4s")
        for sub in range(score_len-1):
            temp_line.append("lower_aim")
    temp_line.append("rec_bysubs")
    temp_line.append("loadDir_")
    temp_line.append("obj_")
    temp_line.append("bind_")
    colData2.append(temp_line)

    loadDir = []
    if init_loadDir!="None":
    
        loadDir = CommonUtil.direction_decode2str(learnDir, init_loadDir)

        if not loadDir:
            logging.debug("selectDir can't be traced the direction")
            loadDir=[" "] * (len(rowLabels)-1)
   
    else:
        print("No loadDir identified, So set defaut value (Center)")
        loadDir=["Center"] * (len(rowLabels)-1)


    try:
        inherit_file("obj.csv" ,learnDir)
        inherit_file("bind.csv" ,learnDir)
    except:
        pass

    try:
        #inherit_file("obj.csv" ,learnDir)
        f2 = open(obj_file)
        obj_string = f2.read();f2.close()
        obj_list = obj_string[:-1].split(',')
        #inherit_file("bind.csv" ,learnDir)
        f3 = open(bind_file)
        bind_string = f3.read();f3.close()
        bind_list = bind_string[:-1].split(',')
        logging.debug("exists set")
    except:
        obj_list=["-"] * (len(rowLabels)-1)
        bind_list=["score"] * (len(rowLabels)-1)
        logging.debug("new set")


    #print obj_list,bind_list,header_list
    logging.debug(bind_list)
    logging.debug(len(rowLabels),len(colLabels))

    for i in range(len(rowLabels)-1):
        temp_line = []


        for j in range(len(colLabels)-3):

            temp_line.append(" ")

        logging.debug(i)

        temp_line.append(loadDir[i])
        temp_line.append(obj_list[i])
        temp_line.append(bind_list[i])
        logging.debug("tryread_obj,bind")    
        colData2.append(temp_line)

    logging.debug(colData2)

    #Initial data of Gridtable

    lines = []
    line = ",".join([" "] + colLabels) + "\n"
    lines.append(line)
    for i in range(len(rowLabels)):
        strCol = list(map(str, colData2[i]))
        line = ",".join([rowLabels[i]] + strCol) + "\n"
        lines.append(line)
    f3 = open(learnDir + "/init_table.csv", "w")
    for line in lines:
        f3.write(line)
    f3.close()


    pre_fileName = learnDir + "/init_table.csv"
    pre_f = open(pre_fileName); pre_lines = pre_f.readlines(); pre_f.close()
    pre_colData = []
    for pre_line in pre_lines:
        pre_vals = pre_line[:-1].split(",")
        pre_colData.append(pre_vals)
    pre_colLabels = pre_colData[0][1:]
    pre_rowLabels = []
    pre_rowColVals = []
    for pre_vals in pre_colData[1:]:
        pre_rowLabels.append(pre_vals[0])
        pre_rowColVals.append(pre_vals[1:])

    app = QApplication(sys.argv)
    ui = gridTable(pre_rowLabels, pre_colLabels, pre_rowColVals)
    ui.main()
    sys.exit(app.exec_())

    # def starting():
    #     """ starting処理"""
    #     #runningFlagをセット
    #     f = open(flagFile, "w"); f.write("running"); f.close()


    # def ending():
    #     """ ending処理"""
    #     #runningFlagをクリア
    #     os.remove(flagFile)

if __name__ == "__main__":
    learnDir = sys.argv[1]
    #projDir = sys.argv[2]
    platformDir = sys.argv[2]
    init_loadDir = sys.argv[3]

    #ending処理(runningFlagをセット)
    # if init_loadDir == "None":
    #     print("Al element of loadDir set to the defaut value Center"")
    #     logFile = os.getenv("TableGui_log")
    # else:
    #     flagFile = os.getenv("TableGuiLoad_flag")
    #     logFile = os.getenv("TableGuiLoad_log")

    # if init_loadDir == "None":
    #     flagFile = os.getenv("TableGui_flag")
    #     logFile = os.getenv("TableGui_log")
    # else:
    #     pass
    #     logFile = os.getenv("TableGuiLoad_log")

    logFile = os.getenv("Optlog")

    #処理
    _main_div,main_param_list=CommonUtil.divname2num(os.path.basename(learnDir))

    ML_depth = len(main_param_list)

    showGui(learnDir,init_loadDir)



    # rowLabels = ["score", "param1", "param2", "param3", ""]
    # colLabels = ["score", "sub1", "sub2", "sub3", ""]
    # rowColVals = [[1, 2, 3, 4, ""],
    #               [11, 22, 33, 44, ""],
    #               [22, 23, 24, 25, ""],
    #               [33, 34, 35, 36, ""],
    #               [44, 45, 46, 47, ""]]
    # showGui(rowLabels, colLabels, rowColVals)
