#!/usr/bin/python3
# coding: utf-8
#
#  ExecUtil.py
#
import logging
logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)

from functools import partial
from decimal import Decimal
import sys
import os.path
import gettext
import tempfile
import math
import subprocess
from subprocess import Popen
import shutil
import glob
import threading
import re
import copy
import csv

import multiprocessing
import time

import CommonUtil
import random


def copyCase(projDir, resDir):
    """ 結果を保存する"""
    #resDir側をチェック
    
    sourceDir = projDir+"/SourceCase"
    
    if os.path.exists(resDir) == False:
        #resDir存在しない場合、作成
        os.mkdir(resDir)
    else:
        #resDir存在する場合、resDir内をクリアする
        #resDirがあってもdivは消さないように後日修正要

        pathes = glob.glob(resDir+"/*")
        for path in pathes:
            if os.path.isdir(path) and os.path.basename(path)[:len("div")] != "div":
                shutil.rmtree(path)
            elif os.path.isfile(path):
                os.remove(path)
            else:
                pass
    #sourecDir内のコピーするfolder、fileを取得
    pathes = glob.glob(sourceDir + "/*")
    folders = []
    files = []
    for path in pathes:
        if os.path.isdir(path):
            name = os.path.basename(path)
#            if name[:len("div")] != "div" and name != "postProcessing":
            #if name[:len("div")] != "div":
            folders.append(path)
        else:
            files.append(path)
    #folderをコピー
    for folder in folders:
        name = os.path.basename(folder)
        shutil.copytree(folder, resDir + "/" + name)
    #fileをコピー
    for file in files:
        name = os.path.basename(file)
        if name != "score.csv":
            shutil.copy(file, resDir)
    #param_listファイルを作成
    f = open(projDir + "/param_boundary.csv"); lines = f.readlines(); f.close()
    upperx = list(map(float, lines[0].replace(" ", "").split(",")))
    lowerx = list(map(float, lines[1].replace(" ", "").split(",")))

    param_list=[]

    job_div,job = CommonUtil.divname2num(os.path.basename(resDir))

    for i in range(len(job)):
        param_list.append((upperx[i]-lowerx[i])*float(job[i])/float(job_div) + lowerx[i])

    f2 = open(resDir + "/param_list.csv",'w')
    writer = csv.writer(f2)
    contents=[]
    writer.writerow(param_list)
    f2.close()

    #dateファイルを作成
    dateFile = resDir + "/date.csv"
    #  現在時刻を書き込み
    date = str(time.time())
    f = open(dateFile, "w"); f.write(date); f.close()




def createCaseDirs(projDir, startDir, job_lists, myself_div):
    #caseをコピーして作成する
    caseDirs = []
    for job in job_lists:
#        resDir = selectDir +"/" + CommonUtil.num2divname(myself_div,job)
        resDir = startDir +"/" + CommonUtil.num2divname(myself_div,job)
        scoreCsv = resDir + "/score.csv"
        if os.path.exists(resDir) == True and os.path.exists(scoreCsv) == True:
            pass
        else:

            copyCase(projDir, resDir)
            caseDirs.append(resDir)
    return caseDirs





def create_prejob_lists(TreeType, directions, startDir):
#    start_div, start_list = CommonUtil.divname2num(os.path.basename(startDir))
    prejob_lists =[]
    
    myself_div = None
        
    for direction in directions:
        prejob_list,myself_div = create_prejob_list(TreeType, direction, startDir)
        prejob_lists.append(prejob_list)

    return prejob_lists, myself_div

def create_prejob_lists4Abs(TreeType, directions, start_list):
#    start_div, start_list = CommonUtil.divname2num(os.path.basename(startDir))
    prejob_lists =[]
    
    myself_div = None
        
    for direction in directions:
        prejob_list,myself_div = create_prejob_list4Abs(TreeType, direction, start_list)
        prejob_lists.append(prejob_list)

    return prejob_lists, myself_div


def create_prejob_lists4AbsString(TreeType, directions, startDir):
    start_div, start_list = CommonUtil.divname2num(os.path.basename(startDir))
    start_list = [n*3 for n in start_list]
    
    prejob_lists =[]
    
    myself_div = None
        
    for direction in directions:
        prejob_list,myself_div = create_prejob_list4Abs(TreeType, direction, start_list)
        prejob_lists.append(prejob_list)

    return prejob_lists, myself_div








def create_prejob_list(TreeType, direction, startDir):
    start_div, start_list = CommonUtil.divname2num(os.path.basename(startDir))
    
    if TreeType == "Pascal":
        myself_div = start_div+1
        prejob_list=[]
        for ii in range(len(direction)):
            if start_list[ii] > start_div//2:
                position=start_list[ii]+direction[ii]//2
            else:
                position=start_list[ii]+(direction[ii]+1)//2
            prejob_list.append(position)
    elif TreeType == "Binary" or TreeType == "Binary_plusC":
        myself_div = start_div*2
        prejob_list=[]
        for ii in range(len(direction)):
            position=max(0,min(myself_div,2*start_list[ii]+direction[ii]-1))
            prejob_list.append(position)
            
    elif TreeType == "fcPascal" or TreeType == "fcPascal_plusC":
        epsilon = 0.00000000000000001
        
        if start_div % 3 == 0:        
            myself_div = (start_div//3)*4
        else:
            myself_div = (start_div//2)*3
                
               
        prejob_list=[]
        for ii in range(len(direction)):
            if start_list[ii]==0:
                position = max(0, direction[ii]-1)
            elif start_list[ii]==start_div:
                position = min(myself_div, myself_div + direction[ii]-1)
        
       
            elif start_list[ii] < (start_div+1)//2:
                position =  min( myself_div//2 -2  ,max(1, math.floor(( (start_list[ii]/start_div - 1/(2*myself_div)))  * myself_div - epsilon)  ))  + direction[ii]

            elif start_list[ii] > start_div//2:
                position =  max( (myself_div+1)//2 +2  ,min(myself_div-1, math.ceil(( (start_list[ii]/start_div + 1/(2*myself_div) ))  * myself_div + epsilon) ))  + direction[ii] -2 
                
            else: #when midpoint
                position = myself_div//2  + direction[ii] - 1

            prejob_list.append(position)

    else:
        logging.debug("TreeType is invalid") 
        exit()
            
    return prejob_list, myself_div



def create_prejob_list4Abs(TreeType, direction, start_list):
    #start_div, start_list = CommonUtil.divname2num(os.path.basename(startDir))
    start_div = 4
    
    if TreeType == "Pascal":
        myself_div = start_div+1
        prejob_list=[]
        for ii in range(len(direction)):
            if start_list[ii] > start_div//2:
                position=start_list[ii]+direction[ii]//2
            else:
                position=start_list[ii]+(direction[ii]+1)//2
            prejob_list.append(position)
    #only use this
    elif TreeType == "Binary" or TreeType == "Binary_plusC":
        myself_div = 12
        prejob_list=[]
        for ii in range(len(direction)):
        
            #20221019change for Abs
            #position=2*start_list[ii]+direction[ii]-1
            #20221029 min max add
            position=max(0,min(12,start_list[ii]+direction[ii]-1))
            #position=start_list[ii]+direction[ii]-1
            prejob_list.append(position)
            
    elif TreeType == "fcPascal" or TreeType == "fcPascal_plusC":
        epsilon = 0.00000000000000001
        
        if start_div % 3 == 0:        
            myself_div = (start_div//3)*4
        else:
            myself_div = (start_div//2)*3
                
               
        prejob_list=[]
        for ii in range(len(direction)):
       
            if start_list[ii] < (start_div+1)//2:
                position =  min( myself_div//2 -2  ,max(0, math.floor(( (start_list[ii]/start_div - 1/(2*myself_div)))  * myself_div - epsilon)  ))  + direction[ii]

            elif start_list[ii] > start_div//2:
                position =  max( (myself_div+1)//2 +2  ,min(myself_div, math.ceil(( (start_list[ii]/start_div + 1/(2*myself_div) ))  * myself_div + epsilon) ))  + direction[ii] -2 
                
            else: #when midpoint
                position = myself_div//2  + direction[ii] - 1

            prejob_list.append(position)

    else:
        logging.debug("TreeType is invalid") 
        exit()
 
    return prejob_list, myself_div







"""
def deleteDubjob_lists4Abs(TreeType, startDir, prejob_lists):
    start_div, _start_list = CommonUtil.divname2num(os.path.basename(startDir))
    folders = glob.glob(startDir+"/*")
    folderName = list(map(lambda x: os.path.basename(x), folders))
    logging.debug(folderName)

    deljob_lists=[]
    if TreeType == "Pascal":
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)
                    if temp_div==start_div+1:
                        deljob_lists.append(temp_list)                         
                except:
                    pass

    elif TreeType == "Binary" or TreeType == "Binary_plusC":
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)
                    #only pick up div12
                    if temp_div==12:
                        deljob_lists.append(temp_list)
                except:
                    pass


    elif TreeType == "fcPascal" or TreeType == "fcPascal_plusC": #when TreeType == "fcPascal
    
        if start_div % 3 == 0:        
            target_div = (start_div//3)*4
        else:
            target_div = (start_div//2)*3
        
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)

#                    if ((start_div %2==0 ^ temp_div %2==0) and temp_div==math.floor(start_div*7/5 - epsilon) + 2) or ((start_div %2==1 ^ temp_div %2==1) and temp_div==math.floor(start_div*7/5 - epsilon) + 1) :
#                    if (temp_div %2==0 and temp_div==math.floor(start_div*7/5 - epsilon) + 2) or ( start_div %2==1 and temp_div==math.floor(start_div*7/5 - epsilon) + 1) :
                    if temp_div == target_div:
                        deljob_lists.append(temp_list)
                except:
                    pass

    else:
        pass

    logging.debug(deljob_lists)
    prejob_lists= [tuple(d) for d in prejob_lists]
    deljob_lists= [tuple(d) for d in deljob_lists]
    job_lists=(set(prejob_lists) - set(deljob_lists))
    job_lists= [list(d) for d in job_lists]
    job_lists.sort()
    return job_lists
"""


def deleteDubjob_lists(TreeType, startDir, prejob_lists):
    start_div, _start_list = CommonUtil.divname2num(os.path.basename(startDir))
    folders = glob.glob(startDir+"/*")
    folderName = list(map(lambda x: os.path.basename(x), folders))
    logging.debug(folderName)

    deljob_lists=[]
    if TreeType == "Pascal":
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)
                    if temp_div==start_div+1:
                        deljob_lists.append(temp_list)                         
                except:
                    pass

    elif TreeType == "Binary" or TreeType == "Binary_plusC":
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)
                    if temp_div==start_div*2:
                        deljob_lists.append(temp_list)
                except:
                    pass


    elif TreeType == "fcPascal" or TreeType == "fcPascal_plusC": #when TreeType == "fcPascal
    
        if start_div % 3 == 0:        
            target_div = (start_div//3)*4
        else:
            target_div = (start_div//2)*3
        
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)

#                    if ((start_div %2==0 ^ temp_div %2==0) and temp_div==math.floor(start_div*7/5 - epsilon) + 2) or ((start_div %2==1 ^ temp_div %2==1) and temp_div==math.floor(start_div*7/5 - epsilon) + 1) :
#                    if (temp_div %2==0 and temp_div==math.floor(start_div*7/5 - epsilon) + 2) or ( start_div %2==1 and temp_div==math.floor(start_div*7/5 - epsilon) + 1) :
                    if temp_div == target_div:
                        deljob_lists.append(temp_list)
                except:
                    pass

    else:
        pass

    logging.debug(deljob_lists)
    prejob_lists= [tuple(d) for d in prejob_lists]
    deljob_lists= [tuple(d) for d in deljob_lists]
    job_lists=(set(prejob_lists) - set(deljob_lists))
    job_lists= [list(d) for d in job_lists]
    job_lists.sort()
    return job_lists


def deleteDubjob_lists4Abs(TreeType, startDir, prejob_lists):
    start_div, start_list = CommonUtil.divname2num(os.path.basename(startDir))


    deljob_lists=[]
#-------------------------------------------------------working--------------------------------------------------------------------
    if start_div == 4 or start_div == 3:

        search_depth = 4
        for currDir, _dirs, _files in os.walk(startDir):
            if currDir[len(startDir):].count(os.sep) < search_depth:

                #above row need to prepare, startDir /div4..., currDir simply div12_xxxx
                #and will better making div6 copy to div12, comment add?
                #? date file also  copy?
                #deleteDubjob_list4Abs exist 2, so need delete above.
                #more better use try?
                #2023/1/1
                #copy
                    
                #20230206 neutralize
                #if currDir.split("/")[-1][:len("div12")] == "div12" and os.path.exists(currDir +  "/" + "score.csv") and not os.path.exists(startDir + "'/" + os.path.basename(currDir)):
                    #comm = "mkdir '" + startDir + "'/" + os.path.basename(currDir)
                    #os.system(comm)
                    #comm = "cp '" + currDir + "'/score.csv" + " '" + startDir + "'/" + os.path.basename(currDir)
                    #os.system(comm)
                    #try:
                        #comm = "cp '" + currDir + "'/param_list.csv" + " '" + startDir + "'/" + os.path.basename(currDir)
                        #os.system(comm)
                    #except:
                        #pass
                               
                    #_div, target_list = CommonUtil.divname2num(currDir.split("/")[-1])
                    #deljob_lists.append(target_list) 

                if (currDir.split("/")[-1][:len("div12")] in ["div3_","div4_","div6_","div12"]) and os.path.exists(currDir +  "/" + "score.csv"):
                    
                    Dividor, pre_loadDir = CommonUtil.divname2num(os.path.basename(currDir))
                    loadDir = [(n*12//Dividor) for n in pre_loadDir]

                    loadDir_name = CommonUtil.num2divname(12, loadDir)

                    if os.path.exists(currDir +  "/" + "score.csv")==True and not os.path.exists(startDir + "'/" + loadDir_name) and not Dividor==None:
                        comm = "mkdir '" + startDir + "'/" + loadDir_name
                        os.system(comm)
                        comm = "cp '" + currDir + "'/score.csv" + " '" + startDir + "'/" + loadDir_name
                        os.system(comm)
                        if os.path.exists(currDir +  "/" + "param_list.csv")==True:
                            comm = "cp '" + currDir + "'/param_list.csv" + " '" + startDir + "'/" + os.path.basename(currDir)
                            os.system(comm)
                        #except:
                            #pass                        
   
       #20221030 div4 under div6 only refer div12 (when addtry, delete)
       #div6 X 2 delete from job (other side, refer when              
       #div4 under at delete job list?
       #this try only to set (all and delete?)



    #inherit_node = "temp"
    #if not os.path.exists(inherit_node):
        #comm = "mkdir "+ inherit_node
        #os.system(comm)


    #if os.path.exists(startDir + "/score.csv") and os.path.exists(inherit_node) and not(os.path.exists(inherit_node+"/score.csv")):
        #comm = "cp '" + startDir + "/score.csv" + "' " + inherit_node
        #print(comm)
        #os.system(comm)
#-------------------------------------------------------working--------------------------------------------------------------------
    folders = glob.glob(startDir+"/*")
    folderName = list(map(lambda x: os.path.basename(x), folders))
    logging.debug(folderName)


    if TreeType == "Pascal":
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)
                    if temp_div==start_div+1:
                        deljob_lists.append(temp_list)                         
                except:
                    pass

    elif TreeType == "Binary" or TreeType == "Binary_plusC":
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)
                    #if temp_div==start_div*2:
                    if temp_div==12:
                        deljob_lists.append(temp_list)
                except:
                    pass


    elif TreeType == "fcPascal" or TreeType == "fcPascal_plusC": #when TreeType == "fcPascal
    
        if start_div % 3 == 0:        
            target_div = (start_div//3)*4
        else:
            target_div = (start_div//2)*3
        
        for name in folderName:
            #if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True and os.path.exists(startDir+"/"+name+"/score.csv"):
            if name[:len("div")] == "div" and os.path.isdir(startDir+"/"+name)==True:
                try:
                    temp_div,temp_list = CommonUtil.divname2num(name)

#                    if ((start_div %2==0 ^ temp_div %2==0) and temp_div==math.floor(start_div*7/5 - epsilon) + 2) or ((start_div %2==1 ^ temp_div %2==1) and temp_div==math.floor(start_div*7/5 - epsilon) + 1) :
#                    if (temp_div %2==0 and temp_div==math.floor(start_div*7/5 - epsilon) + 2) or ( start_div %2==1 and temp_div==math.floor(start_div*7/5 - epsilon) + 1) :
                    if temp_div == target_div:
                        deljob_lists.append(temp_list)
                except:
                    pass

    else:
        pass

    logging.debug(deljob_lists)
    prejob_lists= [tuple(d) for d in prejob_lists]
    deljob_lists= [tuple(d) for d in deljob_lists]
    job_lists=(set(prejob_lists) - set(deljob_lists))
    #20221023 mult set use for copy
    existed_lists=(set(prejob_lists) & set(deljob_lists))
    existed_lists= [list(d) for d in existed_lists]    
    
    
    job_lists= [list(d) for d in job_lists]
    job_lists.sort()
    return job_lists


def addNoteCsv2job_list(myself_div, job_list, note, startDir):
    if note == "":
        return

    folderName = CommonUtil.num2divname(myself_div, job_list)
    folderDir = startDir + "/" + folderName
    noteCsv = folderDir + "/note.csv"
    if os.path.exists(noteCsv) == True:
        #shutil.copy(parentCsv, noteCsv)
        f = open(noteCsv, "a"); f.write(","+note); f.close()
    else:
        f = open(noteCsv, "w"); f.write(note); f.close()



def addNoteCsv2job_lists(myself_div, job_lists, note, startDir):
    if note == "":
        return
    for unit in job_lists:
        folderName = CommonUtil.num2divname(myself_div, unit)
        folderDir = startDir + "/" + folderName
        noteCsv = folderDir + "/note.csv"
        if os.path.exists(noteCsv) == True:
            #shutil.copy(parentCsv, noteCsv)
            f = open(noteCsv, "a"); f.write(","+note); f.close()
        else:
            f = open(noteCsv, "w"); f.write(note); f.close()



def DictateScore_copy(TreeType, selectDir):

    selectDir_name = os.path.basename(selectDir)
    parentDir = "/".join(selectDir.split("/")[:-1])
    parentDir_name = os.path.basename(parentDir)

    myself_div, myself_list = CommonUtil.divname2num(selectDir_name)
    parent_div, parent_list = CommonUtil.divname2num(parentDir_name)


    if TreeType == "Binary_plusC" or TreeType == "Binary" :
        double_temp_paramlist = [ i*2 for i in myself_list ]
        dbelownode_name = CommonUtil.num2divname( myself_div*2, double_temp_paramlist)
        if os.path.exists(selectDir +  "/" + dbelownode_name)==False and os.path.exists(selectDir + "/" + dbelownode_name + "/score.csv")==False and os.path.exists(selectDir + "/score.csv")==True:
            comm = "mkdir '" + selectDir + "'/" + dbelownode_name
            os.system(comm)
            comm = "cp '" + selectDir + "'/score.csv" + " '" + selectDir + "'/" + dbelownode_name
            os.system(comm)
            try:
                comm = "cp '" + selectDir + "'/param_list.csv" + " '" + selectDir + "'/" + dbelownode_name
                os.system(comm)
            except:
                pass            


    if TreeType == "fcPascal_plusC" or TreeType == "fcPascal" :
        temp_note=""
        if os.path.exists(selectDir +"/note.csv")==True:
            f = open(selectDir +"/note.csv"); temp_note= f.read(); f.close()

        #if temp_note[:len("pC")] == "pC" or os.path.exists(selectDir + "/statC.csv")==True:

        
        if ( (parent_div%3==0 and myself_div== (parent_div//3)*4 ) or ( parent_div%3!=0 and myself_div==(parent_div//2)*3 )) and os.path.exists(parentDir +"/score.csv")==True :

            epsilon = 0.00000000000000001
            
            double_temp_paramlist = [ i*2 for i in parent_list ]
            double_parent_div = 2 * parent_div
            inner_flag = True
            for x1,x2 in zip(myself_list,double_temp_paramlist):
                if x2 < ((double_parent_div+1) //2):
                    if abs(x2 -  min( double_parent_div//2 -2 ,max(0, math.floor(( (x1/myself_div - 1/(2*double_parent_div)))  * double_parent_div - epsilon) + 1 ))  ) >1:
                        inner_flag =False
                        logging.debug("parent pos is outer")
                        logging.debug(x1)
                elif  x2 > ( double_parent_div //2):
                    if  abs(x2 -  max( (double_parent_div+1)//2 +2 ,min(double_parent_div, math.ceil(( (x1/myself_div + 1/(2*double_parent_div) )) * double_parent_div + epsilon) -1)) ) >1:
                        inner_flag =False 
                        logging.debug("parent pos is outer2")
                        logging.debug(x1)
                else:
                    pass    
                        
            if inner_flag == True:
                
                dbelownode_name = CommonUtil.num2divname( parent_div*2, double_temp_paramlist)
                if os.path.exists(selectDir +  "/" + dbelownode_name)==False:
                    comm = "mkdir '" + selectDir + "'/" + dbelownode_name
                    os.system(comm)
                    comm = "cp '" + parentDir + "'/score.csv" + " '" + selectDir + "'/" + dbelownode_name
                    os.system(comm)
                    try:
                        comm = "cp '" + selectDir + "'/param_list.csv" + " '" + selectDir + "'/" + dbelownode_name
                        os.system(comm)
                    except:
                        pass            
                    
                    
                                                            

        elif (parent_div==2 and myself_div== 4 ):
            two_temp_paramlist = [ 2 for i in parent_list ]
            thtree_temp_paramlist = [ 3 for i in parent_list ]
            dbelownode_name = CommonUtil.num2divname( 6, thtree_temp_paramlist)
            div4center_name = CommonUtil.num2divname( 4, two_temp_paramlist)
            if os.path.exists(selectDir +  "/" + dbelownode_name)==False:
                comm = "mkdir '" + selectDir + "'/" + dbelownode_name
                os.system(comm)
                if os.path.exists(parentDir + "/score.csv")==True:
                    comm = "cp '" + parentDir + "'/score.csv" + " '" + selectDir + "'/" + dbelownode_name
                    os.system(comm)
                    try:
                        comm = "cp '" + selectDir + "'/param_list.csv" + " '" + selectDir + "'/" + dbelownode_name
                        os.system(comm)
                    except:
                        pass            

                    
                                        
                    
                elif os.path.exists(parentDir +"/" + div4center_name + "/score.csv")==True:
                    comm = "cp '" + parentDir +"/" + div4center_name + "'/score.csv" + " '" + selectDir + "'/" + dbelownode_name
                    os.system(comm)
                    try:
                        comm = "cp '" + selectDir + "'/param_list.csv" + " '" + selectDir + "'/" + dbelownode_name
                        os.system(comm)
                    except:
                        pass            

                else:
                    pass
        else:
            pass


def make_pCdirection(TreeType,selectDir ):

    selectDir_name = os.path.basename(selectDir)
    parentDir = "/".join(selectDir.split("/")[:-1])
    parentDir_name = os.path.basename(parentDir)

    myself_div, myself_list = CommonUtil.divname2num(selectDir_name)
    parent_div, parent_list = CommonUtil.divname2num(parentDir_name)


    pC_direction = []
    if TreeType == "fcPascal_plusC" or TreeType == "fcPascal":
        if myself_div%3!=0 and myself_div%2==0:
            for x1 in myself_list:
#            if (myself_div%3!=0 and myself_div%2==0 and x1%2==0) or (myself_div%3==0 and x1%3==0):
#                ancestor_direction4.append(1)
#            elif x1 < (myself_div+1)//2:        
#                ancestor_direction4.append(0)
#            else:            
#                ancestor_direction4.append(2)
                if x1%2==0:
                    pC_direction.append(1)
                elif x1 < (myself_div+1)//2:
                    pC_direction.append(0)
                else:            
                    pC_direction.append(2)

        elif myself_div%3==0 and myself_div%2==0:
            for x1 in myself_list:

                if x1 < (myself_div+1)//2 and x1==1:
                    pC_direction.append(0)
                
                elif x1 > myself_div//2 and x1==myself_div-1:
                    pC_direction.append(2)                    
                else:
                    pC_direction.append(1)

        else:
            pass
    return pC_direction                



def assignJobs(nProcs, caseDirs, projDir, platformDir, onlyCsv):

    if len(caseDirs)==0:
        return

    #nProcs毎に計算する
    procs  = [ "" for i in range(nProcs)]
    calcCases = caseDirs[:nProcs]
    #procs毎にjob投入
    nCount = 1
    for n in range(len(calcCases)):
        #procs起動
        caseDir = calcCases[n]
        #comm = USE_BASHRC + "python '"+projDir+"/target.py' " + str(nCpu_perCase) + " '" + caseDir + "' > '" + caseDir + "/proc.log'"
#        comm = "python '"+projDir+"/target.py' " + str(nCpu_perCase) + " '" + caseDir + "' > '" + caseDir + "/proc.log'"

#        comm = "cd '" + caseDir + "';" + "python3 '"+projDir+"/target.py' " +  " > '" + caseDir + "/proc.log'"


#        if onlyCsv == "0":
#            comm = "cd '" + caseDir + "';" + "python3 '"+projDir+"/target.py' " +  " > '" + caseDir + "/proc.log'"
#        else:
#            comm = "cd '" + caseDir + "';" + "python3 '"+projDir+"/target.py' " +  " > '" + caseDir + "/proc.log';" + 'python3 -c "import CommonUtil; CommonUtil.clearexceptCsv(' +'"'+caseDir+'"' + ')"'

        comm = "cd '" + caseDir + "';" + "python3 '"+projDir+"/target.py' " +  " > '" + caseDir + "/proc.log';" + "python3 '"+platformDir+"/clear_exceptCsv.py' '" + caseDir + "' " +onlyCsv 


        procs[n] = subprocess.Popen(comm, shell=True)
        print("----calculating", os.path.basename(caseDir), str(nCount)+"/"+str(len(caseDirs)))
        nCount += 1
    #jobの終了を待ちながら新しいjobを投入
    for caseDir in caseDirs[nProcs:]:
        #jobの終了を確認
        loop = True
        while loop:
            #0.5s毎に確認する
            time.sleep(0.5)
            flag = 0
            for n in range(nProcs):
                #procの終了を確認
                if procs[n].poll() != None:
                    #終了しているprocのcaseDirをcalcCasesから削除
                    _finishCase = calcCases.pop(n)
                    #新しいjobを追加
                    #comm = USE_BASHRC + "python '"+projDir+"/target.py' " + str(nCpu_perCase) + " '" + caseDir + "' > '" + caseDir + "/proc.log'"
#                    comm = "python '"+projDir+"/target.py' " + str(nCpu_perCase) + " '" + caseDir + "' > '" + caseDir + "/proc.log'"

#                    comm = "python '"+projDir+"/target.py' " +  " > '" + caseDir + "/proc.log'"

#                    comm = "cd '" + caseDir + "';" + "python3 '"+projDir+"/target.py' " +  " > '" + caseDir + "/proc.log'"
                    comm = "cd '" + caseDir + "';" + "python3 '"+projDir+"/target.py' " +  " > '" + caseDir + "/proc.log';" + "python3 '"+platformDir+"/clear_exceptCsv.py' '" + caseDir + "' " +onlyCsv


                    procs[n] = subprocess.Popen(comm, shell=True)
                    calcCases.append(caseDir)
                    print("----calculating", os.path.basename(calcCases[-1]), str(nCount)+"/"+str(len(caseDirs)))
                    flag = 1
                    break
            if flag == 1:
                #loop脱出し、次のcaseDirに進む

                #score.csvとparent_list.csvとchild_list.csvをinfo_layerxに書き込み
#                try:
#                    setdata2layer(caseDir)
#                except:
#                    pass

                loop = False
                break
        nCount += 1
    #全procの終了を待つ
    loop = True
    while loop:
        #for n in range(nProcs):
        for n in range(len(calcCases)):
            time.sleep(0.5)
            flag = 0
            #procお終了を確認
            if procs[n].poll() == None:
                #終了していない場合は、flagを立てる
                flag = 1
                break
        if flag == 0:
            #全て終了した場合loop脱出
            loop = False
            break

####future must move to parallel-loop
    for caseDir in caseDirs:
        setdata2layer(caseDir,projDir)

    print("------ all jobs are finished.")

# 64length
def line_adaptedlcg(line,mod,lcg_flag,lcg_constant,PatternCode):
    return_line=""
    if (lcg_flag != "0"):
        temp=1
        #20230114 temporary only this formation
        if (PatternCode[:len("logcode")] == "logcode" ):
        #if 1==1 :                        
            for i in range(len(line)):
#        return_line += line[(12^i % mod_length)-1]
#constant is 3,7,11,15,19,23,27,31
                temp = (temp*129 + lcg_constant) % mod
                if temp< mod//2:
                    return_line += str(2-int(line[i]))
                else:
                    return_line += line[i]
            logging.debug("@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
            logging.debug(return_line)
        elif (PatternCode[:len("4C2")] == "4C2" ):
            temp=1
            for i in range(len(line)):
                if i>-1:
                    temp = (5*temp + lcg_constant) % mod
                    region, amari = divmod(temp, 64)
                    return_line += line[ region ]        
        
        else:
            for i in range(len(line)):
                temp = (129*temp + lcg_constant) % mod
                return_line += line[temp ]
        
    else:
        return_line = line

    return return_line

def line_adaptedlcg_abs(line,mod,lcg_flag,lcg_constant,PatternCode):
    return_line=""
    if (lcg_flag != "0"):      
        
        #20230114 temporary only this formation
        if (PatternCode[:len("logcode")] == "logcode" ):
        #if 1==1 :
            temp=1                        
            for i in range(len(line)):
#        return_line += line[(12^i % mod_length)-1]

#constant is 3,7,11,15,19,23,27,31
                temp = (temp*129 + lcg_constant) % mod
                if temp< mod//2:
                    return_line += str(4-int(line[i]))
                else:
                    return_line += line[i]
            logging.debug("@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
            logging.debug(return_line)
        else:
            temp=1
            for i in range(len(line)):
                if i>-1:
                    temp = (5*temp + lcg_constant) % mod
                    region, amari = divmod(temp, 64)
                    return_line += line[ region ]
                else:
                    return_line += line[i] 
                
                
        return return_line        
    else:
        return_line = line

    return return_line





def setdata2layer(caseDir,projDir):

    case_divname = os.path.basename(caseDir)
    myself_div,myself_list = CommonUtil.divname2num(case_divname)

    #msb=1
    #try:
    #Add epsilon For gurantee setting intended integer
    epsilon= 0.01

    msb=int(math.log(myself_div+epsilon,2))
    #except:
    #    pass

    myself_layername= "layer"+str(msb)+"_info"

    if not os.path.exists(projDir+"/"+myself_layername):
        os.mkdir(projDir+"/"+myself_layername)

    if not os.path.exists(projDir+"/"+myself_layername+"/"+case_divname):
        os.mkdir(projDir+"/"+myself_layername+"/"+case_divname)

    
    files =glob.glob(caseDir +"/*")
    for file in files:
        if os.path.isfile(file) and (os.path.basename(file)).split(".")[-1] == "csv":  
            shutil.copy(file, projDir+"/"+myself_layername+"/"+case_divname)
    f = open(projDir+"/"+myself_layername+"/"+case_divname+"/"+"path2instance.csv",'w')
    ##future must change to relative path

    pathlen_projDir = len(projDir.split("/"))

    relativepath2instance = "/".join(caseDir.split("/")[pathlen_projDir:])

    f.write(relativepath2instance)
    f.close()

    print("write layer info") 


