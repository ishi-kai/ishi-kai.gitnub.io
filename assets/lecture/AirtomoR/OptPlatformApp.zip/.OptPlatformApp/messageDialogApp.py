#!/usr/bin/python3
# -*- coding: utf-8 -*-
#
#       messageDialogApp.py
#


#from PyQt4 import QtCore, QtGui
#from PySide import QtCore, QtGui
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
import time
import threading


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(310, 95)
        Dialog.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.dialog = Dialog
        self.verticalLayout = QVBoxLayout(Dialog)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QLabel(Dialog)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.pushButton = QPushButton(Dialog)
        self.pushButton.setObjectName("pushButton")
        self.horizontalLayout.addWidget(self.pushButton)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(Dialog)
        QMetaObject.connectSlotsByName(Dialog)
        self.pushButton.clicked.connect(self.close)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle("excutor state")
        self.label.setText("excutor calculating...")
        self.pushButton.setText("close")

    def close(self, *args):
        self.dialog.close()



def keyInput():
    """ 標準入力から入力があると、dialogをcloseする"""
    #key = raw_input()
    key = input()
    Dialog.close()


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    Dialog = QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    th = threading.Thread(target=keyInput)
    th.start()
    sys.exit(app.exec_())

