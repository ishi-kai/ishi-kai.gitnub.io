#!/usr/bin/python3
#  coding: utf-8
#

"""
Opt_platform.py
Copyright (C) 2020 Tsunehiro Watanabe, Shigeki Fujii all rights reserved.

This software is released under the MIT License.
http://opensource.org/licenses/mit-license.php
"""

import logging
logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)


import sys, os, glob
import decimal
import pathlib
import math

# try:
#     from PySide import QtCore, QtGui
# except:
#     from PyQt4 import QtCore, QtGui
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import CommonUtil
import ExecUtil


#-------------------
#  TreeWidget class
#-------------------
#class TreeWidget(QtGui.QTreeWidget):
class TreeWidget(QTreeWidget):
    """ add signal by overloading treewidget"""
    try:
        #reloadSignal = QtCore.pyqtSignal()
        reloadSignal = pyqtSignal()
    except:
        #reloadSignal = QtCore.Signal()
        reloadSignal = Signal()


#-----------------------
#  treeWidget_Extend class
#-----------------------
class treeWidget_Extend:
    """ class for making directory-tree
    
    Attribute:
        treeWidget (QTreeWidget)    :QtのtreeWidgte
        maskEvent (bool)            :for masking expanding expandEvent
        iconFolder (QPixmap)        :icon of directory
        rootDir (str)               :hightest position of directry-tree
        selDir (str)                :making tree as expanded to selDir"""

    def __init__(self, selDir):
        self.treeWidget = TreeWidget()
        self.maskEvent = True           #masking event
        #setting icon
        iconDir = os.getenv("HOME") + "/.OptPlatformApp"
        #self.iconFolder = QtGui.QIcon()
        #self.iconFolder.addPixmap(QtGui.QPixmap(iconDir + "/folder16.png"))
        self.iconFolder = QIcon()
        self.iconFolder.addPixmap(QPixmap(iconDir + "/folder16.png"))
        #setting selDir 
        self.rootDir = os.getenv("HOME")
        if type(selDir) != str:
            selDir = selDir.encode("utf-8")
        self.selDir = selDir
        #flag of sorting
        self.glob_quadindex = 0
        n = self.glob_quadindex


        #self.headers = ["directory", "score", "sub1", "sub2", "sub3", "sub4", "stat","nValley" , "note", "nChild"]
        self.headers = ["directory", "score", "sub"+str(4*n+1), "sub"+str(4*n+2), "sub"+str(4*n+3), "sub"+str(4*n+4), "stat","nValley" , "note", "nChild"]
        #self.headers = ["directory", "score", "sub1", "sub2", "sub3", "note", "nChild", "nValley", "stat"]
        self.sortScoreFlag = "yes"
        self.sortCoeff = 1.0    #1:ascend、-1:descend
        self.sortColNo = 1      #the index of sort-row
        #---- data format --------------------------------
        # self.dataDict = {
        #     "/home/caeuser":                [],
        #     "/home/caeuser/CAE":            [0,0],
        #     "/home/caeuser/CAE/test":       [1, 2],
        #     "/home/caeuser/CAE/test1":      [3, 4],
        #     "/home/caeuser/CAE/test1/test": [6, 7],
        #     "/home/caeuser/TEST":           [0,0],
        #     "/home/caeuser/TEST/test_1":    [2, 1]
        #     }
        # self.rootDir = "/home/caeuser"
        # self.selDir = "/home/caeuser/CAE/test1"

    #
    #  main
    #-----------
    def main(self):
        """setting dir-information and making directory-tree"""
        rootDir = self.rootDir
        selDir = self.selDir
        #making header
        #self.headers = ["directory", "score", "sub1", "sub2", "sub3", "sub4", "note"]
        self.createTreeWidget()
        #getting tree-data as dictionary
        self.dataDict = self.createDataDictionary(rootDir, selDir)
        #transform the dictionary-data to treeData
        self.treeData = self.createTreeData(rootDir)
        #setting treeData to treeWidget
        self.setItemsToTreeWidget()
        #expand tree to selDir and selected state
        self.selectDir(selDir)
        #adjusting the width of col
        self.adjustColumnsSize()
        #turn off the eventMask
        self.createEvent()
        self.maskEvent = False

    def close(self):
        #QtGui.qApp.quit()
        qApp.quit()

    def createEvent(self):
        """ making event"""
        self.treeWidget.itemChanged.connect(self.onItemChangeed)
        self.treeWidget.itemClicked.connect(self.onItemClicked)
        self.treeWidget.itemExpanded.connect(self.onItemExpanded)
        self.treeWidget.reloadSignal.connect(self.onReloadFolders)



    #------- event handler --------------
    #itemの内容が変更された時
    def onItemChangeed(self, selItem, col):
        pass
    #itemをクリックした時
    def onItemClicked(self, selItem, col):
        #self.selDir = self.getDirFromItem(selItem)
        self.adjustColumnsSize()
    #itemを展開した時
    def onItemExpanded(self, expItem):
        if self.maskEvent == False:
            self.itemExpanded(expItem)
    #reload
    def onReloadFolders(self):
        self.reloadFolders()
    #-----------------------------------------

    def reloadFolders(self):
        """ folderを再読込。選択folderを記憶し、再表示後選択する。"""
        #treeのデータを辞書で取得
        rootDir = self.rootDir
        items = self.treeWidget.selectedItems()
        if len(items) == 0:
            selDir = self.selDir
        else:
            selDir = self.getDirFromItem(items[0])
        self.dataDict = self.createDataDictionary(rootDir, selDir)
        #辞書データをtreeDataに変換
        self.treeData = self.createTreeData(rootDir)
        #root以下を削除
        rootItem = self.treeWidget.topLevelItem(0)
        for _i in range(rootItem.childCount()):
            delItem = rootItem.child(0)
            rootItem.removeChild(delItem)
        #rootitem以下を再作成
        items = self.treeData[1]
        rootDir = self.treeData[0]
        self.addTreeNodes(rootItem, [rootDir], items)
        #treeのselDirを展開し、選択
        self.selectDir(selDir)
        #col幅を調整する
        self.adjustColumnsSize()

    def itemExpanded(self, item):
        """ itemを展開した時、そのfolder内のdataを再読み込みし、treeを再作成する"""
        #itemの子itemを全て削除（辞書も該当部を削除）
        self.deleteChildItems(item)
        #item以下のfolderを取得
        itemDir = self.getDirFromItem(item)
        folders = self.getFolders(itemDir)
        folders += self.getChildFolders(folders)
        #辞書を追加
        self.addDataToDataDict(folders)
        #treeDataを再作成
        rootDir = self.treeData[0]
        self.treeData = self.createTreeData(rootDir)
        #item以下を再作成
        items = self.getItemsFromTreeData(itemDir)
        parentDir = [rootDir] + itemDir[len(rootDir)+1:].split("/")
        self.addTreeNodes(item, parentDir, items)
        #col幅を調整する
        self.adjustColumnsSize()

    def deleteChildItems(self, parentItem):
        """ childItemを全て削除する。
        self.dataDict（辞書）も更新する。
        parentItemがrootの場合、何もせず戻る。"""
        #parentDirを取得
        parentDir = self.getDirFromItem(parentItem)
        rootDir = self.treeData[0]
        if parentDir == rootDir:
            return
        #辞書からparentDir以下を削除
        folders = list(self.dataDict.keys())
        for folderDir in folders:
            if folderDir[:len(parentDir)+1] == parentDir + "/":
                dummy = self.dataDict.pop(folderDir)
        #treeWidgetからchildrenを削除
        for _idx in range(parentItem.childCount()):
            delItem = parentItem.child(0)
            parentItem.removeChild(delItem)

    def getItemsFromTreeData(self, selDir):
        """ dirをたどって、treeDataのitemsを取得する"""

        def getTreeNodes(items, name):
            """ treeData内のitems内からnameが持っているitemsを取得する"""
            for item in items:
                newItems = ""
                if type(item) == str:
                    newItems = name
                else:
                    if item[0] == name:
                        newItems = item[1]
                        break
            return newItems

        rootDir = self.treeData[0]
        items = self.treeData[1]
        words = selDir[len(rootDir)+1:].split("/")
        for name in words:
            items = getTreeNodes(items, name)
        return items

    def addDataToDataDict(self, folders):
        """ folders内のデータをdataDictに追加する"""
        for folder in folders:
            colConts = self.getColContsAtFolder(folder)
            self.dataDict[folder] = colConts

    def createDataDictionary(self, rootDir, selDir):
        """ dirとそれに対応するdataの辞書を作成する。"""
        folders = self.getDirUnderRootToSelDir(rootDir, selDir)
        dataDict = {}
        for folder in folders:
            colConts = self.getColContsAtFolder(folder)
            dataDict[folder] = colConts
        return dataDict


    def getColContsAtFolder(self, folder):
        """ folderDirに対応するdata（colConts）を取得する"""
        colConts = ["" for i in range(len(self.headers)-1)]
        if os.path.exists(folder + "/score.csv"):
            f = open(folder + "/score.csv")
            cont = f.read()
            f.close()
            cont = self.remakeScoreLine(cont)
            #colConts = [cont]
            cols = cont.split(",")
            
#            glob_quadindex = 0
            #for i in range(len(cols)):
            for i in range(5): #最終スコア＋4表示subスコア
                if i==0:
                    colConts[i] = cols[i]
                else:
                    if (self.glob_quadindex*4 + i) < len(cols):
                        colConts[i] = cols[self.glob_quadindex*4 + i]
            # if os.path.exists(folder + "/note.csv"):
            #     f = open(folder + "/note.csv"); cont = f.read(); f.close()
            #     note = cont.split("\n")[0]
            #     colConts[-3] = note
            parentFolder = folder.split("/")[-2]
            if parentFolder[:len("layer")] == "layer":
                fileName = folder + "/path2instance.csv"
                f = open(fileName); linkDir = f.read(); f.close()
                projDir = "/".join(folder.split("/")[:-2])
                linkDir = projDir + "/" + linkDir
                useDir = linkDir
                preCaseDirs = glob.glob(linkDir + "/div*")
                caseDirs = []
                for name in preCaseDirs:
                    if os.path.isdir(name) == True:
                        caseDirs.append(name)
                nValley = self.countValley(caseDirs,linkDir)
                nValley = str(nValley)
                #if nValley == "0":
                #    nValley = ""
                colConts[-3] = nValley
#                if os.path.exists(folder + "/stat.csv") == True:
                if os.path.exists(linkDir + "/statC.csv") == True:
                    colConts[-4] = "C"
                elif  os.path.exists(linkDir + "/statV.csv") == True:   
                    colConts[-4] = "V"
                else:
                    colConts[-4] = ""
                nChild = str(len(caseDirs))
                if nChild == "0":
                    nChild = ""
                #colConts += [nChild]
                colConts[-1] = nChild
            else:
                useDir = folder
                preCaseDirs = glob.glob(folder + "/div*")
                caseDirs = []
                for name in preCaseDirs:
                    if os.path.isdir(name) == True:
                        caseDirs.append(name)
                nValley = self.countValley(caseDirs,folder)
                nValley = str(nValley)
                #if nValley == "0":
                #    nValley = ""
                colConts[-3] = nValley
                if os.path.exists(folder + "/statC.csv") == True:
                    colConts[-4] = "C"
                elif os.path.exists(folder + "/statV.csv") == True:
                    colConts[-4] = "V"
                else:
                    colConts[-4] = ""
                nChild = str(len(caseDirs))
                if nChild == "0":
                    nChild = ""
                #colConts += [nChild]
                colConts[-1] = nChild

#            if os.path.exists(folder + "/note.csv"):
#                f = open(folder + "/note.csv"); cont = f.read(); f.close()

            if os.path.exists(useDir + "/note.csv"):
                f = open(useDir + "/note.csv"); cont = f.read(); f.close()
                note = cont.split("\n")[0]
                colConts[-2] = note
            else:
                colConts[-2] = ""

        elif os.path.exists(folder + "/note.csv"):
            f = open(folder + "/note.csv"); cont = f.read(); f.close()
            note = cont.split("\n")[0]
            colConts[-2] = note
                
        else:
            colConts = []
        return colConts


    def countValley(self, caseDirs,parentDir):

        parent_div,parent_list = CommonUtil.divname2num(os.path.basename(parentDir))
        if parent_div == None:
        #return blank ,
            return ""

        hub_score = CommonUtil.getscore(parentDir)
        if hub_score == None:
            return ""
    
        change_flag =False
        confirm_nodes = []
        num_Valley=0
        num_Plane=0
        num_divnode = 0
        max_crrespond = 400
    
        for caseDir in caseDirs:
            if not(os.path.exists(caseDir+"/statV.csv") or os.path.exists(caseDir+"/statC.csv") or os.path.exists(caseDir+"/statP.csv") or os.path.exists(caseDir+"/statchecked.csv")):
                change_flag = True
                confirm_nodes.append(caseDir)
                pathlib.Path(caseDir + "/statchecked.csv").touch()
            
            elif os.path.exists(caseDir+"/statV.csv"):
                num_Valley = num_Valley + 1
            elif os.path.exists(caseDir+"/statC.csv"):
                pass
            elif os.path.exists(caseDir+"/statP.csv"):
                num_Plane= num_Plane + 1
            else:
                confirm_nodes.append(caseDir)
                pathlib.Path(caseDir + "/statchecked.csv").touch() 
                
        
        if change_flag==False:
            if (num_Valley + num_Plane) ==0:
                return ""
            else:
                return (str(num_Valley) + "/" + str(num_Valley + num_Plane) )        
        
        Pascal_directions = []
        fcPascal_directions = []
        Binary_directions = []
        div12_directions = []

        for confirm_node in confirm_nodes:
            #myself_div,myself_list = CommonUtil.divname2num(os.path.basename(confirm_node))
                 # when not established divname2num, return None
            attr_TreeType, direction = CommonUtil.direction_decode(parentDir, confirm_node)
                #if direction==None:
                #    continue             
            direction = self.foldback(direction,confirm_node)
            if attr_TreeType == "Pascal":
                Pascal_directions.append(direction)
            elif attr_TreeType == "fcPascal":
                fcPascal_directions.append(direction)
            elif attr_TreeType == "Binary":
                Binary_directions.append(direction)
            elif attr_TreeType == "div12":
                div12_directions.append(direction)
            else:
                pass
                                                    
        Pascal_directions.sort()
        fcPascal_directions.sort()
        Binary_directions.sort()
        div12_directions.sort()

        logging.debug(Pascal_directions)

        Pascal_pair_directions= self.extract_pair(Pascal_directions)
        fcPascal_pair_directions= self.extract_pair(fcPascal_directions)
        Binary_pair_directions= self.extract_pair(Binary_directions)
        div12_pair_directions= self.extract_pair(div12_directions)

        add_total_pair_num = len(Pascal_pair_directions) + len(fcPascal_pair_directions) + len(Binary_pair_directions) + len(div12_pair_directions)


        #print("---------previous---------")
        #print(div12_directions)
        #print("---------after---------")
        #print(div12_pair_directions)

        logging.debug("Pascal_pair_init")
        logging.debug(Pascal_pair_directions)
        logging.debug("Pascal_pair_close")

        Pascal_lists, Pascal_div=  ExecUtil.create_prejob_lists("Pascal",Pascal_pair_directions, parentDir)
        fcPascal_lists, fcPascal_div = ExecUtil.create_prejob_lists("fcPascal",fcPascal_pair_directions, parentDir)
        Binary_lists, Binary_div = ExecUtil.create_prejob_lists("Binary",Binary_pair_directions, parentDir)

        parent_list4div12 = [n*3 for n in parent_list]
                
        div12_lists, div12_div = ExecUtil.create_prejob_lists4Abs("Binary",div12_pair_directions, parent_list4div12)

        logging.debug("Pascal_pair_init")
        logging.debug(Pascal_lists)
        logging.debug("Pascal_pair_close")
        #print("---------as lists---------")
        #print(div12_lists)
        
        Pascal_numValley = self.calcandwrite_Valley(Pascal_lists, hub_score, parentDir, Pascal_div)
        fcPascal_numValley = self.calcandwrite_Valley(fcPascal_lists, hub_score, parentDir, fcPascal_div)
        Binary_numValley = self.calcandwrite_Valley(Binary_lists, hub_score, parentDir, Binary_div)        
        div12_numValley = self.calcandwrite_Valley(div12_lists, hub_score, parentDir, div12_div)        



        if (num_Valley + num_Plane + add_total_pair_num) ==0:
            return ""
        else:
            return (str(num_Valley + Pascal_numValley + fcPascal_numValley + Binary_numValley + div12_numValley) + "/" + str( num_Valley + num_Plane + add_total_pair_num ))

#        for i in range(len(Binarycase_mirror)//2):
#            print(Binarycase_mirror[i])
#            oneDir = CommonUtil.num2divname(parent_div*2,Binarycase_mirror[i] )
#            otherDir = CommonUtil.num2divname(parent_div*2, Binarycase_mirror[len(Binarycase_mirror)-i-1])
#            score1= CommonUtil.getscore(parentDir + "/" + oneDir)
#            score2= CommonUtil.getscore(parentDir + "/" + otherDir)
#            if score1 != None and score2 != None and score != None:
#                if (score1-score)*(score2-score)>0:
#                    Binary_countValley += 1
#                    fileName = parentDir + "/" + oneDir + "/stat.csv"

#                else:
#                    fileName = parentDir + "/" + otherDir + "/stat.csv"
#                    f=open(fileName, "w")
#                    cont = "V"
#                    f.write(cont)
#                    f.close()

#        return str(Pascal_countValley + Binary_countValley) + "/" + str((len(Pascalcase_mirror)+len(Binarycase_mirror))//2)
#        return (str(num_Valley) + "/" + str(len(caseDirs)) )

    def extract_pair(self, directions):
        pair_directions = []

        for i in range(len(directions)-1):
            if directions[i]==directions[i+1]:
#                num_nValley = num_nValley + 2   
#                f= open( statV.csv, w)
                pair_directions.append(directions[i])       
                pair_directions.append( CommonUtil.inversed_direction(directions[i]) )       
        return pair_directions

    def calcandwrite_Valley(self, paired_lists, hub_score,parentDir, myself_div):
        num_countValley = 0
        #20210218
        logging.debug(paired_lists)
        
        for i in range(len(paired_lists)//2):
            oneDir = CommonUtil.num2divname( myself_div ,paired_lists[2*i] )
            otherDir = CommonUtil.num2divname( myself_div ,paired_lists[2*i+1] )
#            score = CommonUtil.getscore(parentDir)
            score1= CommonUtil.getscore(parentDir + "/" + oneDir)
            score2= CommonUtil.getscore(parentDir + "/" + otherDir)
#            print "----", oneDir, score1
#            print "1111", otherDir, score2
            if score1 != None and score2 != None and hub_score != None:
                if (score1 - hub_score)*(score2 - hub_score)>0:
                    #Pascal_Valley += Pascal_countValley + 1
                    num_countValley += 2
                    pathlib.Path(parentDir + "/" + oneDir + "/statV.csv").touch()                                            
                    pathlib.Path(parentDir + "/" + otherDir + "/statV.csv").touch()
                else:
                    pathlib.Path(parentDir + "/" + oneDir + "/statP.csv").touch()                                            
                    pathlib.Path(parentDir + "/" + otherDir + "/statP.csv").touch()
        return num_countValley


    def foldback(self, direction, abspath):
        #20230115edit
        for i, elem in enumerate(direction):
            if elem <=0:
                return direction
            elif elem >=2:
                return CommonUtil.inversed_direction(direction)
            elif elem==1 and i==len(direction)-1:            
                pathlib.Path(abspath + "/statC.csv").touch()    
                return direction
            else:
                pass
        return direction
    

    def remakeScoreLine(self, cont):
        """ scoreの値を丸める。"""
        words = cont.split(",")
        try:
            scores = list(map(float, words))
        except:
            scores = ""
        #有効数字を丸める
        nPrec = 8           #値が全8桁になる様に整形する
        setVals = []
        # decimal.getcontext().prec = nPrec
        for score in scores:
            #xx = str(decimal.Decimal(score) + decimal.Decimal(0)).lower()
            #xx = "%9.1f" % score
            xx = "%11.3f" % score
            if xx[0] != " ":
                #指数表記に変更
                xx = "%11.7e" % score
            setVals.append(xx)

            # # if xx[0] != "-":
            # #     xx = " " + xx
            # # n = xx.find("e")
            # if n < 0:
            #     if score == 0.0:
            #         xx = " " * ((nPrec + 1) - 3) + "0.0"
            #     else:
            #         #有効数字を確認
            #         if len(xx) > nPrec:
            #             xx = xx[:nPrec]
            #         else:
            #             xx = xx + " " * (nPrec-len(xx))
            #         #小数点があるか
            #         if xx.find(".") < 0:
            #             #小数点が無くなった場合(指数に置き換える)
            #             xx = "%9.5e" % score
            #             # if xx[0] != "-":
            #             #     xx = " " + xx
            #             # s = len(xx) - nPrec - 5
            #             # if s < 0:
            #             #     xx = xx[:n] + "0"*s + xx[n:]
            #             # else:
            #             #     n = xx.find("e")
            #             #     xx = xx[:n-s] + xx[n:]
            # else:
            #     #縮める文字数
            #     s = len(xx) - nPrec - 5
            #     xx = xx[:n-s] + xx[n:]
            #     pass
            # setVals.append(xx)
        #1行を作成
        line = ""
        for val in setVals:
            if len(val) < nPrec:
                line += " " * (nPrec - len(val)) + val + ", "
            else:
                line += val + ", "
        line = line[:-2]
        return line

    def unselectAllItems(self):
        """ 全itemを非選択に設定する"""
        items = self.treeWidget.selectedItems()
        for item in items:
            item.setSelected(False)

    def getSelectedItems(self):
        """ 選択しているitemをlist形式で取得する"""
        items = self.treeWidget.selectedItems()
        return items

    def selectDir(self, selDir):
        """ selDirを選択表示する。"""
        #全項目を非選択に設定
        self.unselectAllItems()
        #selDirのitemを取得
        selItem = self.getItemFromDir(selDir)
        #selItemまで展開
        self.expandToItem(selItem)
        #selItemを選択
        selItem.setSelected(True)
        #selItemまでscroll
        #self.treeWidget.scrollToItem(selItem, QtGui.QAbstractItemView.PositionAtCenter)
        self.treeWidget.scrollToItem(selItem, QAbstractItemView.PositionAtCenter)

    def expandToItem(self, selItem):
        """ rootからselItemまで展開する"""
        #eventMask
        self.maskEvent = True
        #展開するitemを取得
        items = [selItem]
        rootItem = self.treeWidget.topLevelItem(0)
        while selItem is not rootItem:
            selItem = selItem.parent()
            items = [selItem] + items
        items = [rootItem] + items
        #itemを展開
        for item in items:
            self.treeWidget.expandItem(item)
        #mask解除
        self.maskEvent = False

    def getItemFromDir(self, selDir):
        """ dirからitemを取得"""
        rootDir = self.treeData[0]
        folders = selDir[len(rootDir)+1:].split("/")
        parentItem = self.treeWidget.topLevelItem(0)
        for folder in folders:
            for idx in range(parentItem.childCount()):
                childItem = parentItem.child(idx)
                text = childItem.text(0)
                if text == folder:
                    break
            parentItem = childItem
        return parentItem

    def getDirFromItem(self, selItem):
        """ itemからdirを取得する"""

        def convQstringToText(string):
            """ python2, 3で動作が異なるので、ここで修正。"""
            #python2 or 3 対応に変換
            try:
                #python2の場合、変換する。
                string = string.toUtf8().data()
            except:
                #python3の場合、エラー発生。変換せず。
                pass
            
            #PySide or PyQt4対応で変換
            try:
                #PySideの場合、unicodeで戻るので、strに変換
                if type(string) != str:
                    string = string.encode("utf-8")
            except:
                #PyQt4の場合は、そのまま戻る
                pass
            return string

        words = []
        rootItem = self.treeWidget.topLevelItem(0)
        while selItem is not rootItem:
            text = selItem.text(0)
            text = convQstringToText(text)
            words = [text] + words
            selItem = selItem.parent()
        rootText = rootItem.text(0)
        rootText = convQstringToText(rootText)
        words = [rootText] + words
        selDir = "/".join(words)
        return selDir

    def createTreeWidget(self):
        """ treeのcolumnタイトルを設定する"""
        headers = self.headers
        nCol = len(headers)
        self.treeWidget.setColumnCount(nCol)
        for col in range(len(headers)):
            header = headers[col]
            self.treeWidget.headerItem().setText(col, header)
        self.setScoreLabel()

    def setScoreLabel(self):
        """ flagに応じてscoreLabelを設定し直す"""
        if self.sortScoreFlag == "no":
            return
        else:
            colLabel = self.headers[self.sortColNo]
            if self.sortColNo == 0:
                scoreLabel = colLabel + u"（timeStamp-order）"
            else:
                if self.sortCoeff == 1:
                    scoreLabel = colLabel + u"（asc）"
                elif self.sortCoeff == -1:
                    scoreLabel = colLabel + u"（dsc）"
        col = self.sortColNo
        self.treeWidget.headerItem().setText(col, scoreLabel)

    def setItemsToTreeWidget(self):
        """ treeDataをTreeWidgetにセットする"""
        treeData = self.treeData
        dataDict = self.dataDict
        rootName = treeData[0]
        items = treeData[1]
        #parentItem = QtGui.QTreeWidgetItem(self.treeWidget)
        parentItem = QTreeWidgetItem(self.treeWidget)
        parentItem.setText(0, rootName)
        parentItem.setIcon(0, self.iconFolder)
        colConts = dataDict[rootName]
        self.setColConts(parentItem, colConts)
        self.addTreeNodes(parentItem, [rootName], items)

    def setColConts(self, item, colConts):
        """ item中にcol内容をセットする"""
        for i in range(len(colConts)):
            value = colConts[i]
            col = i + 1
            if type(value) == str:
                item.setText(col, value)
            elif type(value) == int or type(value) == float:
                item.setText(col, str(value))
            else:
                item.setIcon(col, value)

#20210405test
#                item.setIcon(col, str(value))


    def addTreeNodes(self, parentItem, parentDir, items):
        """ TreeItemを作成する"""
        for item in items:
            if type(item) == str:
                itemDir = parentDir + [item]
                colConts = self.dataDict["/".join(itemDir)]
                #child = QtGui.QTreeWidgetItem(parentItem)
                child = QTreeWidgetItem(parentItem)
                child.setIcon(0, self.iconFolder)

                #(20240927)if divname change foldername to other file, need to change this for representation
                child.setText(0, item)
                self.setColConts(child, colConts)
            else:
                itemDir = parentDir + [item[0]]
                colConts = self.dataDict["/".join(itemDir)]
                #child = QtGui.QTreeWidgetItem(parentItem)
                child = QTreeWidgetItem(parentItem)
                
                #(20240927)if divname change foldername to other file, need to change this for representation
                child.setText(0, item[0])
                child.setIcon(0, self.iconFolder)
                self.setColConts(child, colConts)
                self.addTreeNodes(child, itemDir, item[1])

    def adjustColumnsSize(self):
        """ column幅をadjustする"""
        nCols = self.treeWidget.columnCount()
        for col in range(nCols):
            self.treeWidget.resizeColumnToContents(col)

    def createTreeData(self, rootDir):
        """ treeDataDictからtreeDataを返す。sortしたtreeDataを作成。"""
        dataDict = self.dataDict        
        rootName = "root"
        treeData = [rootDir, []]
        folders = []
        folderDirs = list(dataDict.keys())
        folderDirs.sort()
        #sortする？
        if self.sortScoreFlag == "yes":
            #指定された列をsortする
            newFolderDirs = []
            for folder in folderDirs:
                data = [folder]
                dirName = os.path.dirname(folder)
                data.append(dirName)
                if len(dataDict[folder]) > 0:
                    scoreNo = self.sortColNo - 1
                    scores = dataDict[folder]
                    if scoreNo < 0:
                        #directoryをsort
                        dateFile = folder + "/date.csv"
                        if os.path.exists(dateFile) == True:
                            #score = os.path.getmtime(dateFile)
                            f = open(dateFile); date = f.read(); f.close()
                            score = float(date)
                        else:
                            score = os.path.getmtime(folder)
                        data.append(score)
                    elif scoreNo < len(scores):
                        #score値をsort

#20210405 change to try-except
#                        if scores[scoreNo] != "":
#                            score = float(scores[scoreNo])      #sortする値
#                        else:
#                            score = float('inf') * self.sortCoeff

                        try:
                            score = float(scores[scoreNo])      #sortする値
                        except:
                            score = float('inf') * self.sortCoeff


                        score = score * self.sortCoeff      #昇順、降順を決定
                        data.append(score)
                    else:
                        data.append("")
                else:
                    data.append("")
                newFolderDirs.append(data)
            newFolderNums = list(filter(lambda x: type(x[2]) != str, newFolderDirs))
            newFolderEmps = list(filter(lambda x: type(x[2]) == str, newFolderDirs))
            newFolderNums.sort(key=lambda x:(x[1], x[2]), reverse=False)
            newFolderEmps.sort(key=lambda x:(x[1]), reverse=False)
            newFolderDirs = newFolderNums + newFolderEmps
            newFolderDirs.sort(key=lambda x:(x[1]), reverse=False)
            #newFolderDirs.sort(key=lambda x:(x[1], x[2]), reverse=False)
            folderDirs = list(map(lambda x: x[0], newFolderDirs))
        #treeDataを作成
        for folder in folderDirs:
            if folder != rootDir:
                folderDir = rootName + folder[len(rootDir):]
                words = folderDir.split("/")
                folders.append(words)
        for folderWords in folders:
            treeData = self.setTreeDataFolder(0, treeData, folderWords)
        return treeData

    def setTreeDataFolder(self, nest, tree, folder):
        """ folderをtree状に作成する"""
        nest += 1
        if nest > 50:
            print("error: folder nesting is too deep!")
            return
        #親folderまでskipする
        parentDir = folder[nest]
        ii = 0
        while ii < len(tree[1]):
            if type(tree[1][ii]) == list:
                if tree[1][ii][0] == parentDir:
                    self.setTreeDataFolder(nest, tree[1][ii], folder)
                    break
            else:
                if tree[1][ii] == parentDir:
                    tree[1][ii] = [parentDir, []]
                    self.setTreeDataFolder(nest, tree[1][ii], folder)
                    break
            ii += 1
        #親folderの位置ならchildを追加する
        if nest == len(folder) - 1:
            child = folder[-1]
            tree[1].append(child)
        return tree

    #--------- directoryの取得関連 ---------
    def getDirUnderRootToSelDir(self, rootDir, selDir):
        """ rootDirからselDir系列のdirectoryを取得する"""
        folders = self.getFoldersBetweenDir(rootDir, selDir)
        childFolders = self.getChildFolders(folders)
        folders += childFolders
        return folders

    def getFoldersBetweenDir(self, startDir, endDir):
        """ startDirからendDirまでのfolderを取得する"""
        folders = [startDir]
        folders += self.getFolders(startDir)
        if startDir == endDir:
            return folders
        currDir = ""
        for folder in folders:
            n = len(folder)
            if folder == endDir[:n]:
                currDir = folder
                break
        folders += self.getFolders(currDir)
        names = endDir[len(currDir)+1:].split("/")
        for name in names:
            currDir += "/" + name
            folders += self.getFolders(currDir)
        return folders 

    def getFolders(self, currDir):
        """ curDirのfolderDirを取得する。
        currDirが「div*」の場合は、div*のfolderのみ取得する。"""
        if os.path.basename(currDir)[:len("div")] == "div":
            items = glob.glob(currDir + "/div*")
        else:
            items = glob.glob(currDir + "/*")
        folders = list(filter(lambda x: os.path.isdir(x), items))
        return folders

    def getChildFolders(self, folders):
        """ foldersの子foldersを取得する"""
        subFolders = []
        for folder in folders:
            subFolders += self.getFolders(folder)
        return subFolders

    
# def showGui():
#     app = QtGui.QApplication(sys.argv)
#     #ui = treeWidget_test()
#     #ui.main()
#     sys.exit(app.exec_())

# if __name__ == "__main__":
#     showGui()
