#!/usr/bin/python3
# coding: utf-8
#
#  CommonUtil.py
#
import os
import os.path
import glob
import shutil
import sys

import CommonUtil

currDir = sys.argv[1]
onlyCsv = sys.argv[2]

#print("The value of currDir is")
#print(currDir)
#print("The value of only Csv is")
#print(onlyCsv)

if onlyCsv != "0":
    names = glob.glob(currDir + "/*")
    for name in names:
        if os.path.isfile(name):
            if name.split(".")[-1] != "csv" and name.split(".")[-1] != "log":
                os.remove(name)
        elif os.path.isdir(name):
            if os.path.basename(name)[:len("div")] != "div":
                shutil.rmtree(name)
        else:
            pass

try:
    names = glob.glob(currDir + "/*")
    for name in names:
        if os.path.isfile(name):
            if os.path.basename(name) =="statchecked.csv":
                os.remove(name)
except:
    pass
