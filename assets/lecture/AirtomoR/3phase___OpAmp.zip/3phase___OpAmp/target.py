import sys
import os 
import glob
import re  
import csv
import cmath
import math
import spicelib
#from PyLTSpice import RawRead
from spicelib import RawRead
from spicelib import SimRunner
from spicelib import SpiceEditor
from spicelib.simulators.ltspice_simulator import LTspice
from spicelib.editor.asc_editor import AscEditor
#from PyLTSpice import SimRunner
#from PyLTSpice import SpiceEditor
runner = SimRunner(output_folder='./temp',simulator=LTspice)

pattern=r'([+-]?[0-9]+\.?[0-9]*)'

def float_to_str(f):
    float_string = repr(f)
    if 'e' in float_string:  # detect scientific notation
        digits, exp = float_string.split('e')
        digits = digits.replace('.', '').replace('-', '')
        exp = int(exp)
        zero_padding = '0' * (abs(int(exp)) - 1)  # minus 1 for decimal point in the sci notation
        sign = '-' if f < 0 else ''
        if exp > 0:
            float_string = '{}{}{}.0'.format(sign, digits, zero_padding)
        else:
            float_string = '{}0.{}{}'.format(sign, zero_padding, digits)
    return float_string


currDir = os.getcwd()
f = open(currDir + "/param_list.csv","r")
job_list = csv.reader(f)
job_list = [row for row in job_list]
param_list = [float(v) for v in job_list[0]]
f.close()

currDirLikeWin = "Z:" + currDir


try:
    asc = AscEditor("./PREamp3.asc")  
    netlist_path = asc.save_netlist('PREamp3.net')
    print("Netlist saved to:", netlist_path)
except Exception as e:
    print("Error:", e)



#LTC = SimRunner(output_folder='./temp')
LTspice.create_netlist('./PREamp3.asc')

with open('./PREamp3.net',encoding='CP932') as f:
    s = f.read()
    lines = s.split("\n")
    lines[8] =lines[8] +" " + "W=" + str(param_list[0])+" " + "L=" + str(param_list[1])
    lines[9] =lines[9] +" " + "W=" + str(param_list[2])+" " + "L=" + str(param_list[3])+" " + "M=6"
    lines[10] =lines[10] +" " + "W=" + str(param_list[4])+" " + "L=" + str(param_list[5])     
    lines[11] =lines[11] +" " + "W=" + str(param_list[4])+" " + "L=" + str(param_list[5])    
    lines[12] =lines[12] +" " + "W=" + str(param_list[6])+" " + "L=" + str(param_list[7])+" " + "M=3"
    lines[13] =lines[13] +" " + "W=" + str(param_list[6])+" " + "L=" + str(param_list[7])+" " + "M=3" 
    lines[14] =lines[14] +" " + "W=" + str(param_list[8])+" " + "L=" + str(param_list[9])
    lines[15] =lines[15] +" " + "W=" + str(param_list[8])+" " + "L=" + str(param_list[9])
    lines[16] =lines[16] +" " + "W=" + str(param_list[10])+" " + "L=" + str(param_list[11])
    lines[17] =lines[17] +" " + "W=" + str(param_list[10])+" " + "L=" + str(param_list[11])
    lines[18] =lines[18] +" " + "W=" + str(param_list[12])+" " + "L=" + str(param_list[13])
    lines[19] =lines[19] +" " + "W=" + str(param_list[14])+" " + "L=" + str(param_list[15])
    lines[20] =lines[20] +" " + "W=" + str(param_list[16])+" " + "L=" + str(param_list[17])#21
    lines[21] =lines[21] +" " + "W=" + str(param_list[16])+" " + "L=" + str(param_list[17])#22
    lines[22] =lines[22] +" " + "W=" + str(param_list[18])+" " + "L=" + str(param_list[19])+" " + "M=22"#23
    lines[23] =lines[23] +" " + "W=" + str(param_list[20])+" " + "L=" + str(param_list[21])+" " + "M=5" #24

#    lines[7] =lines[m+18][:-1] +" " + str(param_list[m+32]) 
    lines[1] ="IBIAS N001 AVSS"+" "+str(param_list[25])
    lines[2] =lines[2][:-1] +" " + str(param_list[22]) 
    lines[3] =lines[3][:-1] +" " + str(param_list[23]) 
    lines[5] ="V2 Vb1 0"+" "+str(param_list[24])

    lines[-2] = ".LIB "+ currDirLikeWin + "/p.typ \n"
    lines.append(".LIB "+ currDirLikeWin + "/n.typ")
    lines.append(".END")


 
    #lines[18] ="CM2 N006 N003" +" " + str(param_list[32])    
    #lines[19] ="CM1 N003 VOUT" +" " + str(param_list[33])
    

s = "\n".join(lines)
with open('./amp3.net', "w") as f:
    f.write(s)

raw_file, log_file = runner.run_now('./amp3.net')
#netlist = SpiceEditor("./amp3.net")

#LTC.run(netlist)
#LTR = LTSpiceRawRead('amp3.raw') 

runner.wait_completion()
#LTC.wait_completion()

LTR = RawRead(r'./temp/amp3_1.raw') 














result_list1 = LTR.get_trace('V(VOUT)')
result_list2 = LTR.get_trace('V(VP)')
result_list3 = LTR.get_trace('V(AVDD)')
result_list4 = LTR.get_trace('V(AVSS)')


with open('./temp/amp3_1.log',encoding='CP932') as f:
    s = f.read()
    lines = s.split("\n")
    test_result_list =[]
    print(lines[7],lines[8])
    for i in range(len(lines)):
        if lines[i][:5] == "test:":
            print("test found")
            test_result_list= re.findall(pattern, lines[i] )
    print(test_result_list)
    test_result = test_result_list[0]
    
with open('./temp/amp3_1.log',encoding='CP932') as f:
    s = f.read()
    lines = s.split("\n")
    test_result_list1 =[]
    print(lines[7],lines[8])
    for i in range(len(lines)):
        if lines[i][:6] == "power:":
            print("power found")
            test_result_list1= re.findall(pattern, lines[i] )
            print(test_result_list1)
            
    test_result1 = test_result_list1[1]
    #test_result1=1000.0*(10**(0.05*float(test_result1)))    
    test_result1=1000*float(test_result1)
    test_result1=str(test_result1)

with open('./temp/amp3_1.log',encoding='CP932') as f:
    s = f.read()
    lines = s.split("\n")
    test_result_list3 =[]
    print(lines[7],lines[8])
    for i in range(len(lines)):
        if lines[i][:6] == "phase:":
           segments = lines[i].split()
           if len(segments) > 1:
              backcut = ' '.join(segments[:-1])
           else:
              backcut = ""  # 要素が1つのみの場合は空文字にする

           print("phase found")
           test_result_list3= re.findall(pattern, backcut)
           print(test_result_list3)
           test_result3 = test_result_list3[-1]
try:
   phasemargin=180-abs(float(test_result3))
except:
   phasemargin=1.0

phasemargin=str(phasemargin)

totalscore=10000.0
if (10**6)*float(test_result1)/(float(phasemargin)*float(test_result))>0.0:
    totalscore=(10**6)*float(test_result1)/(float(phasemargin)*float(test_result))
else:
    exit()

totalscore=str(totalscore)





currDir = os.getcwd()
f10=open(currDir + "/score.csv","w")
f10.write(totalscore+","+test_result+","+test_result1+","+phasemargin)
#f10.write(str(abs(result_list1[-1]))+','+str(abs(result_list2[-1]))+','+str(abs(result_list3[-1]))+','+str(abs(result_list4[-1])))

f10.close()
