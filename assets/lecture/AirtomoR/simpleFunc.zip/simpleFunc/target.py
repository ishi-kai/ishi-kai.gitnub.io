#!/usr/bin/python
#  coding: utf-8
#
FREECADPATH = "/usr/local/lib"
import sys
sys.path.append(FREECADPATH)
import os
import glob
import subprocess
import multiprocessing
import time
import csv

from functools import partial
from decimal import Decimal
#import sys
import os.path
import gettext
import tempfile
import math

def getScoreWriteFile2(resDir,param_list):
    total_up_ratio = 7.*param_list[0]+5.*param_list[1]+3.*param_list[2]+2.*param_list[3]-(7.*param_list[7]+5.*param_list[6]+3.*param_list[5]+2.*param_list[4])
#    up_ratio = 7.*param_list[0]+5.*param_list[1]+3.*param_list[2]+2.*param_list[3]-(7.*param_list[7]+5.*param_list[6]+3.*param_list[5]+2.*param_list[4])
#    up_ratio2 = 7.*param_list[0]+5.*param_list[1]+3.*param_list[2]+2.*param_list[3]-(7.*param_list[7]+5.*param_list[6]+3.*param_list[5]+2.*param_list[4])
#    up_ratio3 = 7.*param_list[0]+5.*param_list[1]+3.*param_list[2]+2.*param_list[3]-(7.*param_list[7]+5.*param_list[6]+3.*param_list[5]+2.*param_list[4])
    f10=open(resDir + "/score.csv","w")
    f10.write(str(total_up_ratio))
    f10.close()


currDir = os.getcwd()

os.chdir(currDir)

nCpu_perCase = 1

f = open(currDir + "/param_list.csv","r")
job_list = csv.reader(f)
job_list = [row for row in job_list]
param_list = [float(v) for v in job_list[0]]

f.close()

getScoreWriteFile2(currDir,param_list)
